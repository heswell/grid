export default class DragState {
    constructor(zone: any, mouseX: any, mouseY: any, measurements: any);
    init(zone: any, mouseX: any, mouseY: any, rect: any): void;
    constraint: {
        zone: {
            x: {
                lo: any;
                hi: any;
            };
            y: {
                lo: any;
                hi: any;
            };
        };
        pos: {
            x: {
                lo: number;
                hi: number;
            };
            y: {
                lo: number;
                hi: number;
            };
        };
        mouse: {
            x: {
                lo: any;
                hi: number;
            };
            y: {
                lo: any;
                hi: number;
            };
        };
    } | undefined;
    x: {
        pos: any;
        lo: boolean;
        hi: boolean;
        mousePos: any;
        mousePct: number;
    } | undefined;
    y: {
        pos: any;
        lo: boolean;
        hi: boolean;
        mousePos: any;
        mousePct: number;
    } | undefined;
    outOfBounds(): boolean;
    inBounds(): boolean;
    dropX(): any;
    dropY(): any;
    update(xy: any, mousePos: any): boolean;
}
