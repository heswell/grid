export function pointPositionWithinRect(x: any, y: any, rect: any): {
    position: Readonly<{
        offset: number;
        valueOf: () => any;
        toString: () => any;
        North: boolean;
        South: boolean;
        East: boolean;
        West: boolean;
        Header: boolean;
        Centre: boolean;
        NorthOrSouth: boolean;
        EastOrWest: boolean;
        NorthOrWest: boolean;
        SouthOrEast: boolean;
        Absolute: boolean;
    }> | undefined;
    x: any;
    y: any;
    pctX: number;
    pctY: number;
    closeToTheEdge: number;
    tab: {
        left: any;
        index: any;
    } | undefined;
};
export namespace positionValues {
    const north: number;
    const east: number;
    const south: number;
    const west: number;
    const header: number;
    const centre: number;
    const absolute: number;
}
export var Position: Readonly<{
    North: Readonly<{
        offset: number;
        valueOf: () => any;
        toString: () => any;
        North: boolean;
        South: boolean;
        East: boolean;
        West: boolean;
        Header: boolean;
        Centre: boolean;
        NorthOrSouth: boolean;
        EastOrWest: boolean;
        NorthOrWest: boolean;
        SouthOrEast: boolean;
        Absolute: boolean;
    }>;
    East: Readonly<{
        offset: number;
        valueOf: () => any;
        toString: () => any;
        North: boolean;
        South: boolean;
        East: boolean;
        West: boolean;
        Header: boolean;
        Centre: boolean;
        NorthOrSouth: boolean;
        EastOrWest: boolean;
        NorthOrWest: boolean;
        SouthOrEast: boolean;
        Absolute: boolean;
    }>;
    South: Readonly<{
        offset: number;
        valueOf: () => any;
        toString: () => any;
        North: boolean;
        South: boolean;
        East: boolean;
        West: boolean;
        Header: boolean;
        Centre: boolean;
        NorthOrSouth: boolean;
        EastOrWest: boolean;
        NorthOrWest: boolean;
        SouthOrEast: boolean;
        Absolute: boolean;
    }>;
    West: Readonly<{
        offset: number;
        valueOf: () => any;
        toString: () => any;
        North: boolean;
        South: boolean;
        East: boolean;
        West: boolean;
        Header: boolean;
        Centre: boolean;
        NorthOrSouth: boolean;
        EastOrWest: boolean;
        NorthOrWest: boolean;
        SouthOrEast: boolean;
        Absolute: boolean;
    }>;
    Header: Readonly<{
        offset: number;
        valueOf: () => any;
        toString: () => any;
        North: boolean;
        South: boolean;
        East: boolean;
        West: boolean;
        Header: boolean;
        Centre: boolean;
        NorthOrSouth: boolean;
        EastOrWest: boolean;
        NorthOrWest: boolean;
        SouthOrEast: boolean;
        Absolute: boolean;
    }>;
    Centre: Readonly<{
        offset: number;
        valueOf: () => any;
        toString: () => any;
        North: boolean;
        South: boolean;
        East: boolean;
        West: boolean;
        Header: boolean;
        Centre: boolean;
        NorthOrSouth: boolean;
        EastOrWest: boolean;
        NorthOrWest: boolean;
        SouthOrEast: boolean;
        Absolute: boolean;
    }>;
    Absolute: Readonly<{
        offset: number;
        valueOf: () => any;
        toString: () => any;
        North: boolean;
        South: boolean;
        East: boolean;
        West: boolean;
        Header: boolean;
        Centre: boolean;
        NorthOrSouth: boolean;
        EastOrWest: boolean;
        NorthOrWest: boolean;
        SouthOrEast: boolean;
        Absolute: boolean;
    }>;
}>;
export class BoxModel {
    static measure(model: any): {};
    static smallestBoxContainingPoint(layout: any, measurements: any, x: any, y: any): any;
}
