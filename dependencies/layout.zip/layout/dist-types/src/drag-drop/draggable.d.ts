export class DragContainer {
    static get paths(): any[];
    static register(path: any): void;
    static unregister(): void;
}
export namespace Draggable {
    function handleMousedown(e: any, dragStartCallback: any, dragOptions?: {}): void;
    function handleMousedown(e: any, dragStartCallback: any, dragOptions?: {}): void;
    function initDrag(rootContainer: any, dragContainerPath: any, { top, left, right, bottom }: {
        top: any;
        left: any;
        right: any;
        bottom: any;
    }, dragPos: any, dragHandler: any): {
        transform: string;
        transformOrigin: string;
    };
    function initDrag(rootContainer: any, dragContainerPath: any, { top, left, right, bottom }: {
        top: any;
        left: any;
        right: any;
        bottom: any;
    }, dragPos: any, dragHandler: any): {
        transform: string;
        transformOrigin: string;
    };
}
