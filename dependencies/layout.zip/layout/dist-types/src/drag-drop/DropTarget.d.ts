export function identifyDropTarget(x: any, y: any, model: any, measurements: any): DropTarget | null;
export function getNextDropTarget(layout: any, component: any, pos: any, measurements: any, x: any, y: any): any;
export function isTabstrip(dropTarget: any): any;
export class DropTarget {
    static getActiveDropTarget(dropTarget: any): any;
    constructor({ component, pos, clientRect, nextDropTarget, }: {
        component: any;
        pos: any;
        clientRect: any;
        nextDropTarget: any;
    });
    component: any;
    pos: any;
    clientRect: any;
    nextDropTarget: any;
    active: boolean;
    targetTabRect(lineWidth: any, offsetTop?: number, offsetLeft?: number): number[] | null;
    targetRect(lineWidth: any, offsetTop?: number, offsetLeft?: number): number[] | null;
    activate(): DropTarget;
    toArray(): DropTarget[];
}
