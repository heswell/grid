export default class DropTargetCanvas {
    prepare(position: any): void;
    clear(): void;
    get hoverDropTarget(): any;
    draw(dropTarget: any): void;
    drawTarget(dropTarget: any, offsetTop?: number, offsetLeft?: number): void;
}
