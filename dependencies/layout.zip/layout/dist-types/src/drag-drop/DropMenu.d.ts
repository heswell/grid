export function computeMenuPosition(dropTarget: any, offsetTop?: number, offsetLeft?: number): React.ReactText[];
export default DropMenu;
import React from "react";
declare function DropMenu({ className, dropTarget, onHover, orientation }: {
    className: any;
    dropTarget: any;
    onHover: any;
    orientation: any;
}): JSX.Element;
