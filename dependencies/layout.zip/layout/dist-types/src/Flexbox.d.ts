export default Flexbox;
declare function Flexbox(inputProps: any): JSX.Element;
declare namespace Flexbox {
    const displayName: string;
}
