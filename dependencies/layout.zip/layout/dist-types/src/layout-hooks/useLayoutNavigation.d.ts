export default function useLayoutNavigation(layoutType: any, props: any, layoutRef: any, stateRef: any): ((action: any) => boolean) | undefined;
