export default Stack;
declare function Stack(inputProps: any): JSX.Element;
declare namespace Stack {
    const displayName: string;
}
