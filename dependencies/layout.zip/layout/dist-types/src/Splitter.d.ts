export default Splitter;
declare const Splitter: React.NamedExoticComponent<object>;
import React from "react";
