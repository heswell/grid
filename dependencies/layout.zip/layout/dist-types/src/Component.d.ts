export default Component;
declare function Component({ id, isChanged, style }: {
    id: any;
    isChanged: any;
    style: any;
}, ref: any): JSX.Element;
declare namespace Component {
    const displayName: string;
}
