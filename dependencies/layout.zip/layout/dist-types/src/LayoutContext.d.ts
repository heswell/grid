export function useLayoutDispatch(): null;
export function useLayoutContext(): {
    dispatch: null;
};
export default LayoutContext;
declare const LayoutContext: React.Context<{
    dispatch: null;
}>;
import React from "react";
