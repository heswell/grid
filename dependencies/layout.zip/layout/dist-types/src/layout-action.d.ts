export namespace Action {
    const ADD: string;
    const BLUR: string;
    const BLUR_SPLITTER: string;
    const DRAG_START: string;
    const DRAG_STARTED: string;
    const DRAG_DROP: string;
    const FOCUS: string;
    const FOCUS_SPLITTER: string;
    const INITIALIZE: string;
    const MAXIMIZE: string;
    const MINIMIZE: string;
    const REMOVE: string;
    const REPLACE: string;
    const RESTORE: string;
    const SPLITTER_RESIZE: string;
    const SWITCH_TAB: string;
    const TEAR_OUT: string;
}
