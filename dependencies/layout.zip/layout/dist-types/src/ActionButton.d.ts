export default ActionButton;
declare function ActionButton({ actionId, accessibleText, className, iconName, onClick, title, ...props }: {
    [x: string]: any;
    actionId: any;
    accessibleText: any;
    className: any;
    iconName: any;
    onClick: any;
    title: any;
}): JSX.Element;
