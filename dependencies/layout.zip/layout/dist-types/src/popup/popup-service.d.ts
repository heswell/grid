export class PopupService {
    static showPopup({ name, group, position, left, right, top, width, component, onClose }: {
        name?: string | undefined;
        group?: string | undefined;
        position?: string | undefined;
        left?: number | undefined;
        right?: string | undefined;
        top?: number | undefined;
        width?: string | undefined;
        component: any;
        onClose: any;
    }): void;
    static hidePopup(e: any, name?: string, group?: string): void;
    static movePopup(x: any, y: any, name?: string, group?: string): void;
    static movePopupTo(x: any, y: any, name?: string, group?: string): void;
    static keepWithinThePage(el: any, right?: string): void;
}
export class DialogService {
    static showDialog(dialog: any): void;
    static closeDialog(): void;
}
export class Popup extends React.Component<any, any, any> {
    constructor(props: any);
    pendingTask: NodeJS.Timeout | null;
    show(props: any, boundingClientRect: any): void;
}
import React from "react";
