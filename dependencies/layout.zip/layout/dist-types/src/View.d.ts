export default View;
declare const View: React.NamedExoticComponent<object>;
import React from "react";
