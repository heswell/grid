export function layoutToJSON(type: any, props: any, component: any): any;
export function componentToJson(component: any): any;
export function serializeProps(props: any): {} | undefined;
export function getManagedDimension(style: any): string[];
export function applyLayoutProps(component: any): React.DetailedReactHTMLElement<any, HTMLElement>;
export function applyLayout(type: any, props: any, previousLayout: any): any;
import React from "react";
