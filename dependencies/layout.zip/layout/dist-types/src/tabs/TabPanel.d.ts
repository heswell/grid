export default TabPanel;
declare function TabPanel({ ariaLabelledBy, children, id }: {
    ariaLabelledBy: any;
    children: any;
    id: any;
}): JSX.Element;
