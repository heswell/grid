export { default as TabPanel } from "./TabPanel";
