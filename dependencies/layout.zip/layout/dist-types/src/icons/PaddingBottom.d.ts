declare var _default: React.MemoExoticComponent<() => JSX.Element>;
export default _default;
import React from "react";
