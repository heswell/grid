declare var _default: React.MemoExoticComponent<({ onClick }: {
    onClick: any;
}) => JSX.Element>;
export default _default;
import React from "react";
