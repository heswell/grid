export default Close;
declare function Close({ className, ...props }: {
    [x: string]: any;
    className: any;
}): JSX.Element;
