export default Minimize;
declare function Minimize({ className, ...props }: {
    [x: string]: any;
    className: any;
}): JSX.Element;
