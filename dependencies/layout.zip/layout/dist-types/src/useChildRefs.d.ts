export function useChildRefs(children: any): never[];
