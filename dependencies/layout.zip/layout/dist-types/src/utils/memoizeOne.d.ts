export default function memoizeOne(resultFn: any, isEqual?: typeof areInputsEqual): (...newArgs: any[]) => any;
declare function areInputsEqual(newInputs: any, lastInputs: any): boolean;
export {};
