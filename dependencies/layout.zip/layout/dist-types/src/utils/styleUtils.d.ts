export function expandFlex(flex: any): {
    flexBasis: number;
    flexGrow: number;
    flexShrink: number;
};
