export function useForkRef(refA: any, refB: any): ((refValue: any) => void) | null;
