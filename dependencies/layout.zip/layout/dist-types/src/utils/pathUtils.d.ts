export function followPathToParent(source: any, path: any): any;
export function containerOf(source: any, target: any): any;
export function followPath(source: any, path: any): any;
export function nextLeaf(root: any, path: any): any;
export function previousLeaf(root: any, path: any): any;
export function nextStep(pathSoFar: any, targetPath: any): {
    idx: any;
    finalStep: boolean;
};
export function resetPath(model: any, path: any): any;
