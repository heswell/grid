export function typeOf(element: any): any;
export function isTypeOf(element: any, type: any): boolean;
