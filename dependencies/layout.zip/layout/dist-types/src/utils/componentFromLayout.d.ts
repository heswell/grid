export default function componentFromLayout(layout: any): JSX.Element;
