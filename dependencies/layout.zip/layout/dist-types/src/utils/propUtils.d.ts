export function getProp(component: any, propName: any): any;
export function getProps(component: any): any;
