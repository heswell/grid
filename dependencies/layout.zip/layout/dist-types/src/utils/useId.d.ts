export default function useId(idOverride: any): any;
