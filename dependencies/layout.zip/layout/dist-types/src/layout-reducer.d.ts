export default layoutReducer;
declare function layoutReducer(state: any, action: any): any;
