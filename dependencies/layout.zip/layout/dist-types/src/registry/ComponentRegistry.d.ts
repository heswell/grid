export function isContainer(componentType: any): boolean;
export function isView(componentType: any): boolean;
export function registerComponent(componentName: any, component: any, type?: string): void;
export const ComponentRegistry: {};
export function isLayoutComponent(type: any): boolean;
export function isRegistered(className: any): boolean;
