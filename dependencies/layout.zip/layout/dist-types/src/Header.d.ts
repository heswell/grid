export default Header;
declare function Header({ className: classNameProp, density: densityProp, collapsed, expanded, closeable, orientation: orientationProp, style, tearOut, }: {
    className: any;
    density: any;
    collapsed: any;
    expanded: any;
    closeable: any;
    orientation: any;
    style: any;
    tearOut: any;
}): JSX.Element;
