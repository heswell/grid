export function useViewActionDispatcher(root: any, viewPath: any, layoutDispatch: any): (action: any, evt: any) => any;
