export default DraggableLayout;
declare function DraggableLayout(inputProps: any): JSX.Element;
