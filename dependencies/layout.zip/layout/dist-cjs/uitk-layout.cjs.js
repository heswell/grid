'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var nanoid = require('nanoid');
var React = require('react');
var classnames = require('classnames');
var ReactDOM = require('react-dom');
var toolkit = require('@uitk/toolkit');
var d3Selection = require('d3-selection');
require('d3-transition');

function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

var React__default = /*#__PURE__*/_interopDefaultLegacy(React);
var classnames__default = /*#__PURE__*/_interopDefaultLegacy(classnames);
var ReactDOM__default = /*#__PURE__*/_interopDefaultLegacy(ReactDOM);

var Action = {
  ADD: "add",
  BLUR: "blur",
  BLUR_SPLITTER: "blur-splitter",
  DRAG_START: "drag-start",
  DRAG_STARTED: "drag-started",
  DRAG_DROP: "drag-drop",
  FOCUS: "focus",
  FOCUS_SPLITTER: "focus-splitter",
  INITIALIZE: "initialize",
  MAXIMIZE: "maximize",
  MINIMIZE: "minimize",
  REMOVE: "remove",
  REPLACE: "replace",
  RESTORE: "restore",
  SPLITTER_RESIZE: "splitter-resize",
  SWITCH_TAB: "switch-tab",
  TEAR_OUT: "tear-out"
};

function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function (obj) {
      return typeof obj;
    };
  } else {
    _typeof = function (obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

function _extends() {
  _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    if (enumerableOnly) symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    });
    keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread2(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        _defineProperty(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }

  return target;
}

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

function _objectWithoutProperties(source, excluded) {
  if (source == null) return {};

  var target = _objectWithoutPropertiesLoose(source, excluded);

  var key, i;

  if (Object.getOwnPropertySymbols) {
    var sourceSymbolKeys = Object.getOwnPropertySymbols(source);

    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }

  return target;
}

function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}

function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}

function _iterableToArrayLimit(arr, i) {
  if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return;
  var _arr = [];
  var _n = true;
  var _d = false;
  var _e = undefined;

  try {
    for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];

  return arr2;
}

function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _toPrimitive(input, hint) {
  if (typeof input !== "object" || input === null) return input;
  var prim = input[Symbol.toPrimitive];

  if (prim !== undefined) {
    var res = prim.call(input, hint || "default");
    if (typeof res !== "object") return res;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }

  return (hint === "string" ? String : Number)(input);
}

function _toPropertyKey(arg) {
  var key = _toPrimitive(arg, "string");

  return typeof key === "symbol" ? key : String(key);
}

function styleInject(css, ref) {
  if ( ref === void 0 ) ref = {};
  var insertAt = ref.insertAt;

  if (!css || typeof document === 'undefined') { return; }

  var head = document.head || document.getElementsByTagName('head')[0];
  var style = document.createElement('style');
  style.type = 'text/css';

  if (insertAt === 'top') {
    if (head.firstChild) {
      head.insertBefore(style, head.firstChild);
    } else {
      head.appendChild(style);
    }
  } else {
    head.appendChild(style);
  }

  if (style.styleSheet) {
    style.styleSheet.cssText = css;
  } else {
    style.appendChild(document.createTextNode(css));
  }
}

var css_248z = ".react-dialog,\n.react-popup {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 0;\n  height: 0;\n  overflow: visible;\n  z-index: 1000;\n}\n\n.Popup {\n  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 0;\n  height: 0;\n  overflow: visible;\n  z-index: 1000;\n}\n";
styleInject(css_248z);

window.popupReact = React__default['default'];
var _dialogOpen = false;

var _popups = new Map();

function specialKeyHandler(e) {
  if (e.keyCode === 27
  /* ESC */
  ) {
      if (_popups.size) {
        closeAllPopups(e);
        console.log("unmount the open popup(s)");
      }
    }
}

function outsideMouseDownHandler(e) {
  if (_popups.size) {
    // onsole.log(`Popup.outsideClickHandler`);
    var popupContainers = document.body.querySelectorAll(".react-popup");

    for (var i = 0; i < popupContainers.length; i++) {
      if (popupContainers[i].contains(e.target)) {
        return;
      }
    }

    closeAllPopups(e);
  }
}

function closeAllPopups(e) {
  if (_popups.size) {
    // onsole.log(`closeAllPopups`);
    var popupContainers = document.body.querySelectorAll(".react-popup");

    for (var i = 0; i < popupContainers.length; i++) {
      ReactDOM__default['default'].unmountComponentAtNode(popupContainers[i]);
    }

    popupClosed(e, "*");
  }
}

function popupOpened(name, onClose) {
  if (!_popups.has(name)) {
    _popups.set(name, {
      onClose: onClose
    });

    {
      window.addEventListener("keydown", specialKeyHandler, true);
      window.addEventListener("mousedown", outsideMouseDownHandler, true);
    }
  }
}

function popupClosed(e, name) {
  if (_popups.size) {
    if (name === "*") {
      _popups.forEach(function (_ref) {
        var onClose = _ref.onClose;
        onClose && onClose(e);
      });

      _popups.clear();
    } else if (_popups.has(name)) {
      var _popups$get = _popups.get(name),
          onClose = _popups$get.onClose;

      onClose && onClose(e);

      _popups["delete"](name);
    } //onsole.log('PopupService, popup closed ' + name + '  popups : ' + _popups);


    if (_popups.size === 0 && _dialogOpen === false) {
      window.removeEventListener("keydown", specialKeyHandler, true);
      window.removeEventListener("mousedown", outsideMouseDownHandler, true);
    }
  }
}

var PopupComponent = function PopupComponent(_ref2) {
  var children = _ref2.children,
      position = _ref2.position,
      style = _ref2.style;
  var className = classnames__default['default']("Popup", "popup-container", position);
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: style
  }, children);
};

var incrementingKey = 1;
var PopupService = /*#__PURE__*/function () {
  function PopupService() {
    _classCallCheck(this, PopupService);
  }

  _createClass(PopupService, null, [{
    key: "showPopup",
    value: function showPopup(_ref3) {
      var _ref3$name = _ref3.name,
          name = _ref3$name === void 0 ? "anon" : _ref3$name,
          _ref3$group = _ref3.group,
          group = _ref3$group === void 0 ? "all" : _ref3$group,
          _ref3$position = _ref3.position,
          position = _ref3$position === void 0 ? "" : _ref3$position,
          _ref3$left = _ref3.left,
          left = _ref3$left === void 0 ? 0 : _ref3$left,
          _ref3$right = _ref3.right,
          right = _ref3$right === void 0 ? "auto" : _ref3$right,
          _ref3$top = _ref3.top,
          top = _ref3$top === void 0 ? 0 : _ref3$top,
          _ref3$width = _ref3.width,
          width = _ref3$width === void 0 ? "auto" : _ref3$width,
          component = _ref3.component,
          onClose = _ref3.onClose;

      // onsole.log(`PopupService.showPopup ${name} in ${group} ${left} ${top} ${width} depth ${depth}`);
      if (!component) {
        throw Error("PopupService showPopup, no component supplied");
      }

      popupOpened(name, onClose);
      var el = document.body.querySelector(".react-popup." + group);

      if (el === null) {
        el = document.createElement("div");
        el.className = "react-popup " + group;
        document.body.appendChild(el);
      }

      var style = {
        left: left,
        top: top,
        width: width
      };
      ReactDOM__default['default'].render( /*#__PURE__*/React.createElement(PopupComponent, {
        key: incrementingKey++,
        position: position,
        style: style
      }, component), el, function () {
        PopupService.keepWithinThePage(el, right);
      });
    }
  }, {
    key: "hidePopup",
    value: function hidePopup(e) {
      var name = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "anon";
      var group = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "all";

      //onsole.log('PopupService.hidePopup name=' + name + ', group=' + group)
      if (_popups.has(name)) {
        popupClosed(e, name);
        ReactDOM__default['default'].unmountComponentAtNode(document.body.querySelector(".react-popup.".concat(group)));
      }
    }
  }, {
    key: "movePopup",
    value: function movePopup(x, y) {
      var group = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : "all";
      var container = document.querySelector(".react-popup.".concat(group, " .popup-container"));
      container.style.top = parseInt(container.style.top, 10) + y + "px";
      container.style.left = parseInt(container.style.left, 10) + x + "px";
    }
  }, {
    key: "movePopupTo",
    value: function movePopupTo(x, y) {
      var group = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : "all";
      var container = document.querySelector(".react-popup.".concat(group, " .popup-container"));
      container.style.top = "".concat(y, "px");
      container.style.left = "".concat(x, "px");
    }
  }, {
    key: "keepWithinThePage",
    value: function keepWithinThePage(el) {
      var right = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "auto";
      console.log("PopupService.keepWithinThePage");
      var container = el.querySelector(".popup-container");

      var _container$firstChild = container.firstChild.getBoundingClientRect(),
          top = _container$firstChild.top,
          left = _container$firstChild.left,
          width = _container$firstChild.width,
          height = _container$firstChild.height,
          currentRight = _container$firstChild.right;

      var w = window.innerWidth;
      var h = window.innerHeight;
      var overflowH = h - (top + height);

      if (overflowH < 0) {
        container.style.top = parseInt(container.style.top, 10) + overflowH + "px";
      }

      var overflowW = w - (left + width);

      if (overflowW < 0) {
        container.style.left = parseInt(container.style.left, 10) + overflowW + "px";
      }

      if (typeof right === "number" && right !== currentRight) {
        var adjustment = right - currentRight;
        container.style.left = left + adjustment + "px";
      }
    }
  }]);

  return PopupService;
}();

var _containers = {};
var _views = {};
var ComponentRegistry = {};
function isContainer(componentType) {
  return _containers[componentType] === true;
}
function isView(componentType) {
  return _views[componentType] === true;
}
var isLayoutComponent = function isLayoutComponent(type) {
  return isContainer(type) || isView(type);
};
function registerComponent(componentName, component) {
  var type = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "component";
  ComponentRegistry[componentName] = component;

  if (type === "container") {
    _containers[componentName] = true;
  } else if (type === "view") {
    _views[componentName] = true;
  }
} // const EMPTY_OBJECT = {};
// export function getDefaultProps({ type }) {
//   if (typeof type === "function" && type.prototype.isReactComponent) {
//     return type.defaultProps;
//   }
//   return EMPTY_OBJECT;
// }

var css_248z$1 = ".Icon {\n  /* display: inline-block; */\n  /* width: 18px;\n  height: 18px; */\n  /* box-sizing: border-box; */\n}\n\n.Icon .icon-path {\n  fill: grey;\n}\n";
styleInject(css_248z$1);

var neverRerender = function neverRerender() {
  return true;
}; // onClick is temporary until we have a proper Toolbar Field


var AddIcon = function AddIcon(_ref) {
  var onClick = _ref.onClick;
  var root = React.useRef(null);
  React.useEffect(function () {
    root.current.innerHTML = "\n    <svg height=\"100%\" viewBox=\"0 0 18 18\" width=\"100%\">\n    <path class=\"icon-path\" d=\"M14.5,8H10V3.5A.5.5,0,0,0,9.5,3h-1a.5.5,0,0,0-.5.5V8H3.5a.5.5,0,0,0-.5.5v1a.5.5,0,0,0,.5.5H8v4.5a.5.5,0,0,0,.5.5h1a.5.5,0,0,0,.5-.5V10h4.5a.5.5,0,0,0,.5-.5v-1A.5.5,0,0,0,14.5,8Z\" />\n    </svg>";
  }, []);
  return /*#__PURE__*/React__default['default'].createElement("span", {
    className: "Icon close",
    ref: root,
    onClick: onClick
  });
};

var Add = /*#__PURE__*/React__default['default'].memo(AddIcon, neverRerender);
registerComponent("AddIcon", AddIcon);

var Close = function Close(_ref) {
  var className = _ref.className,
      props = _objectWithoutProperties(_ref, ["className"]);

  return /*#__PURE__*/React__default['default'].createElement(toolkit.Button, _extends({}, props, {
    className: classnames__default['default']('CloseButton', className),
    title: "Close View",
    variant: "secondary"
  }), /*#__PURE__*/React__default['default'].createElement(toolkit.Icon, {
    accessibleText: "Close View",
    name: "close"
  }));
};

var neverRerender$1 = function neverRerender() {
  return true;
}; // onClick is temporary until we have a proper Toolbar Field


var Icon = function Icon(_ref) {
  var onClick = _ref.onClick;
  var root = React.useRef(null);
  React.useEffect(function () {
    root.current.innerHTML = "\n    <svg height=\"100%\" viewBox=\"0 0 18 18\" width=\"100%\">\n    <path class=\"icon-path icon-path-1\" d=\"M8,1H2A1,1,0,0,0,1,2V16a1,1,0,0,0,1,1H8Z\" />\n    <path class=\"icon-path icon-path-2\" d=\"M16,1H10V17h6a1,1,0,0,0,1-1V2A1,1,0,0,0,16,1Z\" />\n    </svg>";
  }, []);
  return /*#__PURE__*/React__default['default'].createElement("span", {
    className: "Icon column2a",
    ref: root,
    onClick: onClick
  });
};

var Column2A = /*#__PURE__*/React__default['default'].memo(Icon, neverRerender$1);

var neverRerender$2 = function neverRerender() {
  return true;
}; // onClick is temporary until we have a proper Toolbar Field


var Icon$1 = function Icon(_ref) {
  var onClick = _ref.onClick;
  var root = React.useRef(null);
  React.useEffect(function () {
    root.current.innerHTML = "\n    <svg height=\"100%\" viewBox=\"0 0 18 18\" width=\"100%\">\n    <path class=\"icon-path icon-path-1\" d=\"M11,1H2A1,1,0,0,0,1,2V16a1,1,0,0,0,1,1h9Z\" />\n    <path class=\"icon-path icon-path-2\" d=\"M16,1H13V17h3a1,1,0,0,0,1-1V2A1,1,0,0,0,16,1Z\" />\n      </svg>";
  }, []);
  return /*#__PURE__*/React__default['default'].createElement("span", {
    className: "Icon column2b",
    ref: root,
    onClick: onClick
  });
};

var Column2B = /*#__PURE__*/React__default['default'].memo(Icon$1, neverRerender$2);

var neverRerender$3 = function neverRerender() {
  return true;
}; // onClick is temporary until we have a proper Toolbar Field


var Icon$2 = function Icon(_ref) {
  var onClick = _ref.onClick;
  var root = React.useRef(null);
  React.useEffect(function () {
    root.current.innerHTML = "\n    <svg height=\"100%\" viewBox=\"0 0 18 18\" width=\"100%\">\n    <rect class=\"icon-path\" height=\"1\" rx=\"0.375\" width=\"1\" x=\"6\" y=\"2\" />\n    <rect class=\"icon-path\" height=\"1\" rx=\"0.375\" width=\"1\" x=\"6\" y=\"5\" />\n    <rect class=\"icon-path\" height=\"1\" rx=\"0.375\" width=\"1\" x=\"6\" y=\"8\" />\n    <rect class=\"icon-path\" height=\"1\" rx=\"0.375\" width=\"1\" x=\"6\" y=\"11\" />\n    <rect class=\"icon-path\" height=\"1\" rx=\"0.375\" width=\"1\" x=\"6\" y=\"14\" />\n    <rect class=\"icon-path\" height=\"1\" rx=\"0.375\" width=\"1\" x=\"9\" y=\"2\" />\n    <rect class=\"icon-path\" height=\"1\" rx=\"0.375\" width=\"1\" x=\"9\" y=\"5\" />\n    <rect class=\"icon-path\" height=\"1\" rx=\"0.375\" width=\"1\" x=\"9\" y=\"8\" />\n    <rect class=\"icon-path\" height=\"1\" rx=\"0.375\" width=\"1\" x=\"9\" y=\"11\" />\n    <rect class=\"icon-path\" height=\"1\" rx=\"0.375\" width=\"1\" x=\"9\" y=\"14\" />\n      </svg>";
  }, []);
  return /*#__PURE__*/React__default['default'].createElement("span", {
    className: "Icon close",
    ref: root,
    onClick: onClick
  });
};

var DragHandle = /*#__PURE__*/React__default['default'].memo(Icon$2, neverRerender$3);

var Maximize = function Maximize(_ref) {
  var className = _ref.className,
      props = _objectWithoutProperties(_ref, ["className"]);

  return /*#__PURE__*/React__default['default'].createElement(toolkit.Button, _extends({}, props, {
    className: classnames__default['default']('MaximizeButton', className),
    title: "Maximize View",
    variant: "secondary"
  }), /*#__PURE__*/React__default['default'].createElement(toolkit.Icon, {
    accessibleText: "Maximize View",
    name: "maximize"
  }));
};

var Minimize = function Minimize(_ref) {
  var className = _ref.className,
      props = _objectWithoutProperties(_ref, ["className"]);

  return /*#__PURE__*/React__default['default'].createElement(toolkit.Button, _extends({}, props, {
    className: classnames__default['default']('MinimizeButton', className),
    title: "Minimize View",
    variant: "secondary"
  }), /*#__PURE__*/React__default['default'].createElement(toolkit.Icon, {
    accessibleText: "Minimize View",
    name: "minimize"
  }));
};

var neverRerender$4 = function neverRerender() {
  return true;
};

var Icon$3 = function Icon() {
  var root = React.useRef(null);
  React.useEffect(function () {
    root.current.innerHTML = "\n    <svg height=\"100%\" viewBox=\"0 0 18 18\" width=\"100%\">\n    <circle class=\"icon-path\" cx=\"9\" cy=\"9\" r=\"2.05\" />\n    <circle class=\"icon-path\" cx=\"9\" cy=\"3\" r=\"2.05\" />\n    <circle class=\"icon-path\" cx=\"9\" cy=\"15\" r=\"2.05\" />\n  </svg>\n  ";
  }, []);
  return /*#__PURE__*/React__default['default'].createElement("span", {
    className: "Icon more-vertical",
    ref: root
  });
};

var MoreVertical = /*#__PURE__*/React__default['default'].memo(Icon$3, neverRerender$4);

var neverRerender$5 = function neverRerender() {
  return true;
};

var Icon$4 = function Icon() {
  var root = React.useRef(null);
  React.useEffect(function () {
    root.current.innerHTML = "\n    <svg height=\"100%\" viewBox=\"0 0 18 18\" width=\"100%\">\n    <path class=\"icon-path\" d=\"M16,2V16H2V2Zm.5-1H1.5a.5.5,0,0,0-.5.5v15a.5.5,0,0,0,.5.5h15a.5.5,0,0,0,.5-.5V1.5A.5.5,0,0,0,16.5,1Z\" />\n    <rect class=\"icon-path\" height=\"4\" rx=\"0.25\" width=\"12\" x=\"3\" y=\"11\" />\n    </svg>\n  ";
  }, []);
  return /*#__PURE__*/React__default['default'].createElement("span", {
    className: "Icon more-vertical",
    ref: root
  });
};

var PaddingBottom = /*#__PURE__*/React__default['default'].memo(Icon$4, neverRerender$5);

var neverRerender$6 = function neverRerender() {
  return true;
};

var Icon$5 = function Icon() {
  var root = React.useRef(null);
  React.useEffect(function () {
    root.current.innerHTML = "\n    <svg height=\"100%\" viewBox=\"0 0 18 18\" width=\"100%\">\n    <path class=\"icon-path\" d=\"M16,16H2V2H16Zm1,.5V1.5a.5.5,0,0,0-.5-.5H1.5a.5.5,0,0,0-.5.5v15a.5.5,0,0,0,.5.5h15A.5.5,0,0,0,17,16.5Z\" />\n    <rect class=\"icon-path\" height=\"12\" rx=\"0.25\" width=\"4\" x=\"3\" y=\"3\" />\n      </svg>\n  ";
  }, []);
  return /*#__PURE__*/React__default['default'].createElement("span", {
    className: "Icon more-vertical",
    ref: root
  });
};

var PaddingLeft = /*#__PURE__*/React__default['default'].memo(Icon$5, neverRerender$6);

var neverRerender$7 = function neverRerender() {
  return true;
};

var Icon$6 = function Icon() {
  var root = React.useRef(null);
  React.useEffect(function () {
    root.current.innerHTML = "\n    <svg height=\"100%\" viewBox=\"0 0 18 18\" width=\"100%\">\n    <path class=\"icon-path\" d=\"M2,1.5H16v14H2Zm-.5,15h15A.5.5,0,0,0,17,16V1a.5.5,0,0,0-.5-.5H1.5A.5.5,0,0,0,1,1V16A.5.5,0,0,0,1.5,16.5Z\" />\n    <rect class=\"icon-path\" height=\"12\" rx=\"0.25\" width=\"4\" x=\"11\" y=\"2.5\" />\n      </svg>\n  ";
  }, []);
  return /*#__PURE__*/React__default['default'].createElement("span", {
    className: "Icon more-vertical",
    ref: root
  });
};

var PaddingRight = /*#__PURE__*/React__default['default'].memo(Icon$6, neverRerender$7);

var neverRerender$8 = function neverRerender() {
  return true;
};

var Icon$7 = function Icon() {
  var root = React.useRef(null);
  React.useEffect(function () {
    root.current.innerHTML = "\n    <svg height=\"100%\" viewBox=\"0 0 18 18\" width=\"100%\">\n    <path class=\"icon-path\" d=\"M2,15.5V1.5H16v14ZM17,16V1a.5.5,0,0,0-.5-.5H1.5A.5.5,0,0,0,1,1V16a.5.5,0,0,0,.5.5h15A.5.5,0,0,0,17,16Z\" />\n    <rect class=\"icon-path\" height=\"4\" rx=\"0.25\" width=\"12\" x=\"3\" y=\"2.5\" />\n      </svg>\n  ";
  }, []);
  return /*#__PURE__*/React__default['default'].createElement("span", {
    className: "Icon more-vertical",
    ref: root
  });
};

var PaddingTop = /*#__PURE__*/React__default['default'].memo(Icon$7, neverRerender$8);

var TearOut = function TearOut(_ref) {
  var className = _ref.className,
      props = _objectWithoutProperties(_ref, ["className"]);

  return /*#__PURE__*/React__default['default'].createElement(toolkit.Button, _extends({}, props, {
    className: classnames__default['default']('TearOutButton', className),
    title: "TearOut View",
    variant: "secondary"
  }), /*#__PURE__*/React__default['default'].createElement(toolkit.Icon, {
    accessibleText: "Tear out View",
    name: "tear-out"
  }));
};

var css_248z$2 = ".DropMenu {\n  margin-left: -50%;\n  margin-bottom: -50%;\n  background-color: white;\n  border: solid 1px var(--uitk-grey40);\n  display: inline-flex;\n  justify-content: center;\n  align-items: center;\n  padding: 3px;\n  border-radius: 3px;\n}\n\n.DropMenu.left,\n.DropMenu.right {\n  flex-direction: column;\n}\n\n.drop-menu-item {\n  width: 32px;\n  height: 32px;\n  background-color: var(--uitk-grey20);\n  border-bottom: solid 1px var(--uitk-grey40);\n  cursor: pointer;\n  margin: 0 1px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.drop-menu-item .Icon {\n  transform: scale(1.25);\n  transform-origin: center center;\n}\n\n.DropMenu.left .drop-menu-item .Icon {\n  transform: scale(1.25) rotate(180deg);\n  transform-origin: center center;\n}\n\n.DropMenu.top .drop-menu-item .Icon {\n  transform: scale(1.25) rotate(270deg);\n  transform-origin: center center;\n}\n\n.DropMenu.bottom .drop-menu-item .Icon {\n  transform: scale(1.25) rotate(90deg);\n  transform-origin: center center;\n}\n\n.drop-menu-item .icon-path {\n  fill: var(--uitk-grey70);\n}\n.drop-menu-item:hover .icon-path-2 {\n  fill: var(--uitk-blue500);\n}\n\n.drop-menu-item:last-child {\n  border-bottom: none;\n}\n";
styleInject(css_248z$2);

function computeMenuPosition(dropTarget) {
  var offsetTop = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var offsetLeft = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
  var pos = dropTarget.pos,
      box = dropTarget.clientRect;
  return pos.position.West ? [box.left - offsetLeft + 26, pos.y - offsetTop, "left"] : pos.position.South ? [pos.x - offsetLeft, box.bottom - offsetTop - 26, "bottom"] : pos.position.East ? [box.right - offsetLeft - 26, pos.y - offsetTop, "right"] :
  /* North | Header*/
  [pos.x - offsetLeft, box.top - offsetTop + 26, "top"];
}

var getIcon = function getIcon(i) {
  if (i === 0) {
    return /*#__PURE__*/React__default['default'].createElement(Column2A, null);
  } else {
    return /*#__PURE__*/React__default['default'].createElement(Column2B, null);
  }
};

var DropMenu = function DropMenu(_ref) {
  var className = _ref.className,
      dropTarget = _ref.dropTarget,
      onHover = _ref.onHover,
      orientation = _ref.orientation;
  var dropTargets = dropTarget.toArray(); // TODO we have all the information here to draw a mini target map
  // but maybe thats overkill ...

  return /*#__PURE__*/React__default['default'].createElement("div", {
    className: classnames__default['default']("DropMenu", className, orientation),
    onMouseLeave: function onMouseLeave() {
      return onHover(null);
    }
  }, dropTargets.map(function (target, i) {
    return /*#__PURE__*/React__default['default'].createElement("div", {
      key: i,
      className: "drop-menu-item",
      onMouseEnter: function onMouseEnter() {
        return onHover(target);
      }
    }, getIcon(i));
  }));
};

var expandFlex = function expandFlex(flex) {
  if (typeof flex === "number") {
    return {
      flexBasis: 0,
      flexGrow: 1,
      flexShrink: 1
    };
  } else {
    throw Error("\"no support yet for flex value ".concat(flex));
  }
};

function typeOf(element) {
  var type;

  if (element) {
    if (typeof element.type === "function" || _typeof(element.type) === "object") {
      var _element$type;

      type = element.type.displayName || element.type.name || ((_element$type = element.type) === null || _element$type === void 0 ? void 0 : _element$type.type.name);
    } else if (typeof element.type === "string") {
      type = element.type;
    } else if (element.constructor) {
      type = element.constructor.displayName;
    } else {
      debugger;
    }
  }

  return type;
}

var NO_PROPS = {};
var getProp = function getProp(component, propName) {
  var _component$props$prop;

  return (_component$props$prop = component === null || component === void 0 ? void 0 : component.props[propName]) !== null && _component$props$prop !== void 0 ? _component$props$prop : component === null || component === void 0 ? void 0 : component.props["data-".concat(propName)];
};
var getProps = function getProps(component) {
  return (component === null || component === void 0 ? void 0 : component.props) || component || NO_PROPS;
};

function followPathToParent(source, path) {
  var _getProps = getProps(source),
      dataPath = _getProps["data-path"],
      _getProps$path = _getProps.path,
      sourcePath = _getProps$path === void 0 ? dataPath : _getProps$path;

  if (path === "0") return null;
  if (path === sourcePath) return null;
  return followPath(source, path.replace(/.\d+$/, ""));
}
function containerOf(source, target) {
  if (target === source) {
    return null;
  } else {
    var _getProps2 = getProps(source),
        sourcePath = _getProps2.path,
        children = _getProps2.children;

    var _nextStep = nextStep(sourcePath, getProp(target, "path")),
        idx = _nextStep.idx,
        finalStep = _nextStep.finalStep;

    if (finalStep) {
      return source;
    } else if (children === undefined || children[idx] === undefined) {
      return null;
    } else {
      return containerOf(children[idx], target);
    }
  }
}
function followPath(source, path) {
  var _getProps3 = getProps(source),
      dataPath = _getProps3["data-path"],
      _getProps3$path = _getProps3.path,
      sourcePath = _getProps3$path === void 0 ? dataPath : _getProps3$path;

  if (path.indexOf(sourcePath) !== 0) {
    throw Error("pathUtils.followPath path ".concat(path, " is not within model.path ").concat(sourcePath));
  }

  var route = path.slice(sourcePath.length + 1);

  if (route === "") {
    return source;
  }

  var paths = route.split(".");
  var isElement = /*#__PURE__*/React__default['default'].isValidElement(source);

  for (var i = 0; i < paths.length; i++) {
    if (isElement && React__default['default'].Children.count(source.props.children) === 0 || !isElement && source.children === undefined) {
      console.log("model at 0.".concat(paths.slice(0, i).join("."), " has no children, so cannot fulfill rest of path ").concat(paths.slice(i).join(".")));
      return;
    }

    source = isElement ? source.props.children[paths[i]] : source.children[paths[i]];
    isElement = /*#__PURE__*/React__default['default'].isValidElement(source);

    if (source === undefined) {
      console.log("model at 0.".concat(paths.slice(0, i).join("."), " has no children that fulfill next step of path ").concat(paths.slice(i).join(".")));
      return;
    }
  }

  return source;
}
function nextLeaf(root, path) {
  var parent = followPathToParent(root, path);
  var pathIndices = path.split(".").map(function (idx) {
    return parseInt(idx, 10);
  });
  var lastIdx = pathIndices.pop();
  var children = parent.props.children;

  if (children.length - 1 > lastIdx) {
    return firstLeaf(children[lastIdx + 1]);
  } else {
    var parentIdx = pathIndices.pop();
    var nextParent = followPathToParent(root, getProp(parent, "path"));
    pathIndices = nextParent.props.path.split(".").map(function (idx) {
      return parseInt(idx, 10);
    });

    if (nextParent.props.children.length - 1 > parentIdx) {
      var _nextStep2 = nextParent.props.children[parentIdx + 1];

      if (isContainer(typeOf(_nextStep2))) {
        return firstLeaf(_nextStep2);
      } else {
        return _nextStep2;
      }
    }
  }

  return firstLeaf(root);
}
function previousLeaf(root, path) {
  var pathIndices = path.split(".").map(function (idx) {
    return parseInt(idx, 10);
  });
  var lastIdx = pathIndices.pop();
  var parent = followPathToParent(root, path);
  var children = parent.props.children;

  if (lastIdx > 0) {
    return lastLeaf(children[lastIdx - 1]);
  } else {
    while (pathIndices.length > 1) {
      lastIdx = pathIndices.pop();
      parent = followPathToParent(root, getProp(parent, "path")); // pathIndices = nextParent.props.path
      //   .split(".")
      //   .map((idx) => parseInt(idx, 10));

      if (lastIdx > 0) {
        var _nextStep3 = parent.props.children[lastIdx - 1];

        if (isContainer(typeOf(_nextStep3))) {
          return lastLeaf(_nextStep3);
        } else {
          return _nextStep3;
        }
      }
    }
  }

  return lastLeaf(root);
}

function firstLeaf(root) {
  if (isContainer(typeOf(root))) {
    var _ref = root.props || root,
        children = _ref.children;

    return firstLeaf(children[0]);
  } else {
    return root;
  }
}

function lastLeaf(root) {
  if (isContainer(typeOf(root))) {
    var _ref2 = root.props || root,
        children = _ref2.children;

    return lastLeaf(children[children.length - 1]);
  } else {
    return root;
  }
}

function nextStep(pathSoFar, targetPath) {
  if (pathSoFar === targetPath) {
    return {
      idx: -1,
      finalStep: true
    };
  }

  var regex = new RegExp("^".concat(pathSoFar, ".")); // check that pathSoFar startsWith targetPath and if not, throw

  var paths = targetPath.replace(regex, "").split(".").map(function (n) {
    return parseInt(n, 10);
  });
  return {
    idx: paths[0],
    finalStep: paths.length === 1
  };
}
function resetPath(model, path) {
  if (getProp(model, "path") === path) {
    return model;
  }

  var children = []; // React.Children.map rewrites keys, forEach does not

  React__default['default'].Children.forEach(model.props.children, function (child, i) {
    if (!getProp(child, "path")) {
      children.push(child);
    } else {
      children.push(resetPath(child, "".concat(path, ".").concat(i)));
    }
  });
  return /*#__PURE__*/React__default['default'].cloneElement(model, {
    path: path
  }, children);
}

var positionValues = {
  north: 1,
  east: 2,
  south: 4,
  west: 8,
  header: 16,
  centre: 32,
  absolute: 64
};
var Position = Object.freeze({
  North: _position("north"),
  East: _position("east"),
  South: _position("south"),
  West: _position("west"),
  Header: _position("header"),
  Centre: _position("centre"),
  Absolute: _position("absolute")
});

function _position(str) {
  return Object.freeze({
    offset: str === "north" || str === "west" ? 0 : str === "south" || str === "east" ? 1 : NaN,
    valueOf: function valueOf() {
      return positionValues[str];
    },
    toString: function toString() {
      return str;
    },
    North: str === "north",
    South: str === "south",
    East: str === "east",
    West: str === "west",
    Header: str === "header",
    Centre: str === "centre",
    NorthOrSouth: str === "north" || str === "south",
    EastOrWest: str === "east" || str === "west",
    NorthOrWest: str === "north" || str === "west",
    SouthOrEast: str === "east" || str === "south",
    Absolute: str === "absolute"
  });
}

var NORTH = Position.North,
    SOUTH = Position.South,
    EAST = Position.East,
    WEST = Position.West,
    HEADER = Position.Header,
    CENTRE = Position.Centre;
var BoxModel = /*#__PURE__*/function () {
  function BoxModel() {
    _classCallCheck(this, BoxModel);
  }

  _createClass(BoxModel, null, [{
    key: "measure",
    //TODO we should accept initial let,top offsets here
    value: function measure(model) {
      var measurements = {};
      measureRootComponent(model, measurements);
      return measurements;
    }
  }, {
    key: "smallestBoxContainingPoint",
    value: function smallestBoxContainingPoint(layout, measurements, x, y) {
      return _smallestBoxContainingPoint(layout, measurements, x, y);
    }
  }]);

  return BoxModel;
}();
function pointPositionWithinRect(x, y, rect) {
  var width = rect.right - rect.left;
  var height = rect.bottom - rect.top;
  var posX = x - rect.left;
  var posY = y - rect.top;
  var pctX = posX / width;
  var pctY = posY / height;
  var closeToTheEdge = 0;
  var position;
  var tab;
  var borderZone = 30;

  if (rect.header && containsPoint(rect.header, x, y)) {
    position = HEADER;

    if (rect.Stack) {
      var tabCount = rect.Stack.length;
      var targetTab = rect.Stack.find(function (_ref) {
        var left = _ref.left,
            right = _ref.right;
        return x >= left && x <= right;
      });

      if (targetTab) {
        tab = {
          left: targetTab.left,
          index: rect.Stack.indexOf(targetTab)
        };
      } else {
        var lastTab = rect.Stack[tabCount - 1];
        tab = {
          left: lastTab.right,
          index: tabCount
        };
      }
    } else {
      tab = {
        left: rect.left,
        index: -1
      };
    }
  } else {
    var w = width * 0.4;
    var h = height * 0.4;
    var centerBox = {
      left: rect.left + w,
      top: rect.top + h,
      right: rect.right - w,
      bottom: rect.bottom - h
    };

    if (containsPoint(centerBox, x, y)) {
      position = CENTRE;
    } else {
      var quadrant = (pctY < 0.5 ? "north" : "south") + (pctX < 0.5 ? "west" : "east");

      switch (quadrant) {
        case "northwest":
          position = pctX > pctY ? NORTH : WEST;
          break;

        case "northeast":
          position = 1 - pctX > pctY ? NORTH : EAST;
          break;

        case "southeast":
          position = pctX > pctY ? EAST : SOUTH;
          break;

        case "southwest":
          position = 1 - pctX > pctY ? WEST : SOUTH;
          break;
      }
    }
  } // Set closeToTheEdge even when we have already established that we are in a Header.
  // When we use position to walk the containment hierarchy, building the chain of
  // dropTargets, the Header loses significance after the first dropTarget, but
  // closeToTheEdge remains meaningful.


  {
    if (posX < borderZone) closeToTheEdge += 8;
    if (posX > width - borderZone) closeToTheEdge += 2;
    if (posY < borderZone) closeToTheEdge += 1;
    if (posY > height - borderZone) closeToTheEdge += 4;
  } // we might want to also know if we are in the center - this will be used to allow
  // stack default option


  return {
    position: position,
    x: x,
    y: y,
    pctX: pctX,
    pctY: pctY,
    closeToTheEdge: closeToTheEdge,
    tab: tab
  };
}

function measureRootComponent(rootComponent, measurements) {
  var _getProps = getProps(rootComponent),
      id = _getProps.id,
      _getProps$layoutId = _getProps.layoutId,
      layoutId = _getProps$layoutId === void 0 ? id : _getProps$layoutId,
      dataPath = _getProps["data-path"],
      _getProps$path = _getProps.path,
      path = _getProps$path === void 0 ? dataPath : _getProps$path;

  var type = typeOf(rootComponent);

  if (layoutId && path) {
    var _measureComponentDomE = measureComponentDomElement(rootComponent),
        _measureComponentDomE2 = _slicedToArray(_measureComponentDomE, 2),
        rect = _measureComponentDomE2[0],
        el = _measureComponentDomE2[1];

    measureComponent(rootComponent, rect, el, measurements);

    if (type !== "Stack" && isContainer(type)) {
      collectChildMeasurements(rootComponent, measurements);
    }
  }
}

function measureComponent(component, rect, el, measurements) {
  var _getProps2 = getProps(component),
      dataPath = _getProps2["data-path"],
      _getProps2$path = _getProps2.path,
      path = _getProps2$path === void 0 ? dataPath : _getProps2$path,
      header = _getProps2.header;

  measurements[path] = rect;
  var type = typeOf(component);

  if (header || type === "Stack") {
    var headerEl = el.querySelector(".Header");

    if (headerEl) {
      var _headerEl$getBounding = headerEl.getBoundingClientRect(),
          top = _headerEl$getBounding.top,
          left = _headerEl$getBounding.left,
          right = _headerEl$getBounding.right,
          bottom = _headerEl$getBounding.bottom;

      measurements[path].header = {
        top: top,
        left: left,
        right: right,
        bottom: bottom
      };

      if (type === "Stack") {
        measurements[path].Stack = Array.from(headerEl.querySelectorAll(".Tabstrip .Tab")).map(function (tab) {
          return tab.getBoundingClientRect();
        }).map(function (_ref2) {
          var left = _ref2.left,
              right = _ref2.right;
          return {
            left: left,
            right: right
          };
        });
      }
    }
  }

  return measurements[path];
}

function collectChildMeasurements(component, measurements) {
  var preX = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
  var posX = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0;
  var preY = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 0;
  var posY = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : 0;

  var _getProps3 = getProps(component),
      children = _getProps3.children,
      dataPath = _getProps3["data-path"],
      _getProps3$path = _getProps3.path,
      path = _getProps3$path === void 0 ? dataPath : _getProps3$path,
      style = _getProps3.style;

  var type = typeOf(component);
  var isFlexbox = type === "Flexbox";
  var isTower = isFlexbox && style.flexDirection === "column";
  var isTerrace = isFlexbox && style.flexDirection === "row";
  console.log("collect ChildMeasurements for ".concat(type)); // Collect all the measurements in first pass ...

  var childMeasurements = children.map(function (child) {
    var _measureComponentDomE3 = measureComponentDomElement(child),
        _measureComponentDomE4 = _slicedToArray(_measureComponentDomE3, 2),
        rect = _measureComponentDomE4[0],
        el = _measureComponentDomE4[1];

    return [_objectSpread2(_objectSpread2({}, rect), {}, {
      top: rect.top - preY,
      right: rect.right + posX,
      bottom: rect.bottom + posY,
      left: rect.left - preX
    }), el, child];
  }); // ...so that, in the second pass, we can identify gaps ...

  var expandedMeasurements = childMeasurements.map(function (_ref3, i, all) {
    var _ref4 = _slicedToArray(_ref3, 3),
        rect = _ref4[0],
        el = _ref4[1],
        child = _ref4[2];

    // generate a 'local' splitter adjustment for children adjacent to splitters
    var localPreX;
    var localPosX;
    var localPreY;
    var localPosY;
    var gapPre;
    var gapPos;
    var n = all.length - 1;

    if (isTerrace) {
      gapPre = i === 0 ? 0 : rect.left - all[i - 1][0].right;
      gapPos = i === n ? 0 : all[i + 1][0].left - rect.right; // we don't need to divide the leading gap, as half the gap will
      // already have been assigned to the preceeding child in the
      // previous loop iteration.

      localPreX = i === 0 ? 0 : gapPre === 0 ? 0 : gapPre;
      localPosX = i === n ? 0 : gapPos === 0 ? 0 : gapPos - gapPos / 2;
      rect.left -= localPreX;
      rect.right += localPosX;
      localPreY = preY;
      localPosY = posY;
    } else if (isTower) {
      gapPre = i === 0 ? 0 : rect.top - all[i - 1][0].bottom;
      gapPos = i === n ? 0 : all[i + 1][0].top - rect.bottom; // we don't need to divide the leading gap, as half the gap will
      // already have been assigned to the preceeding child in the
      // previous loop iteration.

      localPreY = i === 0 ? 0 : gapPre === 0 ? 0 : gapPre;
      localPosY = i === n ? 0 : gapPos === 0 ? 0 : gapPos - gapPos / 2;
      rect.top -= localPreY;
      rect.bottom += localPosY;
      localPreX = preX;
      localPosX = posX;
    }

    var componentMeasurements = measureComponent(child, rect, el, measurements);
    var childType = typeOf(child);

    if (childType !== "Stack" && isContainer(childType)) {
      collectChildMeasurements(child, measurements, localPreX, localPosX, localPreY, localPosY);
    }

    return componentMeasurements;
  });

  if (childMeasurements.length) {
    measurements[path].children = expandedMeasurements;
  }
}

function measureComponentDomElement(component) {
  var _getProps4 = getProps(component),
      id = _getProps4.id,
      _getProps4$layoutId = _getProps4.layoutId,
      layoutId = _getProps4$layoutId === void 0 ? id : _getProps4$layoutId;

  var el = document.getElementById(layoutId);

  if (!el) {
    throw Error("No DOM for ".concat(typeOf(component), " ").concat(layoutId));
  } // Note: height and width are not required for dropTarget identification, but
  // are used in sizing calculations on drop


  var _el$getBoundingClient = el.getBoundingClientRect(),
      top = _el$getBoundingClient.top,
      left = _el$getBoundingClient.left,
      right = _el$getBoundingClient.right,
      bottom = _el$getBoundingClient.bottom,
      height = _el$getBoundingClient.height,
      width = _el$getBoundingClient.width;

  return [{
    top: top,
    left: left,
    right: right,
    bottom: bottom,
    height: height,
    width: width
  }, el, component];
}

function _smallestBoxContainingPoint(component, measurements, x, y) {
  var _getProps5 = getProps(component),
      children = _getProps5.children,
      dataPath = _getProps5["data-path"],
      _getProps5$path = _getProps5.path,
      path = _getProps5$path === void 0 ? dataPath : _getProps5$path;

  var type = typeOf(component);
  var rect = measurements[path];
  if (!containsPoint(rect, x, y)) return null;

  if (!isContainer(type)) {
    return component;
  }

  if (rect.header && containsPoint(rect.header, x, y)) {
    return component;
  }

  var subLayout;

  for (var i = 0; i < children.length; i++) {
    if (type === "Stack" && component.props.active !== i) {
      continue;
    } // eslint-disable-next-line no-cond-assign


    if (subLayout = _smallestBoxContainingPoint(children[i], measurements, x, y)) {
      return subLayout;
    }
  }

  return component;
}

function containsPoint(rect, x, y) {
  if (rect) {
    return x >= rect.left && x < rect.right && y >= rect.top && y < rect.bottom;
  }
}

var isTabstrip = function isTabstrip(dropTarget) {
  return dropTarget.pos.tab && typeOf(dropTarget.component) === "Stack" && dropTarget.pos.position.Header;
};
var DropTarget = /*#__PURE__*/function () {
  function DropTarget(_ref) {
    var component = _ref.component,
        pos = _ref.pos,
        clientRect = _ref.clientRect,
        nextDropTarget = _ref.nextDropTarget;

    _classCallCheck(this, DropTarget);

    this.component = component;
    this.pos = pos;
    this.clientRect = clientRect;
    this.nextDropTarget = nextDropTarget;
    this.active = false;
  }

  _createClass(DropTarget, [{
    key: "targetTabRect",
    value: function targetTabRect(lineWidth) {
      var offsetTop = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
      var offsetLeft = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
      var _this$clientRect = this.clientRect,
          top = _this$clientRect.top,
          left = _this$clientRect.left,
          right = _this$clientRect.right,
          bottom = _this$clientRect.bottom,
          header = _this$clientRect.header,
          tab = this.pos.tab;
      var inset = 0;
      var gap = Math.round(lineWidth / 2) + inset;

      if (tab) {
        var t = Math.round(top - offsetTop);
        var l = Math.round(left - offsetLeft + gap);
        var r = Math.round(right - offsetLeft - gap);
        var b = Math.round(bottom - offsetTop - gap);
        var tabLeft = Math.round(tab.left - offsetLeft + gap);
        var tabWidth = 60;
        var tabHeight = header.bottom - header.top;
        return [l, t, r, b, tabLeft, tabWidth, tabHeight];
      } else {
        var rect = this.targetRect(lineWidth, offsetTop, offsetLeft);

        if (rect) {
          rect.push(0, 0, 0);
        }

        return rect;
      }
    }
  }, {
    key: "targetRect",
    value: function targetRect(lineWidth) {
      var offsetTop = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
      var offsetLeft = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
      var _this$pos = this.pos,
          width = _this$pos.width,
          height = _this$pos.height,
          position = _this$pos.position,
          rect = this.clientRect;
      var size = null;

      if (width) {
        size = {
          width: width
        };
      } else if (height) {
        size = {
          height: height
        };
      }

      var t = Math.round(rect.top - offsetTop);
      var l = Math.round(rect.left - offsetLeft);
      var r = Math.round(rect.right - offsetLeft);
      var b = Math.round(rect.bottom - offsetTop);
      var inset = 0;
      var gap = Math.round(lineWidth / 2) + inset;

      switch (position) {
        case Position.North:
        case Position.Header:
          {
            var halfHeight = Math.round((b - t) / 2);
            var sizeHeight = size && size.height ? size.height : 0;

            var _height = sizeHeight ? Math.min(halfHeight, Math.round(sizeHeight)) : halfHeight;

            return [l + gap, t + gap, r - gap, t + gap + _height];
          }

        case Position.West:
          {
            var halfWidth = Math.round((r - l) / 2);
            var sizeWidth = size && size.width ? size.width : 0;

            var _width = sizeWidth ? Math.min(halfWidth, Math.round(sizeWidth)) : halfWidth;

            return [l + gap, t + gap, l + gap + _width, b - gap];
          }

        case Position.East:
          {
            var _halfWidth = Math.round((r - l) / 2);

            var _sizeWidth = size && size.width ? size.width : 0;

            var _width2 = _sizeWidth ? Math.min(_halfWidth, Math.round(_sizeWidth)) : _halfWidth;

            return [r - gap - _width2, t + gap, r - gap, b - gap];
          }

        case Position.South:
          {
            var _halfHeight = Math.round((b - t) / 2);

            var _sizeHeight = size && size.height ? size.height : 0;

            var _height2 = _sizeHeight ? Math.min(_halfHeight, Math.round(_sizeHeight)) : _halfHeight;

            return [l + gap, b - gap - _height2, r - gap, b - gap];
          }

        case Position.Centre:
          {
            return [l + gap, t + gap, r - gap, b - gap];
          }

        default:
          console.warn("DropTarget does not recognize position ".concat(position));
          return null;
      }
    }
  }, {
    key: "activate",
    value: function activate() {
      this.active = true;
      return this;
    }
  }, {
    key: "toArray",
    value: function toArray() {
      var dropTarget = this;
      var dropTargets = [dropTarget]; // eslint-disable-next-line no-cond-assign

      while (dropTarget = dropTarget.nextDropTarget) {
        dropTargets.push(dropTarget);
      }

      return dropTargets;
    }
  }], [{
    key: "getActiveDropTarget",
    value: function getActiveDropTarget(dropTarget) {
      return dropTarget.active ? dropTarget : DropTarget.getActiveDropTarget(dropTarget.nextDropTarget);
    }
  }]);

  return DropTarget;
}(); // Initial entry to this method is always via the app (may be it should be *on* the app)

function identifyDropTarget(x, y, model, measurements) {
  var dropTarget = null; //onsole.log('Draggable.identifyDropTarget for component  ' + box.name + ' (' + box.nestedBoxes.length + ' children)') ;
  // this could return all boxes containing point, which would make getNextDropTarget almost free
  // Also, if we are over  atabstrip, it could include the actual tab

  var component = BoxModel.smallestBoxContainingPoint(model, measurements, x, y);

  if (component) {
    var _component$props = component.props,
        dataPath = _component$props["data-path"],
        _component$props$path = _component$props.path,
        path = _component$props$path === void 0 ? dataPath : _component$props$path;
    var clientRect = measurements[path];
    var pos = pointPositionWithinRect(x, y, clientRect); // console.log(
    //   `%c[DropTarget] identifyDropTarget target path ${path}
    //     position: ${JSON.stringify(pos)}
    //     measurements : ${JSON.stringify(measurements[path])}
    //     `,
    //   "color:cornflowerblue;font-weight:bold;"
    // );

    var nextDropTarget = getNextDropTarget(model, component, pos, measurements, x, y);
    dropTarget = new DropTarget({
      component: component,
      pos: pos,
      clientRect: clientRect,
      nextDropTarget: nextDropTarget
    }).activate(); // console.log('%c'+printDropTarget(dropTarget),'color:green');
  } //onsole.log(`\n${printDropTarget(dropTarget)}`);


  return dropTarget;
} // must be cleared when we end the drag
// layout never changes
// component never changes
// pos neve changes
// zone never changes
// measurements never change

function getNextDropTarget(layout, component, pos, measurements, x, y) {
  var north = positionValues.north,
      south = positionValues.south,
      east = positionValues.east,
      west = positionValues.west;
  var eastwest = east + west;
  var northsouth = north + south;
  return next();

  function next() {
    var container = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : containerOf(layout, component);

    if (pos.position.Header || pos.closeToTheEdge) {
      var nextDropTarget = false;

      while (container && container.path !== "0" && // TODO this should probably checj container root, not assume o
      positionedAtOuterContainerEdge(container, pos, component, measurements)) {
        // console.log(`next ${getProps(container).path}`);
        var _container$props = container.props,
            dataPath = _container$props["data-path"],
            _container$props$path = _container$props.path,
            path = _container$props$path === void 0 ? dataPath : _container$props$path;
        var clientRect = measurements[path];
        var containerPos = pointPositionWithinRect(x, y, clientRect); // if its a VBox and we're close to left or right ...

        if ((isVBox(container) || isTabbedContainer(container)) && pos.closeToTheEdge & eastwest) {
          nextDropTarget = true;
          containerPos.width = 120;
        } // if it's a HBox and we're close to top or bottom ...
        else if ((isHBox(container) || isTabbedContainer(container)) && (pos.position.Header || pos.closeToTheEdge & northsouth)) {
            nextDropTarget = true;
            containerPos.height = 120;
          }

        if (nextDropTarget) {
          if (containerPos.position.Header) {
            containerPos = _objectSpread2(_objectSpread2({}, containerPos), {}, {
              position: north
            });
          } // For each DropTarget, specify which drop operations are appropriate


          return new DropTarget({
            component: container,
            pos: containerPos,
            // <<<<  a local pos for each container
            clientRect: clientRect,
            nextDropTarget: next(containerOf(layout, container))
          });
        }

        container = containerOf(layout, container);
      }
    }
  }
}

function positionedAtOuterContainerEdge(containingComponent, _ref2, component, measurements) {
  var closeToTheEdge = _ref2.closeToTheEdge,
      position = _ref2.position;

  if (containingComponent.type === "DraggableLayout") {
    return false;
  }

  var _component$props2 = component.props,
      dataPath = _component$props2["data-path"],
      _component$props2$pat = _component$props2.path,
      componentPath = _component$props2$pat === void 0 ? dataPath : _component$props2$pat;
  var containingBox = measurements[containingComponent.props.path];
  var box = measurements[componentPath];
  var closeToTop = closeToTheEdge & positionValues.north;
  var closeToRight = closeToTheEdge & positionValues.east;
  var closeToBottom = closeToTheEdge & positionValues.south;
  var closeToLeft = closeToTheEdge & positionValues.west;
  if ((closeToTop || position.Header) && box.top === containingBox.top) return true;
  if (closeToRight && box.right === containingBox.right) return true;
  if (closeToBottom && box.bottom === containingBox.bottom) return true;
  if (closeToLeft && box.left === containingBox.left) return true;
  return false;
}

function isTabbedContainer(component) {
  return typeOf(component) === "Stack";
}

function isVBox(component) {
  return typeOf(component) === "Flexbox" && component.props.style.flexDirection === "column";
}

function isHBox(component) {
  return typeOf(component) === "Flexbox" && component.props.style.flexDirection === "row";
}

var css_248z$3 = "#sketchpad {\n  position: absolute;\n  top: 0;\n  left: 0;\n  border: 0;\n  padding: 0;\n  margin: 0;\n  background-color: rgba(0, 255, 0, 0.2);\n  visibility: hidden;\n  /*opacity : 0.5;*/\n  z-index: 102;\n}\n\n.drawing #sketchpad {\n  visibility: visible;\n}\n\n#sketchpad.sketching {\n  visibility: visible;\n}\n\n#drag-canvas {\n  visibility: hidden;\n  z-index: 1;\n  position: absolute;\n  top: 0px;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background-color: transparent;\n}\n\n.drawing #drag-canvas {\n  visibility: visible;\n}\n\npath.drop-target {\n  stroke: blue;\n  stroke-width: 4px;\n  fill: transparent;\n}\n\npath.drop-target.centre {\n  stroke: red;\n}\n";
styleInject(css_248z$3);

var _dropTarget = null;
var _multiDropOptions = false;
var _hoverDropTarget = null;

var onHoverDropTarget = function onHoverDropTarget(dropTarget) {
  return _hoverDropTarget = dropTarget;
};

function insertSVGRoot() {
  var root = document.getElementById("root");
  var container = document.createElement("div");
  container.id = "drag-canvas";
  container.innerHTML = '<svg width="100%" height="100%"></svg>';
  document.body.insertBefore(container, root);
}

var drawTabPath = function drawTabPath(_ref) {
  var _ref2 = _slicedToArray(_ref, 7),
      l = _ref2[0],
      t = _ref2[1],
      w = _ref2[2],
      h = _ref2[3],
      _ref2$ = _ref2[4],
      tl = _ref2$ === void 0 ? 0 : _ref2$,
      _ref2$2 = _ref2[5],
      tw = _ref2$2 === void 0 ? 0 : _ref2$2,
      _ref2$3 = _ref2[6],
      th = _ref2$3 === void 0 ? 0 : _ref2$3;

  return "M".concat(l, ",").concat(t + th, "l").concat(tl, ",0l0,-").concat(th, "l").concat(tw, ",0l0,").concat(th, "l").concat(w - (tl + tw), ",0l0,").concat(h - th, "l-").concat(w, ",0l0,-").concat(h - th);
};

var DropTargetCanvas = /*#__PURE__*/function () {
  function DropTargetCanvas() {
    _classCallCheck(this, DropTargetCanvas);

    insertSVGRoot();
  }

  _createClass(DropTargetCanvas, [{
    key: "prepare",
    value: function prepare(position) {
      // don't do this on body
      document.body.classList.add("drawing");
    }
  }, {
    key: "clear",
    value: function clear() {
      // don't do this on body
      _hoverDropTarget = null;
      document.body.classList.remove("drawing");
      PopupService.hidePopup();
    }
  }, {
    key: "draw",
    value: function draw(dropTarget) {
      var sameDropTarget = _dropTarget !== null && !isTabstrip(dropTarget) && _dropTarget.component === dropTarget.component && _dropTarget.pos.position === dropTarget.pos.position && _dropTarget.pos.closeToTheEdge === dropTarget.pos.closeToTheEdge;
      var wasMultiDrop = _multiDropOptions;

      if (_hoverDropTarget !== null) {
        this.drawTarget(_hoverDropTarget);
      } else {
        if (sameDropTarget === false) {
          _dropTarget = dropTarget;
          _multiDropOptions = dropTarget.nextDropTarget != null;
          console.log("multiDropOptions = ".concat(_multiDropOptions)); // if (isTabstrip(dropTarget)) {
          //   moveExistingTabs(dropTarget);
          // } else {
          //   clearShiftedTab();
          // }

          this.drawTarget(dropTarget);
        }

        if (_multiDropOptions) {
          var _computeMenuPosition = computeMenuPosition(dropTarget),
              _computeMenuPosition2 = _slicedToArray(_computeMenuPosition, 3),
              left = _computeMenuPosition2[0],
              top = _computeMenuPosition2[1],
              orientation = _computeMenuPosition2[2];

          if (!wasMultiDrop || !sameDropTarget) {
            var component = /*#__PURE__*/React__default['default'].createElement(DropMenu, {
              dropTarget: dropTarget,
              onHover: onHoverDropTarget,
              orientation: orientation
            });
            PopupService.showPopup({
              left: left,
              top: top,
              component: component
            });
          } else {
            PopupService.movePopupTo(left, top);
          }
        } else {
          PopupService.hidePopup();
        }
      }
    }
  }, {
    key: "drawTarget",
    value: function drawTarget(dropTarget) {
      var offsetTop = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
      var offsetLeft = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
      var lineWidth = 6;
      var targetRect = dropTarget.targetTabRect(lineWidth, offsetTop, offsetLeft);

      if (targetRect) {
        var _targetRect = _slicedToArray(targetRect, 7),
            l = _targetRect[0],
            t = _targetRect[1],
            r = _targetRect[2],
            b = _targetRect[3],
            tl = _targetRect[4],
            tw = _targetRect[5],
            th = _targetRect[6];

        var w = r - l;
        var h = b - t;
        var tabLeftOffset = tl === 0 ? 0 : tl - l;
        var data = [l, t, w, h, tabLeftOffset, tw, th];
        var svg = d3Selection.select("#drag-canvas > svg");
        var path = svg.selectAll("path.drop-target").data([data]);
        var d = drawTabPath(data);
        var className = classnames__default['default']("drop-target", dropTarget.pos.position.toString());
        path.transition().duration(200).attr("d", d).attr("class", className);
        path.enter().append("path").attr("class", className).attr("d", d);
      }
    }
  }, {
    key: "hoverDropTarget",
    get: function get() {
      return _hoverDropTarget;
    }
  }]);

  return DropTargetCanvas;
}();

var SCALE_FACTOR = 0.4;

var DragState = /*#__PURE__*/function () {
  function DragState(zone, mouseX, mouseY, measurements) {
    _classCallCheck(this, DragState);

    this.init(zone, mouseX, mouseY, measurements);
  }

  _createClass(DragState, [{
    key: "init",
    value: function init(zone, mouseX, mouseY, rect) {
      var x = rect.left,
          y = rect.top;
      var mousePosition = pointPositionWithinRect(mouseX, mouseY, rect); // We are applying a scale factor of 0.4 to the draggee. This is purely a visual
      // effect - the actual box size remains the original size. The 'leading' values
      // represent the difference between the visual scaled down box and the actual box.

      var scaleFactor = SCALE_FACTOR;
      var leadX = mousePosition.pctX * rect.width;
      var trailX = rect.width - leadX;
      var leadY = mousePosition.pctY * rect.height;
      var trailY = rect.height - leadY; // When we assign position to rect using css. positioning units are applied to the
      // unscaled shape, so we have to adjust values to take scaling into account.

      var scaledWidth = rect.width * scaleFactor,
          scaledHeight = rect.height * scaleFactor;
      var scaleDiff = 1 - scaleFactor;
      var leadXScaleDiff = leadX * scaleDiff;
      var leadYScaleDiff = leadY * scaleDiff;
      var trailXScaleDiff = trailX * scaleDiff;
      var trailYScaleDiff = trailY * scaleDiff;
      this.constraint = {
        zone: {
          x: {
            lo: zone.left,
            hi: zone.right
          },
          y: {
            lo: zone.top,
            hi: zone.bottom
          }
        },
        pos: {
          x: {
            lo:
            /* left */
            zone.left - leadXScaleDiff,
            hi:
            /* right */
            zone.right - rect.width + trailXScaleDiff
          },
          y: {
            lo:
            /* top */
            zone.top - leadYScaleDiff,
            hi:
            /* bottom */
            zone.bottom - rect.height + trailYScaleDiff
          }
        },
        mouse: {
          x: {
            lo:
            /* left */
            zone.left + scaledWidth * mousePosition.pctX,
            hi:
            /* right */
            zone.right - scaledWidth * (1 - mousePosition.pctX)
          },
          y: {
            lo:
            /* top */
            zone.top + scaledHeight * mousePosition.pctY,
            hi:
            /* bottom */
            zone.bottom - scaledHeight * (1 - mousePosition.pctY)
          }
        }
      }; //onsole.log(JSON.stringify(this.constraint,null,2));

      this.x = {
        pos: x,
        lo: false,
        hi: false,
        mousePos: mouseX,
        mousePct: mousePosition.pctX
      };
      this.y = {
        pos: y,
        lo: false,
        hi: false,
        mousePos: mouseY,
        mousePct: mousePosition.pctY
      };
    }
  }, {
    key: "outOfBounds",
    value: function outOfBounds() {
      return this.x.lo || this.x.hi || this.y.lo || this.y.hi;
    }
  }, {
    key: "inBounds",
    value: function inBounds() {
      return !this.outOfBounds();
    }
  }, {
    key: "dropX",
    value: function dropX() {
      return dropXY.call(this, "x");
    }
  }, {
    key: "dropY",
    value: function dropY() {
      return dropXY.call(this, "y");
    }
    /*
     *  diff = mouse movement, signed int
     *  xy = 'x' or 'y'
     */
    //todo, diff can be calculated in here

  }, {
    key: "update",
    value: function update(xy, mousePos) {
      var state = this[xy],
          mouseConstraint = this.constraint.mouse[xy],
          posConstraint = this.constraint.pos[xy],
          previousPos = state.pos;
      var diff = mousePos - state.mousePos; //xy==='x' && console.log(`update: state.lo=${state.lo}, mPos=${mousePos}, mC.lo=${mouseConstraint.lo}, prevPos=${previousPos}, diff=${diff} `  );

      if (diff < 0) {
        if (state.lo) ; else if (mousePos < mouseConstraint.lo) {
          state.lo = true;
          state.pos = posConstraint.lo;
        } else if (state.hi) {
          if (mousePos < mouseConstraint.hi) {
            state.hi = false;
            state.pos += diff;
          }
        } else {
          state.pos += diff;
        }
      } else if (diff > 0) {
        if (state.hi) ; else if (mousePos > mouseConstraint.hi) {
          state.hi = true;
          state.pos = posConstraint.hi;
        } else if (state.lo) {
          if (mousePos > mouseConstraint.lo) {
            state.lo = false;
            state.pos += diff;
          }
        } else {
          state.pos += diff;
        }
      }

      state.mousePos = mousePos;
      return previousPos !== state.pos;
    }
  }]);

  return DragState;
}();

function dropXY(dir) {
  var pos = this[dir],
      rect = this.constraint.zone[dir]; // why not do the rounding +/- 1 on the rect initially - this is all it is usef for

  return pos.lo ? Math.max(rect.lo, pos.mousePos) : pos.hi ? Math.min(pos.mousePos, Math.round(rect.hi) - 1) : pos.mousePos;
}

var _dragCallback;

var _dragStartX;

var _dragStartY;

var _dragContainer;

var _dragState;

var _dropTarget$1 = null;

var _measurements;

var _simpleDrag;

var _dragThreshold;

var DEFAULT_DRAG_THRESHOLD = 5;

var _dropTargetRenderer = new DropTargetCanvas();

var _dragContainers = [];
var SCALE_FACTOR$1 = 0.4;
var DragContainer = /*#__PURE__*/function () {
  function DragContainer() {
    _classCallCheck(this, DragContainer);
  }

  _createClass(DragContainer, null, [{
    key: "register",
    value: function register(path) {
      if (!_dragContainers.includes(path)) {
        // need to decide how to store these
        _dragContainers.push(path);
      }
    }
  }, {
    key: "unregister",
    value: function unregister()
    /*path*/
    {}
  }, {
    key: "paths",
    get: function get() {
      return _dragContainers;
    }
  }]);

  return DragContainer;
}();

function getDragContainer(rootContainer, dragContainerPath) {
  var pathToContainer = "";
  var maxSteps = 0;

  var _getProps = getProps(rootContainer),
      rootPath = _getProps.path; //TODO still to be determined how this will work


  if (rootPath === dragContainerPath) {
    return rootContainer;
  } else if (!dragContainerPath) {
    // If the model has no path (i.e. it hasn't been dragged out of the existing layout)
    // hiow do we decide the dragContainer to use (assuming there may be more than 1)
    pathToContainer = _dragContainers[0];
  } else {
    // find the longest container path that matches path (ie the smallest enclosing container);
    for (var i = 0; i < _dragContainers.length; i++) {
      if (dragContainerPath.indexOf(_dragContainers[i]) === 0) {
        var steps = _dragContainers[i].split(".").length;

        if (steps > maxSteps) {
          maxSteps = steps;
          pathToContainer = _dragContainers[i];
        }
      }
    }
  }

  return followPath(rootContainer, pathToContainer);
}

var Draggable = {
  handleMousedown: function handleMousedown(e, dragStartCallback) {
    var dragOptions = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    _dragCallback = dragStartCallback;
    _dragStartX = e.clientX;
    _dragStartY = e.clientY;
    _dragThreshold = dragOptions.dragThreshold === undefined ? DEFAULT_DRAG_THRESHOLD : dragOptions.dragThreshold;

    if (_dragThreshold === 0) {
      // maybe this should be -1
      _dragCallback(e, 0, 0);
    } else {
      window.addEventListener("mousemove", preDragMousemoveHandler, false);
      window.addEventListener("mouseup", preDragMouseupHandler, false);
    }

    e.preventDefault();
  },
  // called from handleDragStart (_dragCallback)
  initDrag: function initDrag(rootContainer, dragContainerPath, _ref, dragPos, dragHandler) {
    var top = _ref.top,
        left = _ref.left,
        right = _ref.right,
        bottom = _ref.bottom;
    _dragCallback = dragHandler;
    return _initDrag(rootContainer, dragContainerPath, {
      top: top,
      left: left,
      right: right,
      bottom: bottom
    }, dragPos);
  }
};

function preDragMousemoveHandler(e) {
  var x_diff = e.clientX - _dragStartX ;
  var y_diff = e.clientY - _dragStartY ;
  var mouseMoveDistance = Math.max(Math.abs(x_diff), Math.abs(y_diff)); // when we do finally move the draggee, we are going to 'jump' by the amount of the drag threshold, should we
  // attempt to animate this ?

  if (mouseMoveDistance > _dragThreshold) {
    window.removeEventListener("mousemove", preDragMousemoveHandler, false);
    window.removeEventListener("mouseup", preDragMouseupHandler, false);

    _dragCallback(e, x_diff, y_diff);
  }
}

function preDragMouseupHandler() {
  window.removeEventListener("mousemove", preDragMousemoveHandler, false);
  window.removeEventListener("mouseup", preDragMouseupHandler, false);
}

function _initDrag(rootContainer, dragContainerPath, dragRect, dragPos) {
  _dragContainer = getDragContainer(rootContainer, dragContainerPath);

  var _getProps2 = getProps(_dragContainer),
      dataPath = _getProps2["data-path"],
      _getProps2$path = _getProps2.path,
      path = _getProps2$path === void 0 ? dataPath : _getProps2$path;

  var start = window.performance.now();
  console.log("initDrag ".concat(path, " ").concat(dragContainerPath)); // translate the layout $position to drag-oriented co-ordinates, ignoring splitters

  _measurements = BoxModel.measure(_dragContainer);
  console.log({
    measurements: _measurements
  });
  var end = window.performance.now();
  console.log("[Draggable] measurements took ".concat(end - start, "ms"), _measurements);
  var dragZone = _measurements[path];
  _dragState = new DragState(dragZone, dragPos.x, dragPos.y, dragRect);
  var pctX = Math.round(_dragState.x.mousePct * 100);
  var pctY = Math.round(_dragState.y.mousePct * 100);
  window.addEventListener("mousemove", dragMousemoveHandler, false);
  window.addEventListener("mouseup", dragMouseupHandler, false);
  _simpleDrag = false;

  _dropTargetRenderer.prepare(dragZone);

  return {
    // scale factor should be applied in caller, not here
    transform: "scale(".concat(SCALE_FACTOR$1, ",").concat(SCALE_FACTOR$1, ")"),
    transformOrigin: pctX + "% " + pctY + "%"
  };
}

function dragMousemoveHandler(evt) {
  var x = evt.clientX;
  var y = evt.clientY;
  var dragState = _dragState;
  var currentDropTarget = _dropTarget$1;
  var dropTarget;
  var newX, newY;

  if (dragState.update("x", x)) {
    newX = dragState.x.pos;
  }

  if (dragState.update("y", y)) {
    newY = dragState.y.pos;
  }

  if (newX === undefined && newY === undefined) ; else {
    _dragCallback.drag(newX, newY);
  }

  if (_simpleDrag) {
    return;
  }

  if (dragState.inBounds()) {
    dropTarget = identifyDropTarget(x, y, _dragContainer, _measurements);
  } else {
    dropTarget = identifyDropTarget(dragState.dropX(), dragState.dropY(), _dragContainer, _measurements);
  } // did we have an existing droptarget which is no longer such ...


  if (currentDropTarget) {
    if (dropTarget == null || dropTarget.box !== currentDropTarget.box) {
      _dropTarget$1 = null;
    }
  }

  if (dropTarget) {
    _dropTargetRenderer.draw(dropTarget, x, y);

    _dropTarget$1 = dropTarget;
  }
}

function dragMouseupHandler(_evt) {
  onDragEnd();
}

function onDragEnd() {
  if (_dropTarget$1) {
    // why wouldn't the active dropTarget be the hover target - IT ISNT
    var dropTarget = _dropTargetRenderer.hoverDropTarget || DropTarget.getActiveDropTarget(_dropTarget$1);
    var path = dropTarget.component.props.path;
    var targetRect = _measurements[path];

    _dragCallback.drop(dropTarget, targetRect);

    _dropTarget$1 = null;
  } else {
    _dragCallback.drop({
      component: _dragContainer,
      pos: {
        position: Position.Absolute
      }
    });
  }

  _dragCallback = null;
  _dragContainer = null;

  _dropTargetRenderer.clear();

  window.removeEventListener("mousemove", dragMousemoveHandler, false);
  window.removeEventListener("mouseup", dragMouseupHandler, false);
}

var getManagedDimension = function getManagedDimension(style) {
  return style.flexDirection === "column" ? ["height", "width"] : ["width", "height"];
};
var theKidHasNoStyle = {};
var applyLayoutProps = function applyLayoutProps(component) {
  var _getChildLayoutProps = getChildLayoutProps(typeOf(component), component.props, "0"),
      _getChildLayoutProps2 = _slicedToArray(_getChildLayoutProps, 2),
      layoutProps = _getChildLayoutProps2[0],
      children = _getChildLayoutProps2[1];

  return /*#__PURE__*/React__default['default'].cloneElement(component, layoutProps, children);
};
var applyLayout = function applyLayout(type, props, previousLayout) {
  if (props.layout) {
    return layoutFromJson(props.layout, "0");
  } else {
    var _getChildLayoutProps3 = getChildLayoutProps(type, props, "0", undefined, previousLayout),
        _getChildLayoutProps4 = _slicedToArray(_getChildLayoutProps3, 2),
        layoutProps = _getChildLayoutProps4[0],
        children = _getChildLayoutProps4[1];

    return _objectSpread2(_objectSpread2(_objectSpread2({}, props), layoutProps), {}, {
      type: type,
      children: children
    });
  }
};

function getLayoutProps(type, props) {
  var _props$active;

  var path = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "0";
  var parentType = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : null;
  var previousLayout = arguments.length > 4 ? arguments[4] : undefined;

  var _getProps = getProps(previousLayout),
      _getProps$active = _getProps.active,
      prevActive = _getProps$active === void 0 ? 0 : _getProps$active,
      layoutId = _getProps.layoutId,
      dataPath = _getProps["data-path"],
      _getProps$path = _getProps.path,
      prevPath = _getProps$path === void 0 ? dataPath : _getProps$path,
      _getProps$id = _getProps.id,
      prevId = _getProps$id === void 0 ? layoutId : _getProps$id,
      prevStyle = _getProps.style; // console.log(
  //   `getLayoutProps "${path}" ${type} ["${prevPath}" ${typeOf(
  //     previousLayout
  //   )} ${prevId}]`
  // );


  var prevMatch = typeOf(previousLayout) === type && path === prevPath; // TODO is there anything else we can re-use from previousType ?

  var id = prevMatch ? prevId : nanoid.nanoid();
  var active = type === "Stack" ? (_props$active = props.active) !== null && _props$active !== void 0 ? _props$active : prevActive : undefined;
  var key = id; //TODO this might be wrong if client has updated style ?

  var style = prevMatch ? prevStyle : getStyle(type, props, parentType);
  return isLayoutComponent(type) ? {
    layoutId: id,
    key: key,
    path: path,
    style: style,
    type: type,
    active: active
  } : {
    id: id,
    key: key,
    style: style,
    "data-path": path
  };
}

function getChildLayoutProps(type, props, path, parentType, previousLayout) {
  var _previousLayout$child, _previousLayout$props;

  var layoutProps = getLayoutProps(type, props, path, parentType, previousLayout);
  var children = getLayoutChildren(type, props.children, path, (_previousLayout$child = previousLayout === null || previousLayout === void 0 ? void 0 : previousLayout.children) !== null && _previousLayout$child !== void 0 ? _previousLayout$child : previousLayout === null || previousLayout === void 0 ? void 0 : (_previousLayout$props = previousLayout.props) === null || _previousLayout$props === void 0 ? void 0 : _previousLayout$props.children);
  return [layoutProps, children];
}

function getLayoutChildren(type, children) {
  var path = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "0";
  var previousChildren = arguments.length > 3 ? arguments[3] : undefined;
  return isContainer(type) || isView(type) ? React__default['default'].Children.map(children, function (child, i) {
    var _getChildLayoutProps5 = getChildLayoutProps(typeOf(child), child.props, "".concat(path, ".").concat(i), type, previousChildren === null || previousChildren === void 0 ? void 0 : previousChildren[i]),
        _getChildLayoutProps6 = _slicedToArray(_getChildLayoutProps5, 2),
        layoutProps = _getChildLayoutProps6[0],
        children = _getChildLayoutProps6[1];

    return /*#__PURE__*/React__default['default'].cloneElement(child, layoutProps, children);
  }) : children;
}

var getStyle = function getStyle(type, props, parentType) {
  var _props$style = props.style,
      style = _props$style === void 0 ? theKidHasNoStyle : _props$style;

  if (type === "Flexbox") {
    style = _objectSpread2(_objectSpread2({
      flexDirection: props.column ? "column" : "row"
    }, style), {}, {
      display: "flex"
    });
  }

  if (style.flex) {
    var _style = style,
        flex = _style.flex,
        otherStyles = _objectWithoutProperties(_style, ["flex"]);

    style = _objectSpread2(_objectSpread2({}, otherStyles), expandFlex(flex));
  } else if (parentType === "Stack") {
    style = _objectSpread2(_objectSpread2({}, style), expandFlex(1));
  }

  return style;
};

function layoutFromJson(_ref, path) {
  var type = _ref.type,
      children = _ref.children,
      props = _ref.props;

  if (type === "DraggableLayout") {
    return layoutFromJson(children[0], "0");
  }

  var componentType = type.match(/^[a-z]/) ? type : ComponentRegistry[type];

  if (componentType === undefined) {
    throw Error("Unable to create component from JSON, unknown type ".concat(type));
  }

  var id = uuid();
  return /*#__PURE__*/React__default['default'].createElement(componentType, _objectSpread2(_objectSpread2({}, props), {}, {
    id: id,
    key: id,
    path: path
  }), children ? children.map(function (child, i) {
    return layoutFromJson(child, "".concat(path, ".").concat(i));
  }) : undefined);
}

var _handlers;
var MISSING_TYPE = undefined;

var MISSING_HANDLER = function MISSING_HANDLER(state, action) {
  console.warn("layoutActionHandlers. No handler for action.type ".concat(action.type));
  return state;
};

var MISSING_TYPE_HANDLER = function MISSING_TYPE_HANDLER(state) {
  console.warn("layoutActionHandlers. Invalid action:  missing attribute 'type'");
  return state;
};

var handlers = (_handlers = {}, _defineProperty(_handlers, Action.DRAG_STARTED, dragStart), _defineProperty(_handlers, Action.DRAG_DROP, dragDrop), _defineProperty(_handlers, Action.SPLITTER_RESIZE, splitterResize), _defineProperty(_handlers, Action.REMOVE, removeChild), _defineProperty(_handlers, Action.MAXIMIZE, setChildProps), _defineProperty(_handlers, Action.MINIMIZE, setChildProps), _defineProperty(_handlers, Action.RESTORE, setChildProps), _defineProperty(_handlers, Action.SWITCH_TAB, switchTab), _defineProperty(_handlers, MISSING_TYPE, MISSING_TYPE_HANDLER), _handlers);

var layoutReducer = function layoutReducer(state, action) {
  return (handlers[action.type] || MISSING_HANDLER)(state, action);
};

function switchTab(state, _ref) {
  var path = _ref.path,
      nextIdx = _ref.nextIdx;
  var target = followPath(state, path);
  var replacement;

  if ( /*#__PURE__*/React__default['default'].isValidElement(target)) {
    replacement = /*#__PURE__*/React__default['default'].cloneElement(target, {
      active: nextIdx
    });
  } else {
    replacement = _objectSpread2(_objectSpread2({}, target), {}, {
      active: nextIdx
    });
  }

  return swapChild(state, target, replacement);
}

function setChildProps(state, _ref2) {
  var path = _ref2.path,
      type = _ref2.type;
  var target = followPath(state, path);
  return swapChild(state, target, target, type);
}

function splitterResize(rootProps, _ref3) {
  var path = _ref3.path,
      sizes = _ref3.sizes;
  var target = followPath(rootProps, path);
  var targetIsRoot = target === rootProps;

  var _ref4 = targetIsRoot ? target : target.props,
      children = _ref4.children,
      style = _ref4.style;

  var replacementChildren = children.map(function (child, i) {
    var dim = style.flexDirection === 'column' ? 'height' : 'width';
    var _child$props$style = child.props.style,
        size = _child$props$style[dim],
        flexBasis = _child$props$style.flexBasis;

    if (size === sizes[i] || flexBasis === sizes[i]) {
      return child;
    } else {
      return /*#__PURE__*/React__default['default'].cloneElement(child, {
        style: applySize(child.props.style, dim, sizes[i])
      });
    }
  });
  var replacement = targetIsRoot ? _objectSpread2(_objectSpread2({}, target), {}, {
    children: replacementChildren
  }) : /*#__PURE__*/React__default['default'].cloneElement(target, null, replacementChildren);
  return swapChild(rootProps, target, replacement);
}
/**
 *  We will be passed a component to drag (with instructions)
 * OR a path, which indicates that a component within the layout
 * is to be extracted and dragged to a new position.
 */


function dragStart(model, _ref5) {
  var component = _ref5.component,
      dragContainerPath = _ref5.dragContainerPath,
      dragRect = _ref5.dragRect,
      dragPos = _ref5.dragPos,
      instructions = _ref5.instructions,
      path = _ref5.path;
  var dragContainer = followPath(model, dragContainerPath);
  var draggable = component || followPath(model, path);
  var dragContainerWithDrag = /*#__PURE__*/React__default['default'].isValidElement(dragContainer) ? /*#__PURE__*/React__default['default'].cloneElement(dragContainer, {
    drag: {
      dragRect: dragRect,
      dragPos: dragPos,
      dragPath: path,
      draggable: draggable
    }
  }) : _objectSpread2(_objectSpread2({}, dragContainer), {}, {
    drag: {
      dragRect: dragRect,
      dragPos: dragPos,
      dragPath: path,
      draggable: draggable
    }
  });
  var newRootProps = replaceChild(model, dragContainer, dragContainerWithDrag); // const newRootProps = {
  //   drag: { dragRect, dragPos, dragPath: path, draggable },
  //   ...model,
  // };

  if (instructions && instructions.DoNotRemove) {
    return newRootProps;
  } else {
    return _removeChild(newRootProps, draggable);
  }
}

function dragDrop(model, action) {
  var dragContainerPath = action.dragContainerPath,
      _action$dropTarget = action.dropTarget,
      target = _action$dropTarget.component,
      pos = _action$dropTarget.pos,
      targetRect = action.targetRect,
      targetPosition = action.targetPosition;
  var dragContainer = followPath(model, dragContainerPath);

  var _getProps = getProps(dragContainer),
      source = _getProps.drag.draggable;

  var dragContainerWithoutDrag = /*#__PURE__*/React__default['default'].isValidElement(dragContainer) ? /*#__PURE__*/React__default['default'].cloneElement(dragContainer, {
    drag: undefined
  }) : _objectSpread2(_objectSpread2({}, dragContainer), {}, {
    drag: undefined
  });
  var newModel = replaceChild(model, dragContainer, dragContainerWithoutDrag);

  if (pos.position.Header) {
    if (typeOf(target) === 'Stack') {
      var before, after;
      var tabIndex = pos.tab.index;

      if (pos.tab.index === -1 || tabIndex >= target.props.children.length) {
        after = target.props.children[target.props.children.length - 1].props.path;
      } else {
        before = target.props.children[tabIndex].props.path;
      }

      return insert(newModel, source, null, before, after);
    } else {
      return wrap(newModel, source, target, pos);
    }
  } else if (pos.position.Centre) {
    return replaceChild(newModel, target, source);
  } else {
    return dropLayoutIntoContainer(newModel, pos, source, target, targetPosition, targetRect);
  }
}

function applySize(style, dim, newSize) {
  var _objectSpread2$1;

  var hasSize = typeof style[dim] === 'number';
  var _style$flexShrink = style.flexShrink,
      flexShrink = _style$flexShrink === void 0 ? 1 : _style$flexShrink,
      _style$flexGrow = style.flexGrow,
      flexGrow = _style$flexGrow === void 0 ? 1 : _style$flexGrow;
  return _objectSpread2(_objectSpread2({}, style), {}, (_objectSpread2$1 = {}, _defineProperty(_objectSpread2$1, dim, hasSize ? newSize : dim === 'width' ? 'auto' : 0), _defineProperty(_objectSpread2$1, "flexBasis", hasSize ? 'auto' : newSize), _defineProperty(_objectSpread2$1, "flexShrink", flexShrink), _defineProperty(_objectSpread2$1, "flexGrow", flexGrow), _objectSpread2$1));
}

function replaceChild(model, child, replacement) {
  var _getProps2 = getProps(child),
      path = _getProps2.path,
      style = _getProps2.style;

  var newChild = /*#__PURE__*/React__default['default'].isValidElement(replacement) ? /*#__PURE__*/React__default['default'].cloneElement(replacement, {
    path: path,
    style: _objectSpread2(_objectSpread2({}, style), replacement.props.style)
  }) : _objectSpread2(_objectSpread2({}, replacement), {}, {
    path: path,
    style: _objectSpread2(_objectSpread2({}, style), replacement.style)
  });
  return swapChild(model, child, newChild);
}

function swapChild(model, child, replacement, op) {
  if (model === child) {
    return replacement;
  } else {
    if ( /*#__PURE__*/React__default['default'].isValidElement(model)) {
      var _nextStep = nextStep(getProp(model, 'path'), getProp(child, 'path')),
          idx = _nextStep.idx,
          finalStep = _nextStep.finalStep;

      var children = model.props.children.slice();

      if (finalStep) {
        if (!op) {
          children[idx] = replacement;
        } else if (op === Action.MINIMIZE) {
          children[idx] = minimize(model, children[idx]);
        } else if (op === Action.RESTORE) {
          children[idx] = restore(children[idx]);
        }
      } else {
        children[idx] = swapChild(children[idx], child, replacement, op);
      }

      return /*#__PURE__*/React__default['default'].cloneElement(model, null, children);
    } else {
      var _getProps3 = getProps(model),
          modelPath = _getProps3.path;

      var _nextStep2 = nextStep(modelPath, getProp(child, 'path')),
          _idx = _nextStep2.idx,
          _finalStep = _nextStep2.finalStep;

      var _children = model.children.slice();

      if (_finalStep) {
        _children[_idx] = replacement;
      } else {
        _children[_idx] = swapChild(_children[_idx], child, replacement, op);
      }

      return _objectSpread2(_objectSpread2({}, model), {}, {
        children: _children
      });
    }
  }
}

function minimize(parent, child) {
  // Right now, parent is always going to be a FLexbox, but might not always be the case
  var _getProps4 = getProps(parent),
      parentStyle = _getProps4.style;

  var _getProps5 = getProps(child),
      childStyle = _getProps5.style;

  var width = childStyle.width,
      height = childStyle.height,
      flexBasis = childStyle.flexBasis,
      flexShrink = childStyle.flexShrink,
      flexGrow = childStyle.flexGrow,
      rest = _objectWithoutProperties(childStyle, ["width", "height", "flexBasis", "flexShrink", "flexGrow"]);

  var restoreStyle = {
    width: width,
    height: height,
    flexBasis: flexBasis,
    flexShrink: flexShrink,
    flexGrow: flexGrow
  };

  var style = _objectSpread2(_objectSpread2({}, rest), {}, {
    flexBasis: 0,
    flexGrow: 0,
    flexShrink: 0
  });

  var collapsed = parentStyle.flexDirection === 'row' ? 'vertical' : parentStyle.flexDirection === 'column' ? 'horizontal' : false;

  if (collapsed) {
    return /*#__PURE__*/React__default['default'].cloneElement(child, {
      collapsed: collapsed,
      restoreStyle: restoreStyle,
      style: style
    });
  } else {
    return child;
  }
}

function restore(child) {
  // Right now, parent is always going to be a FLexbox, but might not always be the case
  var _getProps6 = getProps(child),
      childStyle = _getProps6.style,
      restoreStyle = _getProps6.restoreStyle;

  var rest = _objectWithoutProperties(childStyle, ["flexBasis", "flexShrink", "flexGrow"]);

  var style = _objectSpread2(_objectSpread2({}, rest), restoreStyle);

  return /*#__PURE__*/React__default['default'].cloneElement(child, {
    collapsed: false,
    style: style,
    restoreStyle: undefined
  });
}

function isFlexible(model) {
  return model.props.style.flexGrow > 0;
}

function canBeMadeFlexible(model) {
  var _model$props$style = model.props.style,
      width = _model$props$style.width,
      height = _model$props$style.height,
      flexGrow = _model$props$style.flexGrow;
  return flexGrow === 0 && typeof width !== 'number' && typeof height !== 'number';
}

function makeFlexible(children) {
  return children.map(function (child) {
    return canBeMadeFlexible(child) ? /*#__PURE__*/React__default['default'].cloneElement(child, {
      style: _objectSpread2(_objectSpread2({}, child.props.style), {}, {
        flexGrow: 1
      })
    }) : child;
  });
}

function removeChild(rootProps, _ref6) {
  var path = _ref6.path;
  var target = followPath(rootProps, path);
  return _removeChild(rootProps, target);
}

function _removeChild(model, child) {
  var _getProps7 = getProps(model),
      active = _getProps7.active,
      componentChildren = _getProps7.children,
      path = _getProps7.path;

  var _nextStep3 = nextStep(path, getProp(child, 'path')),
      idx = _nextStep3.idx,
      finalStep = _nextStep3.finalStep;

  var type = typeOf(model);
  var children = componentChildren.slice();

  if (finalStep) {
    children.splice(idx, 1);

    if (active !== undefined && active >= idx) {
      active = Math.max(0, active - 1);
    }

    if (children.length === 1 && type.match(/Flexbox|Stack/)) {
      return unwrap(model, children[0]);
    } // Not 100% sure we should do this, unless configured to


    if (!children.some(isFlexible) && children.some(canBeMadeFlexible)) {
      children = makeFlexible(children);
    }
  } else {
    children[idx] = _removeChild(children[idx], child);
  }

  children = children.map(function (child, i) {
    return resetPath(child, "".concat(path, ".").concat(i));
  });
  return /*#__PURE__*/React__default['default'].isValidElement(model) ? /*#__PURE__*/React__default['default'].cloneElement(model, {
    active: active
  }, children) : _objectSpread2(_objectSpread2({}, model), {}, {
    active: active,
    children: children
  });
}

function unwrap(state, child) {
  var type = typeOf(state);
  var _state$props = state.props,
      path = _state$props.path,
      drag = _state$props.drag,
      _state$props$style = _state$props.style,
      flexBasis = _state$props$style.flexBasis,
      flexGrow = _state$props$style.flexGrow,
      flexShrink = _state$props$style.flexShrink,
      width = _state$props$style.width,
      height = _state$props$style.height;
  var unwrappedChild = resetPath(child, path);

  if (path === '0.0') {
    unwrappedChild = /*#__PURE__*/React__default['default'].cloneElement(unwrappedChild, {
      drag: drag,
      style: _objectSpread2(_objectSpread2({}, child.props.style), {}, {
        width: width,
        height: height
      })
    });
  } else if (type === 'Flexbox') {
    var dim = state.props.style.flexDirection === 'column' ? 'height' : 'width';

    var _unwrappedChild$props = unwrappedChild.props.style,
        style = _objectWithoutProperties(_unwrappedChild$props, [dim].map(_toPropertyKey)); // Need to overwrite key


    unwrappedChild = /*#__PURE__*/React__default['default'].cloneElement(unwrappedChild, {
      // Need to assign key
      drag: drag,
      style: _objectSpread2(_objectSpread2({}, style), {}, {
        flexGrow: flexGrow,
        flexShrink: flexShrink,
        flexBasis: flexBasis,
        width: width,
        height: height
      })
    });
  }

  return unwrappedChild;
}

function dropLayoutIntoContainer(rootProps, pos, source, target, targetPosition, targetRect) {
  var targetPath = getProp(target, 'path'); // In a Draggable layout, 0.n is the top-level layout

  if (target.path === '0.0' || targetPath === '0.0') {
    return wrap(rootProps, source, target, pos);
  } else {
    var targetContainer = followPathToParent(rootProps, targetPath);

    if (absoluteDrop(target, pos.position)) {
      return insert(rootProps, source, targetPath, null, null, pos.width || pos.height);
    } else if (target === rootProps || isDraggableRoot(rootProps, target)) {
      // Can only be against the grain...
      if (withTheGrain(pos, target)) {
        throw Error('How the hell did we do this');
      }
    } else if (withTheGrain(pos, targetContainer)) {
      if (pos.position.SouthOrEast) {
        return insert(rootProps, source, null, null, targetPath, pos.width || pos.height, targetRect);
      } else {
        return insert(rootProps, source, null, targetPath, null, pos.width || pos.height, targetRect);
      }
    } else if (!withTheGrain(pos, targetContainer)) {
      return wrap(rootProps, source, target, pos);
    } else if (isContainer(targetContainer)) {
      return wrap(rootProps, source, target, pos);
    } else {
      console.log('no support right now for position = ' + pos.position);
    }
  }

  return rootProps;
}

function wrap(model, source, target, pos, targetRect) {
  var _getProps8 = getProps(model),
      modelPath = _getProps8.path,
      modelChildren = _getProps8.children;

  var path = getProp(target, 'path');

  var _nextStep4 = nextStep(modelPath, path),
      idx = _nextStep4.idx,
      finalStep = _nextStep4.finalStep;

  var children = modelChildren.slice();

  if (finalStep) {
    var _getLayoutSpec = getLayoutSpec(pos),
        type = _getLayoutSpec.type,
        flexDirection = _getLayoutSpec.flexDirection,
        showTabs = _getLayoutSpec.showTabs;

    var active = type === 'Stack' || pos.position.SouthOrEast ? 1 : 0;
    target = children[idx];
    var size = pos.width || pos.height;

    var style = _objectSpread2(_objectSpread2({}, target.props.style), {}, {
      flexDirection: flexDirection
    }); // This assumes flexBox ...


    var flexStyles = {
      flexBasis: 0,
      flexGrow: 1,
      flexShrink: 1,
      width: 'auto',
      height: 'auto'
    };
    var sourceStyle = size ? _objectSpread2(_objectSpread2({}, flexStyles), {}, {
      flexBasis: size,
      flexShrink: 0,
      flexGrow: 0
    }) : flexStyles;
    var targetFirst = pos.position.SouthOrEast || pos.position.Header;
    var nestedSource = /*#__PURE__*/React__default['default'].cloneElement(source, {
      resizeable: true,
      style: _objectSpread2(_objectSpread2({}, source.props.style), sourceStyle)
    });
    var nestedTarget = /*#__PURE__*/React__default['default'].cloneElement(target, {
      resizeable: true,
      // how do we decide this ?
      style: _objectSpread2(_objectSpread2({}, target.props.style), flexStyles)
    });
    var id = nanoid.nanoid();
    var wrapper = /*#__PURE__*/React__default['default'].createElement(ComponentRegistry[type], {
      active: active,
      dispatch: target.props.dispatch,
      layoutId: id,
      key: id,
      path: getProp(target, 'path'),
      // TODO we should be able to configure this in setDefaultLayoutProps
      splitterSize: type === 'Flexbox' && typeOf(model) === 'Flexbox' ? model.props.splitterSize : undefined,
      showTabs: showTabs,
      style: style,
      resizeable: target.props.resizeable
    }, targetFirst ? [resetPath(nestedTarget, "".concat(path, ".0")), resetPath(nestedSource, "".concat(path, ".1"))] : [resetPath(nestedSource, "".concat(path, ".0")), resetPath(nestedTarget, "".concat(path, ".1"))]);
    children.splice(idx, 1, wrapper);
  } else {
    children[idx] = wrap(children[idx], source, target, pos);
  }

  return /*#__PURE__*/React__default['default'].isValidElement(model) ? /*#__PURE__*/React__default['default'].cloneElement(model, null, children) : _objectSpread2(_objectSpread2({}, model), {}, {
    children: children
  });
}

function insert(component, source, into, before, after, size, targetRect) {
  var isElement = /*#__PURE__*/React__default['default'].isValidElement(component);

  var _ref7 = isElement ? component.props : component,
      componentActive = _ref7.active,
      path = _ref7.path,
      componentChildren = _ref7.children;

  var type = typeOf(component);
  var target = before || after || into;

  var _nextStep5 = nextStep(path, target),
      idx = _nextStep5.idx,
      finalStep = _nextStep5.finalStep;

  var children;
  var active; // One more step needed when we're inserting 'into' a container

  var oneMoreStepNeeded = finalStep && into && idx !== -1;

  if (finalStep && !oneMoreStepNeeded) {
    //TODO how do we identify splitter width
    //TODO checj reiizeable to make sure a splitter will be present
    var assignSizes = function assignSizes(rect, dim, size) {
      if (typeof size === 'number') {
        return [size, rect[dim] - size - 11];
      } else {
        var measurement = (targetRect[dim] - 11) / 2;
        return [measurement, measurement];
      }
    };

    var isFlexBox = type === 'Flexbox';

    var _getManagedDimension = getManagedDimension(component.props.style),
        _getManagedDimension2 = _slicedToArray(_getManagedDimension, 1),
        dim = _getManagedDimension2[0];

    children = componentChildren.reduce(function (arr, child, i) {
      if (idx === i) {
        if (isFlexBox) {
          var _assignSizes = assignSizes(targetRect, dim, size),
              _assignSizes2 = _slicedToArray(_assignSizes, 2),
              sourceMeasurement = _assignSizes2[0],
              childMeasurement = _assignSizes2[1]; // TODO if size is supplied, it must be respected


          source = assignFlexDimension(source, dim, sourceMeasurement);
          child = assignFlexDimension(child, dim, childMeasurement);
        } else {
          var _source$props$style = source.props.style,
              width = _source$props$style.width,
              height = _source$props$style.height,
              style = _objectWithoutProperties(_source$props$style, ["left", "top", "flex", "width", "height", "transform", "transformOrigin"]);

          var dimensions = source.props.resizeable ? {} : {
            width: width,
            height: height
          };
          source = /*#__PURE__*/React__default['default'].cloneElement(source, {
            style: _objectSpread2(_objectSpread2({}, style), dimensions)
          });
        }

        if (before) {
          arr.push(source, child);
        } else {
          arr.push(child, source);
        }
      } else {
        // arr.push(assignFlexDimension(child, dim, measurement));
        arr.push(child);
      }

      return arr;
    }, []);
    var insertedIdx = children.indexOf(source);
    active = type === 'Stack' ? insertedIdx : componentActive;
    children = children.map(function (child, i) {
      return i < insertedIdx ? child : resetPath(child, "".concat(path, ".").concat(i));
    });
  } else {
    children = componentChildren.slice();
    children[idx] = insert(children[idx], source, into, before, after, size, targetRect);
  }

  return isElement ? /*#__PURE__*/React__default['default'].cloneElement(component, _objectSpread2(_objectSpread2({}, component.props), {}, {
    active: active
  }), children) : _objectSpread2(_objectSpread2({}, component), {}, {
    active: active,
    children: children
  });
}

function assignFlexDimension(model, dim) {
  var _objectSpread3;

  var size = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
  var _model$props$style2 = model.props.style;
  _model$props$style2 = _model$props$style2 === void 0 ? {} : _model$props$style2;

  var flexBasis = _model$props$style2.flexBasis,
      height = _model$props$style2.height,
      width = _model$props$style2.width,
      otherStyles = _objectWithoutProperties(_model$props$style2, ["flex", "flexBasis", "height", "width"]);

  var _height$width = {
    height: height,
    width: width
  },
      currentSize = _height$width[dim];

  if (flexBasis === 'auto' && currentSize === size || flexBasis === size) {
    return model;
  }

  var style = _objectSpread2(_objectSpread2({}, otherStyles), {}, (_objectSpread3 = {}, _defineProperty(_objectSpread3, dim, 'auto'), _defineProperty(_objectSpread3, "flexBasis", size), _defineProperty(_objectSpread3, "flexGrow", 0), _defineProperty(_objectSpread3, "flexShrink", 0), _objectSpread3));

  return /*#__PURE__*/React__default['default'].cloneElement(model, {
    style: style
  });
} // TODO do we still need surface


function absoluteDrop(target, position) {
  return typeOf(target) === 'Surface' && position.Absolute;
} //TODO how are we going to allow dgar containers to be defined ?


function isDraggableRoot(layout, component) {
  if (getProp(component, 'path') === '0') {
    return true;
  }

  var container = containerOf(layout, component);

  if (container) {
    return typeOf(container) === 'App';
  } else {
    debugger;
  }
} // Note: withTheGrain is not the negative of againstTheGrain - the difference lies in the
// handling of non-Flexible containers, the response for which is always false;


function withTheGrain(pos, container) {
  return pos.position.NorthOrSouth ? isTower(container) : pos.position.EastOrWest ? isTerrace(container) : false;
}

function isTower(model) {
  return typeOf(model) === 'Flexbox' && model.props.style.flexDirection === 'column';
}

function isTerrace(model) {
  return typeOf(model) === 'Flexbox' && model.props.style.flexDirection !== 'column';
} // maybe in layout-json ?


function getLayoutSpec(pos) {
  var type, flexDirection, showTabs;

  if (pos.position.Header) {
    type = 'Stack';
    flexDirection = 'column';
    showTabs = true;
  } else {
    type = 'Flexbox';

    if (pos.position.EastOrWest) {
      flexDirection = 'row';
    } else {
      flexDirection = 'column';
    }
  }

  return {
    type: type,
    flexDirection: flexDirection,
    showTabs: showTabs
  };
}

var NO_CONTEXT = {
  dispatch: null
};
var LayoutContext = /*#__PURE__*/React__default['default'].createContext(NO_CONTEXT);
var useLayoutDispatch = function useLayoutDispatch() {
  var _context$dispatch;

  var context = React.useContext(LayoutContext);
  return (_context$dispatch = context === null || context === void 0 ? void 0 : context.dispatch) !== null && _context$dispatch !== void 0 ? _context$dispatch : null;
};
var useLayoutContext = function useLayoutContext() {
  return React.useContext(LayoutContext);
};

function getNextTarget(root, _ref) {
  var type = _ref.type,
      path = _ref.path,
      focusVisible = _ref.focusVisible,
      index = _ref.index;

  if (type === 'View') {
    if (focusVisible) {
      return nextLeaf(root, path);
    } else {
      return followPath(root, path);
    }
  } else {
    return nextLeaf(root, "".concat(path, ".").concat(index));
  }
}

function getPrevTarget(root, _ref2) {
  var type = _ref2.type,
      path = _ref2.path,
      focusVisible = _ref2.focusVisible,
      index = _ref2.index;

  if (type === 'View') {
    if (focusVisible) {
      return previousLeaf(root, path);
    } else {
      return followPath(root, path);
    }
  } else {
    return previousLeaf(root, "".concat(path, ".").concat(index));
  }
}

function focusElement(root, path) {
  var _followPath = followPath(root, path),
      _followPath$props = _followPath.props,
      id = _followPath$props.id,
      _followPath$props$lay = _followPath$props.layoutId,
      layoutId = _followPath$props$lay === void 0 ? id : _followPath$props$lay;

  var el = document.getElementById(layoutId);
  el.focus();
}

function addFocusVisible(root, path) {
  var _followPath2 = followPath(root, path),
      _followPath2$props = _followPath2.props,
      id = _followPath2$props.id,
      _followPath2$props$la = _followPath2$props.layoutId,
      layoutId = _followPath2$props$la === void 0 ? id : _followPath2$props$la;

  var el = document.getElementById(layoutId);
  el.classList.add('focus-visible');
}

function removeFocusVisible(root, path) {
  var _followPath3 = followPath(root, path),
      _followPath3$props = _followPath3.props,
      id = _followPath3$props.id,
      _followPath3$props$la = _followPath3$props.layoutId,
      layoutId = _followPath3$props$la === void 0 ? id : _followPath3$props$la;

  var el = document.getElementById(layoutId);
  el.classList.remove('focus-visible');
}

function useLayoutNavigation(layoutType, props, layoutRef, stateRef) {
  var dispatch = useLayoutDispatch();
  var isRoot = dispatch === null;
  var withFocus = React.useRef(null);
  var navHandler = React.useCallback(function (e) {
    if (e.key === 'F6') {
      var _withFocus$current, _withFocus$current2;

      var target = e.shiftKey ? getPrevTarget(stateRef.current, withFocus.current) : getNextTarget(stateRef.current, withFocus.current);

      if (((_withFocus$current = withFocus.current) === null || _withFocus$current === void 0 ? void 0 : _withFocus$current.type) === 'View' && (_withFocus$current2 = withFocus.current) !== null && _withFocus$current2 !== void 0 && _withFocus$current2.focusVisible) {
        removeFocusVisible(stateRef.current, withFocus.current.path);
      }

      if (target) {
        var _withFocus$current3;

        var _target$props = target.props,
            dataPath = _target$props['data-path'],
            _target$props$path = _target$props.path,
            path = _target$props$path === void 0 ? dataPath : _target$props$path;

        if (path === ((_withFocus$current3 = withFocus.current) === null || _withFocus$current3 === void 0 ? void 0 : _withFocus$current3.path)) {
          withFocus.current.focusVisible = true;
          addFocusVisible(stateRef.current, withFocus.current.path);
        } else {
          withFocus.current = {
            type: 'View',
            path: path,
            focusing: true
          };
          focusElement(stateRef.current, path);
        }
      }
    }
  }, []);
  React.useEffect(function () {
    function onFocus(e) {
      dispatch({
        type: Action.FOCUS,
        path: props.path
      });
    }

    function onBlur(e) {
      dispatch({
        type: Action.BLUR,
        path: props.path,
        relatedTarget: e.relatedTarget
      });
    }

    var layoutEl = layoutRef.current;

    if (layoutType === 'View') {
      layoutEl.addEventListener('blur', onBlur, true);
      layoutEl.addEventListener('focus', onFocus, true);
    }

    return function () {
      if (layoutType === 'View') {
        layoutEl.removeEventListener('blur', onBlur, true);
        layoutEl.removeEventListener('focus', onFocus, true);
      }
    };
  }, [dispatch, layoutRef, layoutType, props]);
  var dispatcher = isRoot ? function (action) {
    if (action.type === Action.FOCUS) {
      var _withFocus$current4, _withFocus$current5, _withFocus$current6;

      if (((_withFocus$current4 = withFocus.current) === null || _withFocus$current4 === void 0 ? void 0 : _withFocus$current4.path) !== action.path) {
        if (withFocus.current === null) {
          window.addEventListener('keyup', navHandler);
        } else if (withFocus.current.focusVisible) {
          removeFocusVisible(stateRef.current, withFocus.current.path);
        }

        withFocus.current = {
          type: 'View',
          path: action.path
        };
      } else if ((_withFocus$current5 = withFocus.current) !== null && _withFocus$current5 !== void 0 && _withFocus$current5.focusVisible) {
        removeFocusVisible(stateRef.current, withFocus.current.path);
        withFocus.current.focusVisible = false;
      } else if ((_withFocus$current6 = withFocus.current) !== null && _withFocus$current6 !== void 0 && _withFocus$current6.focusing) {
        withFocus.current.focusVisible = true;
        addFocusVisible(stateRef.current, withFocus.current.path);
      }

      return true;
    } else if (action.type === Action.BLUR || action.type === Action.BLUR_SPLITTER) {
      if (!layoutRef.current.contains(action.relatedTarget)) {
        var _withFocus$current7;

        if ((_withFocus$current7 = withFocus.current) !== null && _withFocus$current7 !== void 0 && _withFocus$current7.focusVisible) {
          var _withFocus$current8;

          removeFocusVisible(stateRef.current, (_withFocus$current8 = withFocus.current) === null || _withFocus$current8 === void 0 ? void 0 : _withFocus$current8.path);
        }

        withFocus.current = null;
        window.removeEventListener('keyup', navHandler);
      }

      return true;
    } else if (action.type === Action.FOCUS_SPLITTER) {
      var _withFocus$current9;

      if (((_withFocus$current9 = withFocus.current) === null || _withFocus$current9 === void 0 ? void 0 : _withFocus$current9.type) === 'View') {
        var _withFocus$current10;

        removeFocusVisible(stateRef.current, (_withFocus$current10 = withFocus.current) === null || _withFocus$current10 === void 0 ? void 0 : _withFocus$current10.path);
      }

      withFocus.current = {
        type: 'Splitter',
        path: action.path,
        index: action.index
      };
      return true;
    } else {
      // return customDispatcher && customDispatcher(action);
      return false;
    }
  } : undefined; // Navigation is only handled at root layout

  return dispatcher;
}

/**
 * Root layout node will never receive dispatch. It may receive a layoutModel,
 * in which case UI will be built from model. Only root stores layoutModel in
 * state and only root updates layoutModel. Non-root layout nodes always return
 * layoutModel from props. Root node, if seeded with layoutModel stores this in
 * state and subsequently manages layoutModel in state.
 */

var useLayout = function useLayout(layoutType, props) {
  var dispatch = useLayoutDispatch();
  var isRoot = dispatch === null;
  var ref = React.useRef(null); // Only the root layout actually stores state here

  var state = React.useRef(undefined);
  var children = React.useRef(null); // AKA forceRefresh

  var _useState = React.useState(0),
      _useState2 = _slicedToArray(_useState, 2),
      setState = _useState2[1];

  var layout = React.useRef(props.layout);
  var navigationDispatcher = useLayoutNavigation(layoutType, props, ref, state);
  var dispatchLayoutAction = React.useRef(dispatch || function (action) {
    // A custom dispatcher should return true to indicate that it has handled this action.
    // A custom dispatcher alone will not refresh the layout state, it must ultimately
    // dispatch a  layout action that will be handled below.It can be used to defer an action
    // that has async pre-requisites or initiate an operation that may or may not progress
    // to actual layour re-render e.g layout drag drop.
    if (navigationDispatcher && navigationDispatcher(action)) {
      return;
    }

    console.log("useLayout (".concat(layoutType, ") about to reduce ").concat(action.type, " ").concat(action.path));
    var nextState = layoutReducer(state.current, action);

    if (nextState !== state) {
      state.current = nextState;
      setState(function (c) {
        return c + 1;
      });
    }
  }); // Detect dynamic layout reset from serialized layout

  React.useEffect(function () {
    if (props.layout !== layout.current) {
      state.current = applyLayout(layoutType, props);
      setState(function (c) {
        return c + 1;
      });
      layout.current = props.layout;
    }
  }, [layoutType, props]);

  if (isRoot && (state.current === undefined || children.current !== props.children)) {
    // console.log(
    //   `LAYOUT ROOT COMPONENT (${layoutType})_____ (useLayout regenerated layout structure)`
    // );
    children.current = props.children; // TODO should be a call to the reducer

    state.current = applyLayout(layoutType, props, state.current); //console.log(state.current);
  }

  var layoutProps = isRoot ? state.current : props;
  return [layoutProps, ref, dispatchLayoutAction.current, isRoot];
};

var css_248z$4 = ".DraggableLayout {\n  display: inline-block;\n  outline: none;\n}\n";
styleInject(css_248z$4);

var EMPTY_OBJECT = {}; // We need to add props to restrict drag behaviour to, for example, popups only

var DraggableLayout = function DraggableLayout(inputProps) {
  var _useLayout = useLayout('DraggableLayout', inputProps),
      _useLayout2 = _slicedToArray(_useLayout, 3),
      props = _useLayout2[0],
      ref = _useLayout2[1],
      layoutDispatch = _useLayout2[2];

  var prepareToDrag = React.useCallback(function (_ref, evt, xDiff, yDiff) {
    var component = _ref.component,
        dragRect = _ref.dragRect,
        _ref$instructions = _ref.instructions,
        instructions = _ref$instructions === void 0 ? EMPTY_OBJECT : _ref$instructions,
        path = _ref.path;
    var dragPos = {
      x: evt.clientX,
      y: evt.clientY
    }; // we need to wait for this to take effect before we continue with the drag

    console.log("dispatch drag started");
    layoutDispatch({
      type: Action.DRAG_STARTED,
      path: path,
      dragContainerPath: props.path,
      dragRect: dragRect,
      dragPos: dragPos,
      component: component,
      instructions: instructions
    });
  }, [layoutDispatch]);
  var customDispatcher = React.useCallback(function (action) {
    if (action.type === Action.DRAG_START) {
      var path = action.path;

      if (DragContainer.paths.length === 0) {
        DragContainer.register('0');
      } else if (path !== '*') {
        var paths = DragContainer.paths;

        if (!paths.some(function (p) {
          return path.startsWith(p);
        })) {
          return;
        }
      }

      var evt = action.evt,
          options = _objectWithoutProperties(action, ["evt"]);

      Draggable.handleMousedown(evt, prepareToDrag.bind(null, options), options.instructions);
    } else {
      layoutDispatch(action);
    }
  }, [prepareToDrag]);
  var classNameProp = props.className,
      drag = props.drag,
      layoutId = props.layoutId,
      style = props.style;

  if (props !== null && props !== void 0 && props.dropTarget) {
    var _props$children$0$pro = props.children[0].props,
        dataPath = _props$children$0$pro['data-path'],
        _props$children$0$pro2 = _props$children$0$pro.path,
        dragContainerPath = _props$children$0$pro2 === void 0 ? dataPath : _props$children$0$pro2;
    console.log("this container is a draggable root 2) ".concat(props.path, " register child path ").concat(dragContainerPath));
    DragContainer.register(dragContainerPath);
  }

  var _useState = React.useState(-1.0),
      _useState2 = _slicedToArray(_useState, 2),
      setDrag = _useState2[1];

  var dragOperation = React.useRef(null);
  var handleDrop = React.useCallback(function (dropTarget, targetRect) {
    layoutDispatch({
      type: Action.DRAG_DROP,
      dragContainerPath: props.path,
      dropTarget: dropTarget,
      targetRect: targetRect,
      targetPosition: dragOperation.current.position
    });
    dragOperation.current = null;
    setDrag(-1.0);
  }, [layoutDispatch, drag]);
  var dragStart = React.useCallback(function (draggable, dragRect, dragPos, dragPath, instructions) {
    var top = dragRect.top,
        left = dragRect.left; // note: by passing null as dragContainer path, we are relying on registered DragContainer. How do we allow an
    // override for this ?

    var dragTransform = Draggable.initDrag(props, null, dragRect, dragPos, {
      drag: handleDrag,
      drop: handleDrop
    });
    dragOperation.current = {
      draggable: draggable,
      dragRect: dragRect,
      dragTransform: dragTransform,
      position: {
        left: left,
        top: top
      }
    };
  }, [handleDrop, props]);
  React.useEffect(function () {
    if (drag) {
      var dragRect = drag.dragRect,
          dragPos = drag.dragPos,
          dragPath = drag.dragPath,
          instructions = drag.instructions,
          draggable = drag.draggable;
      dragStart(draggable, dragRect, dragPos, dragPath, instructions);
      setDrag(0.0);
    }
  }, [drag]);

  function handleDrag(x, y) {
    var position = dragOperation.current.position;
    var left = typeof x === 'number' ? x : position.left;
    var top = typeof y === 'number' ? y : position.top;

    if (left !== position.left || top !== position.top) {
      dragOperation.current.position.left = left;
      dragOperation.current.position.top = top;
      setDrag(parseFloat("".concat(left, ".").concat(top)));
    }
  }

  var dragComponent = undefined;

  if (dragOperation.current) {
    var _dragOperation$curren = dragOperation.current,
        draggable = _dragOperation$curren.draggable,
        dragRect = _dragOperation$curren.dragRect,
        dragTransform = _dragOperation$curren.dragTransform,
        position = _dragOperation$curren.position;
    dragComponent = /*#__PURE__*/React__default['default'].cloneElement(draggable, {
      className: 'dragging',
      style: _objectSpread2(_objectSpread2({
        backgroundColor: 'white',
        position: 'absolute',
        width: dragRect.width,
        height: dragRect.height
      }, position), dragTransform)
    });
  }

  var className = classnames__default['default']('DraggableLayout', classNameProp);
  return /*#__PURE__*/React__default['default'].createElement(LayoutContext.Provider, {
    value: {
      dispatch: customDispatcher
    }
  }, /*#__PURE__*/React__default['default'].createElement("div", {
    className: className,
    id: layoutId,
    ref: ref,
    style: style
  }, props.children || props, dragComponent));
};
registerComponent('DraggableLayout', DraggableLayout, 'container');

var css_248z$5 = ".Splitter {\n  --splitter-size: 3px;\n  --splitter-border-width: 4px;\n  --splitter-border-style: none;\n  --splitter-border-color: white;\n\n  align-items: center;\n  background-color: var(--uitk-grey60);\n  border-color: var(--splitter-border-color);\n  border-style: var(--splitter-border-style);\n  box-sizing: border-box;\n  display: flex;\n  justify-content: center;\n  position: relative;\n  outline: none;\n  z-index: 1;\n}\n\n.Splitter:hover {\n  background-color: var(--uitk-grey40);\n}\n.active.Splitter {\n  background-color: var(--uitk-blue500);\n}\n\n.Splitter.column {\n  cursor: ns-resize;\n  height: var(--splitter-size);\n  border-width: var(--splitter-border-width) 0;\n}\n\n.Splitter:not(.column) {\n  cursor: ew-resize;\n  width: var(--splitter-size);\n  border-width: 0 var(--splitter-border-width);\n}\n\n.Splitter:before {\n  border: none;\n  border-radius: 0;\n  content: '';\n  display: block;\n  padding: 0;\n}\n\n.Splitter .grab-zone {\n  position: absolute;\n  background-color: rgba(255, 0, 0, 0.01);\n  cursor: inherit;\n}\n\n.Splitter.column .grab-zone {\n  left: 0;\n  right: 0;\n  top: -5px;\n  bottom: -5px;\n}\n\n.Splitter:not(column) .grab-zone {\n  left: -5px;\n  right: -5px;\n  top: 0;\n  bottom: 0;\n}\n\n.Splitter:not(.column):before {\n  width: 1px;\n  height: 10px;\n  background: linear-gradient(\n    to bottom,\n    var(--uitk-grey900) 10%,\n    transparent 10%,\n    transparent 30%,\n    var(--uitk-grey900) 30%,\n    var(--uitk-grey900) 40%,\n    transparent 40%,\n    transparent 60%,\n    var(--uitk-grey900) 60%,\n    var(--uitk-grey900) 70%,\n    transparent 70%,\n    transparent 90%,\n    var(--uitk-grey900) 90%\n  );\n}\n\n.active.Splitter.column:before {\n  background: linear-gradient(\n    to right,\n    #ffffff 10%,\n    transparent 10%,\n    transparent 30%,\n    #ffffff 30%,\n    #ffffff 40%,\n    transparent 40%,\n    transparent 60%,\n    #ffffff 60%,\n    #ffffff 70%,\n    transparent 70%,\n    transparent 90%,\n    #ffffff 90%\n  );\n}\n\n.active.Splitter:not(.column):before {\n  background: linear-gradient(\n    to bottom,\n    #ffffff 10%,\n    transparent 10%,\n    transparent 30%,\n    #ffffff 30%,\n    #ffffff 40%,\n    transparent 40%,\n    transparent 60%,\n    #ffffff 60%,\n    #ffffff 70%,\n    transparent 70%,\n    transparent 90%,\n    #ffffff 90%\n  );\n}\n\n.Splitter.column:before {\n  width: 10px;\n  height: 1px;\n  background: linear-gradient(\n    to right,\n    var(--uitk-grey900) 10%,\n    transparent 10%,\n    transparent 30%,\n    var(--uitk-grey900) 30%,\n    var(--uitk-grey900) 40%,\n    transparent 40%,\n    transparent 60%,\n    var(--uitk-grey900) 60%,\n    var(--uitk-grey900) 70%,\n    transparent 70%,\n    transparent 90%,\n    var(--uitk-grey900) 90%\n  );\n}\n";
styleInject(css_248z$5);

var Splitter = /*#__PURE__*/React__default['default'].memo(function Splitter(_ref) {
  var column = _ref.column,
      dispatch = _ref.dispatch,
      index = _ref.index,
      onDrag = _ref.onDrag,
      onDragEnd = _ref.onDragEnd,
      onDragStart = _ref.onDragStart,
      path = _ref.path,
      style = _ref.style;
  var ignoreClick = React.useRef(null);
  var rootRef = React.useRef(null);
  var lastPos = React.useRef(null);

  var _useState = React.useState(false),
      _useState2 = _slicedToArray(_useState, 2),
      active = _useState2[0],
      setActive = _useState2[1];

  var handleKeyDownDrag = React.useCallback(function (_ref2) {
    var key = _ref2.key,
        shiftKey = _ref2.shiftKey;
    // TODO calc max distance
    var distance = shiftKey ? 10 : 1;

    if (column && key === 'ArrowDown') {
      onDrag(index, distance);
    } else if (column && key === 'ArrowUp') {
      onDrag(index, -distance);
    } else if (!column && key === 'ArrowLeft') {
      onDrag(index, -distance);
    } else if (!column && key === 'ArrowRight') {
      onDrag(index, distance);
    }
  }, [column, index, onDrag]);
  var handleKeyDownInitDrag = React.useCallback(function (evt) {
    var key = evt.key;
    var horizontalMove = key === 'ArrowLeft' || key === 'ArrowRight';
    var verticalMove = key === 'ArrowUp' || key === 'ArrowDown';

    if (column && verticalMove || !column && horizontalMove) {
      onDragStart(index);
      handleKeyDownDrag(evt);
      keyDownHandlerRef.current = handleKeyDownDrag;
    }
  }, [column, handleKeyDownDrag, index, onDragStart]);
  var keyDownHandlerRef = React.useRef(handleKeyDownInitDrag);

  var handleKeyDown = function handleKeyDown(evt) {
    return keyDownHandlerRef.current(evt);
  };

  var handleMouseMove = React.useCallback(function (e) {
    ignoreClick.current = true;
    var pos = e[column ? 'clientY' : 'clientX'];
    var diff = pos - lastPos.current; // we seem to get a final value of zero

    if (pos && pos !== lastPos.current) {
      onDrag(index, diff);
    }

    lastPos.current = pos;
  }, [column, index, onDrag]);
  var handleMouseUp = React.useCallback(function (e) {
    window.removeEventListener('mousemove', handleMouseMove, false);
    window.removeEventListener('mouseup', handleMouseUp, false);
    onDragEnd();
    setActive(false);
    rootRef.current.focus();
  }, [handleMouseMove, onDragEnd, setActive]);
  var handleMouseDown = React.useCallback(function (e) {
    lastPos.current = column ? e.clientY : e.clientX;
    onDragStart(index);
    window.addEventListener('mousemove', handleMouseMove, false);
    window.addEventListener('mouseup', handleMouseUp, false);
    e.preventDefault();
    setActive(true);
  }, [column, handleMouseMove, handleMouseUp, index, onDragStart, setActive]);

  var handleFocus = function handleFocus(e) {
    dispatch({
      type: Action.FOCUS_SPLITTER,
      path: path,
      index: index
    });
  };

  var handleClick = function handleClick() {
    if (ignoreClick.current) {
      ignoreClick.current = false;
    } else {
      rootRef.current.focus();
    }
  };

  var handleBlur = function handleBlur(e) {
    dispatch({
      type: Action.BLUR_SPLITTER,
      relatedTarget: e.relatedTarget
    });
    keyDownHandlerRef.current = handleKeyDownInitDrag;
  };

  var className = classnames__default['default']('Splitter', 'focusable', {
    active: active,
    column: column
  });
  return /*#__PURE__*/React__default['default'].createElement("div", {
    className: className,
    ref: rootRef,
    role: "separator",
    style: style,
    onBlur: handleBlur,
    onClick: handleClick,
    onFocus: handleFocus,
    onKeyDown: handleKeyDown,
    onMouseDown: handleMouseDown,
    tabIndex: 0
  }, /*#__PURE__*/React__default['default'].createElement("div", {
    className: "grab-zone"
  }));
});

var css_248z$6 = ".Flexbox {\n  background-color: var(--uitk-container1-background);\n  display: flex;\n  box-sizing: border-box;\n  min-height: 0;\n  min-width: 0;\n  overflow: hidden;\n}\n";
styleInject(css_248z$6);

var useSizesRef = function useSizesRef() {
  var sizesRef = React.useRef([]);

  var _useState = React.useState(sizesRef.current),
      _useState2 = _slicedToArray(_useState, 2),
      setState = _useState2[1];

  var setSizes = React.useCallback(function (fn) {
    sizesRef.current = fn(sizesRef.current);
    setState(sizesRef.current);
  }, []);

  var clear = function clear() {
    return sizesRef.current = [];
  };

  return [sizesRef, setSizes, clear];
};

var Flexbox = function Flexbox(inputProps) {
  var _useLayout = useLayout('Flexbox', inputProps),
      _useLayout2 = _slicedToArray(_useLayout, 4),
      props = _useLayout2[0],
      ref = _useLayout2[1],
      layoutDispatch = _useLayout2[2],
      isRoot = _useLayout2[3];

  var _props$children = props.children,
      children = _props$children === void 0 ? [] : _props$children,
      className = props.className,
      id = props.layoutId,
      path = props.path,
      style = props.style;
  var isColumn = style.flexDirection === 'column';

  var _useSizesRef = useSizesRef(),
      _useSizesRef2 = _slicedToArray(_useSizesRef, 3),
      sizesRef = _useSizesRef2[0],
      setSizes = _useSizesRef2[1],
      clearSizes = _useSizesRef2[2];

  var dimension = isColumn ? 'height' : 'width';
  var measure = React.useCallback(function () {
    return Array.from(ref.current.childNodes).filter(function (el) {
      return !el.classList.contains('Splitter');
    }).map(function (el) {
      return Math.round(el.getBoundingClientRect()[dimension]);
    });
  }, [dimension]);
  var handleDragStart = React.useCallback(function () {
    setSizes(function () {
      return measure();
    });
  }, [ref, dimension, setSizes]);
  var handleDrag = React.useCallback(function (idx, distance) {
    setSizes(function (prevSizes) {
      // prevSizes should have been set in handleDragStart, but we occasionally
      // find ourselves here without that having been invoked
      var newSizes = prevSizes.length === 0 ? measure() : prevSizes.slice();
      newSizes[idx] += distance;
      newSizes[idx + 1] -= distance;
      return newSizes;
    });
  }, [setSizes]);
  var handleDragEnd = React.useCallback(function () {
    var sizes = sizesRef.current;
    clearSizes();
    layoutDispatch({
      type: Action.SPLITTER_RESIZE,
      path: path,
      sizes: sizes
    });
  }, [clearSizes, layoutDispatch, path, sizesRef]);

  var createSplitter = function createSplitter(i) {
    return /*#__PURE__*/React__default['default'].createElement(Splitter, {
      column: isColumn,
      dispatch: layoutDispatch,
      index: i,
      key: "splitter-".concat(i),
      onDrag: handleDrag,
      onDragEnd: handleDragEnd,
      onDragStart: handleDragStart,
      path: path
    });
  };

  var injectSplitters = function injectSplitters(list, child, i, arr) {
    var _child$props$style = child.props.style,
        flexBasis = _child$props$style.flexBasis,
        layoutSize = _child$props$style[dimension];
    var draggedSize = sizesRef.current[i];
    var cloneChild = draggedSize !== undefined && draggedSize !== flexBasis && draggedSize !== layoutSize;

    if (cloneChild) {
      var dolly = /*#__PURE__*/React__default['default'].cloneElement(child, {
        style: _objectSpread2(_objectSpread2({}, child.props.style), {}, _defineProperty({
          flexBasis: draggedSize
        }, dimension, 0))
      });
      list.push(dolly);
    } else {
      list.push(child);
    } // TODO we have to watch out for runtime changes to resizeable


    if (getProp(child, 'resizeable') && getProp(arr[i + 1], 'resizeable')) {
      list.push(createSplitter(i));
    }

    return list;
  };

  var container = /*#__PURE__*/React__default['default'].createElement("div", {
    className: classnames__default['default']('Flexbox', className),
    id: id,
    ref: ref,
    style: style
  }, children.reduce(injectSplitters, []));
  return isRoot ? /*#__PURE__*/React__default['default'].createElement(LayoutContext.Provider, {
    value: {
      dispatch: layoutDispatch
    }
  }, container) : container;
};

Flexbox.displayName = 'Flexbox';
registerComponent('Flexbox', Flexbox, 'container');

var ActionButton = function ActionButton(_ref) {
  var actionId = _ref.actionId,
      accessibleText = _ref.accessibleText,
      className = _ref.className,
      iconName = _ref.iconName,
      onClick = _ref.onClick,
      title = _ref.title,
      props = _objectWithoutProperties(_ref, ["actionId", "accessibleText", "className", "iconName", "onClick", "title"]);

  var handleClick = function handleClick(evt) {
    onClick(evt, actionId);
  };

  return /*#__PURE__*/React__default['default'].createElement(toolkit.Button, _extends({}, props, {
    className: classnames__default['default']('ActionButton', className),
    onClick: handleClick,
    title: title,
    variant: "secondary"
  }), /*#__PURE__*/React__default['default'].createElement(toolkit.Icon, {
    accessibleText: accessibleText,
    name: iconName
  }));
};

var css_248z$7 = ".Header {\n  border-bottom: solid 1px var(--uitk-grey40);\n}\n";
styleInject(css_248z$7);

var Header = function Header(_ref) {
  var classNameProp = _ref.className,
      collapsed = _ref.collapsed,
      expanded = _ref.expanded,
      closeable = _ref.closeable,
      orientationProp = _ref.orientation,
      tearOut = _ref.tearOut;

  var _useLayoutContext = useLayoutContext(),
      title = _useLayoutContext.title,
      dispatchViewAction = _useLayoutContext.dispatch;

  var handleAction = function handleAction(evt, actionId) {
    return dispatchViewAction({
      type: actionId
    });
  };

  var handleMouseDown = function handleMouseDown(e) {
    dispatchViewAction({
      type: 'mousedown'
    }, e);
  };

  var handleButtonMouseDown = function handleButtonMouseDown(evt) {
    // do not allow drag to be initiated
    evt.stopPropagation();
  };

  var className = classnames__default['default']('Header', // `Header-${density}Density`,
  classNameProp);
  var orientation = collapsed || orientationProp;

  var getContent = function getContent() {
    var result = [];

    if (collapsed === false) {
      result.push( /*#__PURE__*/React__default['default'].createElement(ActionButton, {
        accessibleText: "Minimize View",
        actionId: Action.MINIMIZE,
        iconName: "minimize",
        key: result.length,
        onClick: handleAction,
        onMouseDown: handleButtonMouseDown,
        title: "Minimize"
      }));
    } else if (collapsed) {
      result.push( /*#__PURE__*/React__default['default'].createElement(ActionButton, {
        accessibleText: "Restore View",
        actionId: Action.RESTORE,
        iconName: "double-chevron-right",
        onClick: handleAction,
        onMouseDown: handleMouseDown,
        title: "Restore"
      }));
    }

    if (expanded === false) {
      result.push( /*#__PURE__*/React__default['default'].createElement(ActionButton, {
        accessibleText: "Maximize View",
        actionId: Action.MAXIMIZE,
        iconName: "maximize",
        key: result.length,
        onClick: handleAction,
        onMouseDown: handleButtonMouseDown,
        title: "Maximize"
      }));
    } else if (expanded) {
      result.push( /*#__PURE__*/React__default['default'].createElement(ActionButton, {
        accessibleText: "Restore View",
        actionId: Action.RESTORE,
        iconName: "restore",
        key: result.length,
        onClick: handleAction,
        onMouseDown: handleButtonMouseDown,
        title: "Restore"
      }));
    }

    if (tearOut) {
      result.push( /*#__PURE__*/React__default['default'].createElement(ActionButton, {
        accessibleText: "Tear out View",
        actionId: Action.TEAR_OUT,
        iconName: "tear-out",
        key: result.length,
        onClick: handleAction,
        onMouseDown: handleButtonMouseDown,
        title: "Tear Out"
      }));
    }

    if (closeable) {
      result.push( /*#__PURE__*/React__default['default'].createElement(ActionButton, {
        accessibleText: "Close View",
        actionId: Action.REMOVE,
        iconName: "close",
        key: result.length,
        onClick: handleAction,
        onMouseDown: handleButtonMouseDown,
        title: "Close"
      }));
    }

    return result;
  };

  var content = getContent();
  return /*#__PURE__*/React__default['default'].createElement(toolkit.Toolbar, {
    className: className,
    orientation: orientation,
    onMouseDown: handleMouseDown
  }, /*#__PURE__*/React__default['default'].createElement("span", {
    className: "Header-title"
  }, title), content.length > 0 ? /*#__PURE__*/React__default['default'].createElement(toolkit.Tooltray, {
    align: "right"
  }, content) : null);
};

var useViewActionDispatcher = function useViewActionDispatcher(root, viewPath, layoutDispatch) {
  var handleMouseDown = React.useCallback(function (evt, index) {
    evt.stopPropagation();
    var dragRect = root.current.getBoundingClientRect(); // TODO should we check if we are allowed to drag ?

    layoutDispatch({
      type: Action.DRAG_START,
      evt: evt,
      path: index === undefined ? viewPath : "".concat(viewPath, ".").concat(index),
      dragRect: dragRect
    });
  }, [layoutDispatch, viewPath, root]); // TODO should be event, action, then this method can bea assigned directly to a html element
  // as an event hander

  var dispatchAction = function dispatchAction(action, evt) {
    var type = action.type,
        index = action.index,
        _action$path = action.path,
        path = _action$path === void 0 ? viewPath : _action$path;

    switch (type) {
      case Action.REMOVE:
      case Action.MINIMIZE:
      case Action.MAXIMIZE:
      case Action.RESTORE:
      case Action.TEAR_OUT:
        return layoutDispatch({
          type: type,
          path: path
        });

      case "mousedown":
        return handleMouseDown(evt, index);

      default:
        {
          if (Object.values(Action).includes(type)) {
            layoutDispatch(action);
          }
        }
    }
  };

  return dispatchAction;
};

var css_248z$8 = ".View {\n  display: flex;\n  flex-direction: column;\n  outline: none;\n  position: relative;\n}\n\n.View.focus-visible:after {\n  content: '';\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  border: dotted cornflowerblue 2px;\n}\n\n.View.dragging {\n  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.175);\n}\n\n.view-main {\n  display: flex;\n  flex-direction: column;\n  flex: 1;\n}\n\n.View-collapsed .view-main {\n  display: none;\n}\n\n.View-collapsed + .Splitter {\n  display: none;\n}\n\n.View-collapsed .Toolbar-vertical {\n  border-right: solid 1px var(--uitk-grey40);\n}\n\n.View-collapsed .Toolbar-vertical .toolbar-title {\n  display: none;\n}\n";
styleInject(css_248z$8);

var View = /*#__PURE__*/React__default['default'].memo(function View(inputProps) {
  var _useLayout = useLayout('View', inputProps),
      _useLayout2 = _slicedToArray(_useLayout, 2),
      props = _useLayout2[0],
      ref = _useLayout2[1];

  var children = props.children,
      className = props.className,
      collapsed = props.collapsed,
      closeable = props.closeable,
      expanded = props.expanded,
      id = props.layoutId,
      header = props.header,
      _props$orientation = props.orientation,
      orientation = _props$orientation === void 0 ? 'horizontal' : _props$orientation,
      path = props.path,
      tearOut = props.tearOut,
      style = props.style,
      title = props.title;
  var layoutDispatch = useLayoutDispatch();
  var dispatchViewAction = useViewActionDispatcher(ref, path, layoutDispatch);

  var handleClick = function handleClick() {// ref.current.focus();
  };

  var headerProps = _typeof(header) === 'object' ? header : {};
  return /*#__PURE__*/React__default['default'].createElement("div", {
    className: classnames__default['default']('View', className, {
      'View-collapsed': collapsed,
      'View-expanded': expanded
    }),
    id: id,
    ref: ref,
    onClick: handleClick,
    style: style,
    tabIndex: -1
  }, /*#__PURE__*/React__default['default'].createElement(LayoutContext.Provider, {
    value: {
      dispatch: dispatchViewAction,
      path: path,
      title: title
    }
  }, header ? /*#__PURE__*/React__default['default'].createElement(Header, _extends({}, headerProps, {
    collapsed: collapsed,
    expanded: expanded,
    closeable: closeable,
    orientation: collapsed || orientation,
    tearOut: tearOut
  })) : null, /*#__PURE__*/React__default['default'].createElement("div", {
    className: "view-main"
  }, children)));
});
View.displayName = 'View';
registerComponent('View', View, 'view');

var css_248z$9 = ".Component {\n}\n";
styleInject(css_248z$9);

var Component = function Component(_ref, ref) {
  var id = _ref.id,
      style = _ref.style;
  return /*#__PURE__*/React__default['default'].createElement("div", {
    className: "Component",
    id: id,
    style: style
  });
};

Component.displayName = "Component";
registerComponent("Component", Component);

var css_248z$a = ".Tabs {\n  display: flex;\n  box-sizing: border-box;\n  flex-direction: column;\n}\n\n.Tabs .Toolbar:before {\n  left: 0;\n  width: 100%;\n  bottom: 0;\n  height: 1px;\n  content: '';\n  position: absolute;\n  background: var(--uitk-grey60);\n}\n\n.Tabs > .Header {\n  border-bottom: none;\n}\n\n/* .Splitter.column + .Flexbox > .Tabs:first-child {\n  border-top: solid 1px lightgrey;\n} */\n\n.Layout-svg-button {\n  --uitk-space-medium: 5px;\n}\n";
styleInject(css_248z$a);

var Stack = function Stack(inputProps) {
  var _useLayout = useLayout('Stack', inputProps),
      _useLayout2 = _slicedToArray(_useLayout, 3),
      props = _useLayout2[0],
      ref = _useLayout2[1],
      layoutDispatch = _useLayout2[2];

  var enableAddTab = props.enableAddTab,
      id = props.layoutId,
      _props$keyBoardActiva = props.keyBoardActivation,
      keyBoardActivation = _props$keyBoardActiva === void 0 ? 'automatic' : _props$keyBoardActiva,
      onTabSelectionChanged = props.onTabSelectionChanged,
      path = props.path,
      showTabs = props.showTabs,
      style = props.style;
  var dispatchViewAction = useViewActionDispatcher(ref, path, layoutDispatch);

  var handleTabSelection = function handleTabSelection(e, nextIdx) {
    layoutDispatch({
      type: Action.SWITCH_TAB,
      path: props.path,
      nextIdx: nextIdx
    });

    if (onTabSelectionChanged) {
      onTabSelectionChanged(nextIdx);
    }
  };

  var handleDeleteTab = function handleDeleteTab(e, tabIndex) {
    var doomedChild = props.children[tabIndex];
    layoutDispatch({
      type: Action.REMOVE,
      path: doomedChild.props.path
    });
  };

  var handleAddTab = function handleAddTab(e, tabIndex) {
    layoutDispatch({
      type: Action.ADD,
      component: /*#__PURE__*/React__default['default'].createElement(Component, {
        style: {
          backgroundColor: 'pink'
        }
      })
    });
  };

  var handleMouseDown = function handleMouseDown(e, index) {
    dispatchViewAction({
      type: 'mousedown',
      index: index
    }, e);
  };

  function activeChild() {
    var _props$active = props.active,
        active = _props$active === void 0 ? 0 : _props$active,
        child = props.children[active];
    return child;
  }

  var renderTabs = function renderTabs() {
    return props.children.map(function (child, idx) {
      return /*#__PURE__*/React__default['default'].createElement(toolkit.Tab, {
        ariaControls: "".concat(id, "-").concat(idx, "-tab"),
        draggable: true,
        key: idx,
        id: "".concat(id, "-").concat(idx),
        label: child.props.title,
        deletable: child.props.removable
      });
    });
  };

  var child = activeChild(); //TODO roll ViewContext into LayoutContext
  // Stack always provides context, so Tabs have access to view commands

  return /*#__PURE__*/React__default['default'].createElement("div", {
    className: "Tabs",
    style: style,
    id: id,
    ref: ref
  }, /*#__PURE__*/React__default['default'].createElement(LayoutContext.Provider, {
    value: {
      dispatch: dispatchViewAction
    }
  }, showTabs ? /*#__PURE__*/React__default['default'].createElement(toolkit.Toolbar, {
    className: "Header",
    maxRows: 1,
    onMouseDown: handleMouseDown
  }, /*#__PURE__*/React__default['default'].createElement(toolkit.Tabstrip, {
    enableAddTab: enableAddTab,
    keyBoardActivation: keyBoardActivation,
    onChange: handleTabSelection,
    onAddTab: handleAddTab,
    onDeleteTab: handleDeleteTab,
    onMouseDown: handleMouseDown,
    value: props.active || 0
  }, renderTabs()), /*#__PURE__*/React__default['default'].createElement(toolkit.Tooltray, {
    align: "right",
    className: "layout-buttons"
  }, /*#__PURE__*/React__default['default'].createElement(Minimize, null), /*#__PURE__*/React__default['default'].createElement(Maximize, null), /*#__PURE__*/React__default['default'].createElement(Close, null))) : null, isLayoutComponent(typeOf(child)) ? child : /*#__PURE__*/React__default['default'].createElement(View, {
    className: "TabPanel" // don't think we need this
    ,
    dispatch: layoutDispatch,
    id: "".concat(id, "-").concat(props.active || 0, "-tab"),
    ariaLabelledBy: "".concat(id, "-").concat(props.active || 0),
    rootId: id
  }, child)));
};

Stack.displayName = 'Stack';
registerComponent('Stack', Stack, 'container');

var css_248z$b = ".TabPanel {\n  display: flex;\n  flex: 1;\n}\n\n.TabPanel > * {\n  height: 100%;\n}\n\n.TabPanel > .View > .Header {\n  display: none;\n}\n";
styleInject(css_248z$b);

var TabPanel = function TabPanel(_ref) {
  var ariaLabelledBy = _ref.ariaLabelledBy,
      children = _ref.children,
      id = _ref.id;
  return /*#__PURE__*/React__default['default'].createElement("div", {
    className: "TabPanel",
    id: id,
    role: "tabpanel",
    "aria-labelledby": ariaLabelledBy
  }, children);
};

var uuid$1 = nanoid.nanoid;

exports.Action = Action;
exports.AddIcon = Add;
exports.Close = Close;
exports.Column2A = Column2A;
exports.Column2B = Column2B;
exports.Component = Component;
exports.DragHandle = DragHandle;
exports.DraggableLayout = DraggableLayout;
exports.Flexbox = Flexbox;
exports.LayoutContext = LayoutContext;
exports.Maximize = Maximize;
exports.Minimize = Minimize;
exports.MoreVerticalIcon = MoreVertical;
exports.PaddingBottomIcon = PaddingBottom;
exports.PaddingLeftIcon = PaddingLeft;
exports.PaddingRightIcon = PaddingRight;
exports.PaddingTopIcon = PaddingTop;
exports.Stack = Stack;
exports.TabPanel = TabPanel;
exports.TearOut = TearOut;
exports.View = View;
exports.applyLayoutProps = applyLayoutProps;
exports.registerComponent = registerComponent;
exports.useLayoutContext = useLayoutContext;
exports.useLayoutDispatch = useLayoutDispatch;
exports.uuid = uuid$1;
//# sourceMappingURL=uitk-layout.cjs.js.map
