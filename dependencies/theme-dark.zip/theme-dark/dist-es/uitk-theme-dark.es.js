import { installTheme } from '@uitk/toolkit';
import '@uitk/theme-light/src/density.css';
import '@uitk/theme-light/src/theme.css';

function styleInject(css, ref) {
  if ( ref === void 0 ) ref = {};
  var insertAt = ref.insertAt;

  if (!css || typeof document === 'undefined') { return; }

  var head = document.head || document.getElementsByTagName('head')[0];
  var style = document.createElement('style');
  style.type = 'text/css';

  if (insertAt === 'top') {
    if (head.firstChild) {
      head.insertBefore(style, head.firstChild);
    } else {
      head.appendChild(style);
    }
  } else {
    head.appendChild(style);
  }

  if (style.styleSheet) {
    style.styleSheet.cssText = css;
  } else {
    style.appendChild(document.createTextNode(css));
  }
}

var css_248z = ".uitk-dark {\n  --uitk-red10: #412522;\n  --uitk-red20: #ffcfc9;\n  --uitk-red30: #ffbbb2;\n  --uitk-red40: #ffa79c;\n  --uitk-red50: #ff9485;\n  --uitk-red100: #ff806f;\n  --uitk-red200: #ff6c58;\n  --uitk-red300: #ff5942;\n  --uitk-red400: #ed412a;\n  --uitk-red500: #e32b16;\n  --uitk-red600: #c42010;\n  --uitk-red700: #a6150b;\n  --uitk-red800: #880a05;\n  --uitk-red900: #6a0000;\n  --uitk-orange10: #362c24;\n  --uitk-orange20: #fedfa6;\n  --uitk-orange30: #fed68e;\n  --uitk-orange40: #fecd76;\n  --uitk-orange50: #fec55e;\n  --uitk-orange100: #fab551;\n  --uitk-orange200: #f6a544;\n  --uitk-orange300: #f29538;\n  --uitk-orange400: #ee852b;\n  --uitk-orange500: #ea7319;\n  --uitk-orange600: #e06519;\n  --uitk-orange700: #d65513;\n  --uitk-orange800: #cc440d;\n  --uitk-orange900: #c23407;\n  --uitk-green10: #23342b;\n  --uitk-green20: #b8e8b6;\n  --uitk-green30: #a0dda4;\n  --uitk-green40: #88d291;\n  --uitk-green50: #70c77f;\n  --uitk-green100: #5dbd74;\n  --uitk-green200: #4db469;\n  --uitk-green300: #3cab60;\n  --uitk-green400: #309c5a;\n  --uitk-green500: #24874b;\n  --uitk-green600: #18723d;\n  --uitk-green700: #0c5d2e;\n  --uitk-green800: #014920;\n  --uitk-green900: #003912;\n  --uitk-teal10: #1c373c;\n  --uitk-teal20: #c7e8e8;\n  --uitk-teal30: #b4e0e1;\n  --uitk-teal40: #a2d9da;\n  --uitk-teal50: #8dcdd1;\n  --uitk-teal100: #7bc1c8;\n  --uitk-teal200: #63b5c0;\n  --uitk-teal300: #49a0ac;\n  --uitk-teal400: #3095a6;\n  --uitk-teal500: #008297;\n  --uitk-teal600: #1b6b85;\n  --uitk-teal700: #005571;\n  --uitk-teal800: #014156;\n  --uitk-teal900: #00314c;\n  --uitk-blue10: #232f38;\n  --uitk-blue20: #233645;\n  --uitk-blue30: #273c4d;\n  --uitk-blue40: #90ccf2;\n  --uitk-blue50: #7dc3f0;\n  --uitk-blue100: #64b1e4;\n  --uitk-blue200: #4b9fd8;\n  --uitk-blue300: #338dcd;\n  --uitk-blue400: #2d81bd;\n  --uitk-blue500: #2670a9;\n  --uitk-blue600: #155c93;\n  --uitk-blue700: #00477b;\n  --uitk-blue700Fade: #00477bfc;\n  --uitk-blue800: #0c3566;\n  --uitk-blue900: #002858;\n  --uitk-purple10: #3a2d3e;\n  --uitk-purple20: #f7d4f4;\n  --uitk-purple30: #f5c9f1;\n  --uitk-purple40: #f3bdee;\n  --uitk-purple50: #f1b2eb;\n  --uitk-purple100: #df9ce1;\n  --uitk-purple200: #cd87d7;\n  --uitk-purple300: #c074cb;\n  --uitk-purple400: #a961b5;\n  --uitk-purple500: #964ea2;\n  --uitk-purple600: #813c8d;\n  --uitk-purple700: #672e7a;\n  --uitk-purple800: #53256d;\n  --uitk-purple900: #3b1054;\n  --uitk-grey10: #f2f4f6;\n  --uitk-grey20: #eaedef;\n  --uitk-grey30: #e0e4e9;\n  --uitk-grey40: #d9dde3;\n  --uitk-grey50: #ced2d9;\n  --uitk-grey60: #c5c9d0;\n  --uitk-grey70: #b4b7be;\n  --uitk-grey80: #9fa3aa;\n  --uitk-grey90: #84878e;\n  --uitk-grey100: #74777f;\n  --uitk-grey200: #61656e;\n  --uitk-grey300: #4c505b;\n  --uitk-grey400: #44484f;\n  --uitk-grey500: #3b3f46;\n  --uitk-grey600: #2f3136;\n  --uitk-grey700: #2a2c2f;\n  --uitk-grey800: #242526;\n  --uitk-grey900: #161616;\n  --uitk-purple: var(--uitk-purple500);\n  --uitk-blue: var(--uitk-blue500);\n  --uitk-teal: var(--uitk-teal500);\n  --uitk-green: var(--uitk-green500);\n  --uitk-orange: var(--uitk-orange500);\n  --uitk-red: var(--uitk-red500);\n  --white: #ffffff;\n  --black: #000000;\n\n  --uitk-status-info-color: var(--uitk-blue400);\n  --uitk-status-error-color: var(--uitk-red400);\n  --uitk-status-warning-color: var(--uitk-orange500);\n  --uitk-status-success-color: var(--uitk-green400);\n\n  --uitk-action-regular-default-color: var(--white);\n  --uitk-action-regular-default-background: var(--uitk-grey300);\n  --uitk-action-regular-default-icon: var(--white);\n  --uitk-action-regular-active-color: var(--uitk-grey900);\n  --uitk-action-regular-active-background: var(--uitk-grey80);\n  --uitk-action-regular-active-icon: var(--uitk-grey900);\n  --uitk-action-regular-hover-color: var(--white);\n  --uitk-action-regular-hover-background: var(--uitk-grey200);\n  --uitk-action-regular-hover-icon: var(--white);\n\n  --uitk-action-cta-default-color: var(--white);\n  --uitk-action-cta-default-background: var(--uitk-blue600);\n  --uitk-action-cta-default-icon: var(--white);\n  --uitk-action-cta-active-color: var(--white);\n  --uitk-action-cta-active-background: var(--uitk-blue700);\n  --uitk-action-cta-active-icon: var(--white);\n  --uitk-action-cta-hover-color: var(--white);\n  --uitk-action-cta-hover-background: var(--uitk-blue500);\n  --uitk-action-cta-hover-icon: var(--white);\n\n  --uitk-action-secondary-default-color: var(--white);\n  --uitk-action-secondary-default-background: transparent;\n  --uitk-action-secondary-default-icon: var(--uitk-grey60);\n  --uitk-action-secondary-active-color: var(--uitk-grey900);\n  --uitk-action-secondary-active-background: var(--uitk-grey80);\n  --uitk-action-secondary-active-icon: var(--uitk-grey900);\n  --uitk-action-secondary-hover-color: var(--white);\n  --uitk-action-secondary-hover-background: var(--uitk-grey200);\n  --uitk-action-secondary-hover-icon: var(--white);\n\n  --uitk-shadow-black-1: 0 1px 3px 0 rgba(0, 0, 0, 0.5);\n  --uitk-shadow-black-2: 0 2px 4px 0 rgba(0, 0, 0, 0.5);\n  --uitk-shadow-black-3: 0 4px 8px 0 rgba(0, 0, 0, 0.55);\n  --uitk-shadow-black-4: 0 6px 10px 0 rgba(0, 0, 0, 0.55);\n  --uitk-shadow-black-5: 0 8px 16px 0 rgba(0, 0, 0, 0.6);\n  --uitk-shadow-black-6: 0 12px 40px 5px rgba(0, 0, 0, 0.65);\n  --uitk-shadow-blue-1: 0 1px 3px 0 rgba(0, 18, 40, 1);\n  --uitk-shadow-blue-2: 0 2px 4px 0 rgba(0, 18, 40, 1);\n  --uitk-shadow-blue-3: 0 4px 8px 0 rgba(0, 18, 40, 1);\n  --uitk-shadow-blue-4: 0 6px 10px 0 rgba(0, 18, 40, 1);\n  --uitk-shadow-blue-5: 0 8px 16px 0 rgba(0, 18, 40, 1);\n  --uitk-shadow-blue-6: 0 12px 40px 5px rgba(0, 18, 40, 1);\n\n  --uitk-select-default-background: var(--uitk-grey800);\n  --uitk-select-default-color: var(--white);\n\n  --uitk-select-active-background: var(--uitk-blue30);\n  --uitk-select-selected-background: var(--uitk-blue500);\n  --uitk-select-selected-color: var(--white);\n\n  --uitk-container1-background: var(--uitk-grey800);\n  --uitk-container1-border-color: var(--uitk-grey200);\n\n  /* default color for text */\n  --uitk-text-color: var(--uitk-grey20);\n  /* Grid Header */\n  --default-header-color: var(--uitk-grey70);\n}\n";
styleInject(css_248z);

installTheme("uitk-dark");
//# sourceMappingURL=uitk-theme-dark.es.js.map
