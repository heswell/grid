'use strict';

require('@uitk/theme-light/src/density.css');
require('@uitk/theme-light/src/theme.css');

function styleInject(css, ref) {
  if ( ref === void 0 ) ref = {};
  var insertAt = ref.insertAt;

  if (!css || typeof document === 'undefined') { return; }

  var head = document.head || document.getElementsByTagName('head')[0];
  var style = document.createElement('style');
  style.type = 'text/css';

  if (insertAt === 'top') {
    if (head.firstChild) {
      head.insertBefore(style, head.firstChild);
    } else {
      head.appendChild(style);
    }
  } else {
    head.appendChild(style);
  }

  if (style.styleSheet) {
    style.styleSheet.cssText = css;
  } else {
    style.appendChild(document.createTextNode(css));
  }
}

var css_248z = ".palette-dark_uitk-dark__3dqE7 {\n  --red10: #412522;\n  --red20: #ffcfc9;\n  --red30: #ffbbb2;\n  --red40: #ffa79c;\n  --red50: #ff9485;\n  --red100: #ff806f;\n  --red200: #ff6c58;\n  --red300: #ff5942;\n  --red400: #ed412a;\n  --red500: #e32b16;\n  --red600: #c42010;\n  --red700: #a6150b;\n  --red800: #880a05;\n  --red900: #6a0000;\n  --orange10: #362c24;\n  --orange20: #fedfa6;\n  --orange30: #fed68e;\n  --orange40: #fecd76;\n  --orange50: #fec55e;\n  --orange100: #fab551;\n  --orange200: #f6a544;\n  --orange300: #f29538;\n  --orange400: #ee852b;\n  --orange500: #ea7319;\n  --orange600: #e06519;\n  --orange700: #d65513;\n  --orange800: #cc440d;\n  --orange900: #c23407;\n  --green10: #23342b;\n  --green20: #b8e8b6;\n  --green30: #a0dda4;\n  --green40: #88d291;\n  --green50: #70c77f;\n  --green100: #5dbd74;\n  --green200: #4db469;\n  --green300: #3cab60;\n  --green400: #309c5a;\n  --green500: #24874b;\n  --green600: #18723d;\n  --green700: #0c5d2e;\n  --green800: #014920;\n  --green900: #003912;\n  --teal10: #1c373c;\n  --teal20: #c7e8e8;\n  --teal30: #b4e0e1;\n  --teal40: #a2d9da;\n  --teal50: #8dcdd1;\n  --teal100: #7bc1c8;\n  --teal200: #63b5c0;\n  --teal300: #49a0ac;\n  --teal400: #3095a6;\n  --teal500: #008297;\n  --teal600: #1b6b85;\n  --teal700: #005571;\n  --teal800: #014156;\n  --teal900: #00314c;\n  --blue10: #232f38;\n  --blue20: #233645;\n  --blue30: #273c4d;\n  --blue40: #90ccf2;\n  --blue50: #7dc3f0;\n  --blue100: #64b1e4;\n  --blue200: #4b9fd8;\n  --blue300: #338dcd;\n  --blue400: #2d81bd;\n  --blue500: #2670a9;\n  --blue600: #155c93;\n  --blue700: #00477b;\n  --blue700Fade: #00477bfc;\n  --blue800: #0c3566;\n  --blue900: #002858;\n  --purple10: #3a2d3e;\n  --purple20: #f7d4f4;\n  --purple30: #f5c9f1;\n  --purple40: #f3bdee;\n  --purple50: #f1b2eb;\n  --purple100: #df9ce1;\n  --purple200: #cd87d7;\n  --purple300: #c074cb;\n  --purple400: #a961b5;\n  --purple500: #964ea2;\n  --purple600: #813c8d;\n  --purple700: #672e7a;\n  --purple800: #53256d;\n  --purple900: #3b1054;\n  --grey10: #f2f4f6;\n  --grey20: #eaedef;\n  --grey30: #e0e4e9;\n  --grey40: #d9dde3;\n  --grey50: #ced2d9;\n  --grey60: #c5c9d0;\n  --grey70: #b4b7be;\n  --grey80: #9fa3aa;\n  --grey90: #84878e;\n  --grey100: #74777f;\n  --grey200: #61656e;\n  --grey300: #4c505b;\n  --grey400: #44484f;\n  --grey500: #3b3f46;\n  --grey600: #2f3136;\n  --grey700: #2a2c2f;\n  --grey800: #242526;\n  --grey900: #16161;\n  --purple: var(--purple500);\n  --blue: var(--blue500);\n  --teal: var(--teal500);\n  --green: var(--green500);\n  --orange: var(--orange500);\n  --red: var(--red500);\n  --white: #ffffff;\n  --black: #000000;\n\n  --status-info-color: var(--blue400);\n  --status-error-color: var(--red400);\n  --status-warning-color: var(--orange500);\n  --status-success-color: var(--green400);\n\n  --actionable-regular-default-color: var(--white);\n  --actionable-regular-default-background: var(--grey300);\n  --actionable-regular-default-icon: var(--white);\n  --actionable-regular-active-color: var(--grey900);\n  --actionable-regular-active-background: var(--grey80);\n  --actionable-regular-active-icon: var(--grey900);\n  --actionable-regular-hover-color: var(--white);\n  --actionable-regular-hover-background: var(--grey200);\n  --actionable-regular-hover-icon: var(--white);\n\n  --actionable-cta-default-color: var(--white);\n  --actionable-cta-default-background: var(--blue600);\n  --actionable-cta-default-icon: var(--white);\n  --actionable-cta-active-color: var(--white);\n  --actionable-cta-active-background: var(--blue700);\n  --actionable-cta-active-icon: var(--white);\n  --actionable-cta-hover-color: var(--white);\n  --actionable-cta-hover-background: var(--blue500);\n  --actionable-cta-hover-icon: var(--white);\n\n  --actionable-secondary-default-color: var(--white);\n  --actionable-secondary-default-background: transparent;\n  --actionable-secondary-default-icon: var(--grey60);\n  --actionable-secondary-active-color: var(--grey900);\n  --actionable-secondary-active-background: var(--grey80);\n  --actionable-secondary-active-icon: var(--grey900);\n  --actionable-secondary-hover-color: var(--white);\n  --actionable-secondary-hover-background: var(--grey200);\n  --actionable-secondary-hover-icon: var(--white);\n\n  --elevation-shadow-black-1: 0 1px 3px 0 rgba(0, 0, 0, 0.5);\n  --elevation-shadow-black-2: 0 2px 4px 0 rgba(0, 0, 0, 0.5);\n  --elevation-shadow-black-3: 0 4px 8px 0 rgba(0, 0, 0, 0.55);\n  --elevation-shadow-black-4: 0 6px 10px 0 rgba(0, 0, 0, 0.55);\n  --elevation-shadow-black-5: 0 8px 16px 0 rgba(0, 0, 0, 0.6);\n  --elevation-shadow-black-6: 0 12px 40px 5px rgba(0, 0, 0, 0.65);\n  --elevation-shadow-blue-1: 0 1px 3px 0 rgba(0, 18, 40, 1);\n  --elevation-shadow-blue-2: 0 2px 4px 0 rgba(0, 18, 40, 1);\n  --elevation-shadow-blue-3: 0 4px 8px 0 rgba(0, 18, 40, 1);\n  --elevation-shadow-blue-4: 0 6px 10px 0 rgba(0, 18, 40, 1);\n  --elevation-shadow-blue-5: 0 8px 16px 0 rgba(0, 18, 40, 1);\n  --elevation-shadow-blue-6: 0 12px 40px 5px rgba(0, 18, 40, 1);\n\n  --selectable-default-background: var(--grey800);\n  --selectable-default-color: var(--white);\n\n  --selectable-active-background: var(--blue30);\n  --selectable-selected-background: var(--blue500);\n  --selectable-selected-color: var(--white);\n\n  --container1-background: var(--grey800);\n  --container1-border-color: var(--grey200);\n\n  --default-text-color: var(--grey20);\n  /* Grid Header */\n  --default-header-color: var(--grey70);\n}\n";
styleInject(css_248z);
//# sourceMappingURL=theme-dark.cjs.js.map
