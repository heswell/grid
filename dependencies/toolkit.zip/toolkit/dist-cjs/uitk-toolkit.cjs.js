'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var React = require('react');
var classnames = require('classnames');
var toolkit$1 = require('@uitk/toolkit');
var PropTypes = require('prop-types');
var ReactDOM = require('react-dom');
var noScroll = require('no-scroll');
var ariaHidden = require('aria-hidden');
var reactPopper = require('react-popper');
var reactWindow = require('react-window');
var computeScrollIntoView = require('compute-scroll-into-view');
var warning = require('warning');
var deepmerge = require('deepmerge');
var copy = require('clipboard-copy');

function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

var React__default = /*#__PURE__*/_interopDefaultLegacy(React);
var classnames__default = /*#__PURE__*/_interopDefaultLegacy(classnames);
var PropTypes__default = /*#__PURE__*/_interopDefaultLegacy(PropTypes);
var noScroll__default = /*#__PURE__*/_interopDefaultLegacy(noScroll);
var computeScrollIntoView__default = /*#__PURE__*/_interopDefaultLegacy(computeScrollIntoView);
var warning__default = /*#__PURE__*/_interopDefaultLegacy(warning);
var deepmerge__default = /*#__PURE__*/_interopDefaultLegacy(deepmerge);
var copy__default = /*#__PURE__*/_interopDefaultLegacy(copy);

function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function (obj) {
      return typeof obj;
    };
  } else {
    _typeof = function (obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

function _extends() {
  _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    if (enumerableOnly) symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    });
    keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread2(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        _defineProperty(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }

  return target;
}

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

function _objectWithoutProperties(source, excluded) {
  if (source == null) return {};

  var target = _objectWithoutPropertiesLoose(source, excluded);

  var key, i;

  if (Object.getOwnPropertySymbols) {
    var sourceSymbolKeys = Object.getOwnPropertySymbols(source);

    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }

  return target;
}

function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}

function _toConsumableArray(arr) {
  return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
}

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return _arrayLikeToArray(arr);
}

function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
}

function _iterableToArrayLimit(arr, i) {
  if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return;
  var _arr = [];
  var _n = true;
  var _d = false;
  var _e = undefined;

  try {
    for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];

  return arr2;
}

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _createForOfIteratorHelper(o, allowArrayLike) {
  var it;

  if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) {
    if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") {
      if (it) o = it;
      var i = 0;

      var F = function () {};

      return {
        s: F,
        n: function () {
          if (i >= o.length) return {
            done: true
          };
          return {
            done: false,
            value: o[i++]
          };
        },
        e: function (e) {
          throw e;
        },
        f: F
      };
    }

    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }

  var normalCompletion = true,
      didErr = false,
      err;
  return {
    s: function () {
      it = o[Symbol.iterator]();
    },
    n: function () {
      var step = it.next();
      normalCompletion = step.done;
      return step;
    },
    e: function (e) {
      didErr = true;
      err = e;
    },
    f: function () {
      try {
        if (!normalCompletion && it.return != null) it.return();
      } finally {
        if (didErr) throw err;
      }
    }
  };
}

var ThemeContext = /*#__PURE__*/React.createContext();
var ICON_SIZE = {
  large: {
    height: 48
  },
  medium: {
    height: 24
  },
  small: {
    height: 12
  }
};
var SIZE = {
  touch: {
    regular: {
      height: 44
    },
    stackable: {
      height: 60
    }
  },
  low: {
    regular: {
      height: 36
    },
    stackable: {
      height: 48
    }
  },
  medium: {
    regular: {
      height: 28
    },
    stackable: {
      height: 36
    }
  },
  high: {
    regular: {
      height: 20
    },
    stackable: {
      height: 24
    }
  }
};
var toolkit = {
  size: {
    getSize: function getSize(_ref) {
      var _ref$density = _ref.density,
          density = _ref$density === void 0 ? 'medium' : _ref$density,
          _ref$variant = _ref.variant,
          variant = _ref$variant === void 0 ? 'regular' : _ref$variant,
          _ref$iconSize = _ref.iconSize,
          iconSize = _ref$iconSize === void 0 ? 'small' : _ref$iconSize;
      return variant === 'icon' ? ICON_SIZE[iconSize] : SIZE[density][variant];
    }
  }
}; // TODO need toseparate the theme id (uitk) from the variant id (uitk-light)

var lightTheme = {
  id: 'uitk-light',
  toolkit: toolkit
};
var darkTheme = {
  id: 'uitk-dark',
  toolkit: toolkit
};
var availableThemes = {
  'uitk-light': lightTheme,
  'uitk-dark': darkTheme
};
function ThemeProvider(_ref2) {
  var children = _ref2.children,
      _ref2$density = _ref2.density,
      density = _ref2$density === void 0 ? 'medium' : _ref2$density,
      _ref2$theme = _ref2.theme,
      themeId = _ref2$theme === void 0 ? 'uitk-light' : _ref2$theme,
      _ref2$themeLoader = _ref2.themeLoader,
      themeLoader = _ref2$themeLoader === void 0 ? null : _ref2$themeLoader;
  var currentTheme = React.useRef(themeId);

  if (themeId !== currentTheme.current) {
    currentTheme.current = themeId;
    themeLoader && themeLoader(themeId);
  }

  var theme = availableThemes[themeId];

  if (theme === undefined) {
    throw Error("No registered theme ".concat(themeId));
  }

  return /*#__PURE__*/React__default['default'].createElement(ThemeContext.Provider, {
    value: {
      density: density,
      theme: theme
    }
  }, /*#__PURE__*/React__default['default'].createElement("uitk-theme", {
    "class": classnames__default['default']('uitk', theme.id, "uitk-density-".concat(density)),
    style: {
      display: 'contents'
    }
  }, children));
}
var ThemeConsumer = ThemeContext.Consumer;
var useTheme = function useTheme() {
  var _useContext = React.useContext(ThemeContext),
      theme = _useContext.theme;

  return theme;
};
function useDensity(density) {
  var _useContext2 = React.useContext(ThemeContext),
      densityFromContext = _useContext2.density;

  return density || densityFromContext;
} // TODO deprecate the above two functions

var useThemeProps = function useThemeProps() {
  // could just return the context, but not sure what else we might store
  var _useContext3 = React.useContext(ThemeContext),
      density = _useContext3.density,
      theme = _useContext3.theme;

  return {
    density: density,
    theme: theme
  };
};

// should we have some global; defaults ?
function breakpointReader(themeName, defaultBreakpoints) {
  //TODO ownerDocument
  var themeRoot = document.body.querySelector(".".concat(themeName));
  var handler = {
    get: function get(style, stopName) {
      var val = style.getPropertyValue( // lets assume we have the following naming convention
      "--".concat(themeName, "-breakpoint-").concat(stopName));
      return val ? parseInt(val) : undefined;
    }
  };
  return themeRoot ? new Proxy(getComputedStyle(themeRoot), handler) : defaultBreakpoints !== null && defaultBreakpoints !== void 0 ? defaultBreakpoints : {};
}

var byAsscendingStopSize = function byAsscendingStopSize(_ref, _ref2) {
  var _ref3 = _slicedToArray(_ref, 2),
      s1 = _ref3[1];

  var _ref4 = _slicedToArray(_ref2, 2),
      s2 = _ref4[1];

  return s1 - s2;
}; // These are assumed to be min-width (aka mobile-first) stops, we could take a
// paramneter to support max-width as well ?
// return [stopName, minWidth, maxWidth]


var breakpointRamp = function breakpointRamp(breakpoints) {
  return Object.entries(breakpoints).sort(byAsscendingStopSize).map(function (_ref5, i, all) {
    var _ref6 = _slicedToArray(_ref5, 2),
        name = _ref6[0],
        value = _ref6[1];

    return [name, value, i < all.length - 1 ? all[i + 1][1] : 9999];
  });
};
var documentBreakpoints = null;

var loadBreakpoints = function loadBreakpoints() {
  var themeName = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'uitk';

  // TODO would be nice to read these breakpoint labels from a css variable to
  // avoid hard-coding them here ?
  var _breakpointReader = breakpointReader(themeName),
      xs = _breakpointReader.xs,
      sm = _breakpointReader.sm,
      md = _breakpointReader.md,
      lg = _breakpointReader.lg,
      xl = _breakpointReader.xl;

  return breakpointRamp({
    xs: xs,
    sm: sm,
    md: md,
    lg: lg,
    xl: xl
  });
}; //TODO support multiple themes loaded


var getBreakPoints = function getBreakPoints(themeName) {
  if (documentBreakpoints === null) {
    documentBreakpoints = loadBreakpoints(themeName);
  }

  return documentBreakpoints;
};

var installTheme = function installTheme(themeId) {
  var installedThemes = getComputedStyle(document.body).getPropertyValue('--installed-themes');
  document.body.style.setProperty('--installed-themes', "".concat(installedThemes, " ").concat(themeId));
};

var DensityValues = ['high', 'medium', 'low', 'touch'];

function styleInject(css, ref) {
  if ( ref === void 0 ) ref = {};
  var insertAt = ref.insertAt;

  if (!css || typeof document === 'undefined') { return; }

  var head = document.head || document.getElementsByTagName('head')[0];
  var style = document.createElement('style');
  style.type = 'text/css';

  if (insertAt === 'top') {
    if (head.firstChild) {
      head.insertBefore(style, head.firstChild);
    } else {
      head.appendChild(style);
    }
  } else {
    head.appendChild(style);
  }

  if (style.styleSheet) {
    style.styleSheet.cssText = css;
  } else {
    style.appendChild(document.createTextNode(css));
  }
}

var css_248z = ".OverflowMenu {\n  /* width: 20px;\n  height: 20px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  cursor: pointer;\n  margin: 6px 0px 6px 0;\n  align-self: flex-end;\n  border: none;\n  border-radius: 0;\n  background-color: inherit;\n  padding: 0; */\n}\n\n/* .OverflowMenu-open {\n  backgroundcolor: active.overflow.background;\n} */\n\n/* .OverflowMenu-open .OverflowMenu-icon {\n  color: active.overflow.color;\n} */\n\n/* .Toolbar .Toolbar-overflow:hover {\n  background-color: lightgrey;\n} */\n\n[data-overflowed] {\n  order: 99;\n  /* visibility: hidden; */\n}\n";
styleInject(css_248z);

var OverflowMenu = /*#__PURE__*/React.forwardRef(function OverflowMenu(_ref, ref) {
  var _ref$iconName = _ref.iconName,
      iconName = _ref$iconName === void 0 ? 'more' : _ref$iconName,
      _ref$source = _ref.source,
      source = _ref$source === void 0 ? [] : _ref$source,
      rest = _objectWithoutProperties(_ref, ["iconName", "overflowOffsetLeft", "source"]);

  return source.length > 0 ? /*#__PURE__*/React__default['default'].createElement(toolkit$1.Dropdown, _extends({
    ListProps: {
      width: 200
    },
    ref: ref,
    source: source
  }, rest), function (_ref2) {
    var DropdownButtonProps = _ref2.DropdownButtonProps,
        isOpen = _ref2.isOpen;

    _objectWithoutProperties(DropdownButtonProps, ["style"]);

    var onClick = DropdownButtonProps.onClick,
        onKeyDown = DropdownButtonProps.onKeyDown,
        onFocus = DropdownButtonProps.onFocus,
        onBlur = DropdownButtonProps.onBlur;
    var defaultProps = {
      'data-jpmui-test': 'dropdown-button',
      'aria-label': 'toggle overflow',
      'aria-haspopup': true,
      className: classnames__default['default']('OverflowMenu-dropdown', {
        'OverflowMenu-open': isOpen
      }),
      onBlur: onBlur,
      onClick: onClick,
      onFocus: onFocus,
      onKeyDown: onKeyDown,
      title: 'Overflow Menu',
      type: 'button',
      variant: 'secondary'
    };
    return /*#__PURE__*/React__default['default'].createElement(toolkit$1.Button, defaultProps, /*#__PURE__*/React__default['default'].createElement(toolkit$1.Icon, {
      accessibleText: "overflow menu",
      className: "OverflowMenu-icon",
      name: iconName
    }));
  }) : null;
});
OverflowMenu.defaultProps = {
  PopperProps: {
    modifiers: {
      offset: {
        offset: '0, 0'
      }
    },
    placement: 'bottom-end'
  } // placeholder: "",

};

var observedMap = new Map();
var isScrollAttribute = {
  scrollHeight: true,
  scrollWidth: true
}; // TODO should we make this create-on-demand

var resizeObserver = new ResizeObserver(function (entries) {
  var _iterator = _createForOfIteratorHelper(entries),
      _step;

  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var entry = _step.value;
      var target = entry.target,
          contentRect = entry.contentRect;

      if (observedMap.has(target)) {
        var _observedMap$get = observedMap.get(target),
            onResize = _observedMap$get.onResize,
            measurements = _observedMap$get.measurements;

        var sizeChanged = false;

        for (var _i = 0, _Object$entries = Object.entries(measurements); _i < _Object$entries.length; _i++) {
          var _Object$entries$_i = _slicedToArray(_Object$entries[_i], 2),
              dimension = _Object$entries$_i[0],
              size = _Object$entries$_i[1];

          var newSize = isScrollAttribute[dimension] ? target[dimension] : contentRect[dimension];

          if (newSize !== size) {
            sizeChanged = true;
            measurements[dimension] = newSize;
          }
        }

        if (sizeChanged) {
          // TODO only return measured sizes
          // const { height, width } = contentRect;
          onResize && onResize(measurements);
        }
      }
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }
}); // TODO use an optional lag (default to false) to ask to fire onResize
// with initial size

function useResizeObserver(ref, dimensions, onResize) {
  var dimensionsRef = React.useRef(dimensions);
  var measure = React.useCallback(function (target) {
    var rect = target.getBoundingClientRect();
    return dimensionsRef.current.reduce(function (map, dim) {
      if (isScrollAttribute[dim]) {
        map[dim] = target[dim];
      } else {
        map[dim] = rect[dim];
      }

      return map;
    }, {});
  }, []); // TODO use ref to store resizeHandler here
  // resize handler registered with REsizeObserver will never change
  // use ref to store user onResize callback here
  // resizeHandler will call user callback.current
  // Keep this effect separate in case user inadvertently passes different
  // dimensions or callback instance each time - we only ever want to
  // initiate new observation when ref changes.

  React.useEffect(function () {
    var target = ref.current;

    function registerObserver() {
      return _registerObserver.apply(this, arguments);
    }

    function _registerObserver() {
      _registerObserver = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        var measurements;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                // Create the map entry immediately. useEffect may fire below
                // before fonts are ready and attempt to update entry
                observedMap.set(target, {
                  measurements: []
                });
                _context.next = 3;
                return document.fonts.ready;

              case 3:
                measurements = measure(target);
                observedMap.get(target).measurements = measurements;
                resizeObserver.observe(target);

              case 6:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));
      return _registerObserver.apply(this, arguments);
    }

    if (target) {
      // TODO might we want multiple callers to attach a listener to the same element ?
      if (observedMap.has(target)) {
        throw Error('useResizeObserver attemping to observe same element twice');
      } // TODO set a pending entry on map


      registerObserver();
    }

    return function () {
      if (target && observedMap.has(target)) {
        resizeObserver.unobserve(target);
        observedMap["delete"](target);
      }
    };
  }, [measure, ref]);
  React.useEffect(function () {
    var target = ref.current;
    var record = observedMap.get(target);

    if (record) {
      if (dimensionsRef.current !== dimensions) {
        dimensionsRef.current = dimensions;
        var measurements = measure(target);
        record.measurements = measurements;
      } // Might not have changed, but no harm ...


      record.onResize = onResize;
    }
  }, [dimensions, measure, ref, onResize]); // TODO might be a good idea to ref and return the current measurememnts. That way, derived hooks
  // e.g useBreakpoints don't have to measure and client cn make onResize callback simpler
}

var EMPTY_ARRAY = []; // TODO how do we cater for smallerThan/greaterThan breakpoints

function useBreakpoints(_ref, ref) {
  var breakPointsProp = _ref.breakPoints,
      smallerThan = _ref.smallerThan;

  var _useState = React.useState(smallerThan ? false : 'lg'),
      _useState2 = _slicedToArray(_useState, 2),
      breakpointMatch = _useState2[0],
      setBreakpointmatch = _useState2[1];

  var bodyRef = React.useRef(document.body);
  var breakPointsRef = React.useRef(breakPointsProp ? breakpointRamp(breakPointsProp) : getBreakPoints()); // TODO how do we identify the default

  var sizeRef = React.useRef('lg');
  var stopFromMinWidth = React.useCallback(function (w) {
    if (breakPointsRef.current) {
      var _iterator = _createForOfIteratorHelper(breakPointsRef.current),
          _step;

      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var _step$value = _slicedToArray(_step.value, 2),
              name = _step$value[0],
              size = _step$value[1];

          if (w >= size) {
            return name;
          }
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }
  }, [breakPointsRef]);
  var matchSizeAgainstBreakpoints = React.useCallback(function (width) {
    console.log("matchSizeAgainstBreakpoints smallerThan ".concat(smallerThan));

    if (smallerThan) {
      var _breakPointsRef$curre = breakPointsRef.current.find(function (_ref2) {
        var _ref3 = _slicedToArray(_ref2, 1),
            name = _ref3[0];

        return name === smallerThan;
      }),
          _breakPointsRef$curre2 = _slicedToArray(_breakPointsRef$curre, 3),
          maxValue = _breakPointsRef$curre2[2];

      return width < maxValue;
    } else {
      return stopFromMinWidth(width);
    }
  }, [smallerThan, stopFromMinWidth]); // TODO need to make the dimension a config

  useResizeObserver(ref || bodyRef, breakPointsRef.current ? ['width'] : EMPTY_ARRAY, function (_ref4) {
    var measuredWidth = _ref4.width;
    console.log('resize');
    var result = matchSizeAgainstBreakpoints(measuredWidth);

    if (result !== sizeRef.current) {
      sizeRef.current = result;
      setBreakpointmatch(result);
    }
  });
  React.useEffect(function () {
    var target = ref || bodyRef;

    if (target.current) {
      var prevSize = sizeRef.current;

      if (breakPointsRef.current) {
        // We're measuring here when the resizeObserver has also measured
        // There isn't a convenient way to get the Resizeobserver to
        // notify initial size - that's not really its job, unless we
        // set a flag ?
        var clientWidth = target.current.clientWidth;
        var result = matchSizeAgainstBreakpoints(clientWidth);
        sizeRef.current = result; // If initial size of ref does not match the default, notify client after render

        if (result !== prevSize) {
          setBreakpointmatch(result);
        }
      }
    }
  }, [setBreakpointmatch, matchSizeAgainstBreakpoints, ref]);
  return breakpointMatch;
}

var LEFT_RIGHT = ["left", "right"];
var TOP_BOTTOM = ["top", "bottom"];
function measureMinimumNodeSize(node) {
  var dimension = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "width";

  var _node$getBoundingClie = node.getBoundingClientRect(),
      size = _node$getBoundingClie[dimension];

  var _node$dataset = node.dataset,
      _node$dataset$padRigh = _node$dataset.padRight,
      padRight = _node$dataset$padRigh === void 0 ? false : _node$dataset$padRigh,
      _node$dataset$padLeft = _node$dataset.padLeft,
      padLeft = _node$dataset$padLeft === void 0 ? false : _node$dataset$padLeft;
  var style = getComputedStyle(node);

  var _ref = dimension === "width" ? LEFT_RIGHT : TOP_BOTTOM,
      _ref2 = _slicedToArray(_ref, 2),
      start = _ref2[0],
      end = _ref2[1];

  var marginStart = padLeft ? 0 : parseInt(style.getPropertyValue("margin-".concat(start)), 10);
  var marginEnd = padRight ? 0 : parseInt(style.getPropertyValue("margin-".concat(end)), 10);
  var minWidth = size;
  var flexShrink = parseInt(style.getPropertyValue("flex-shrink", 10));

  if (flexShrink > 0) {
    var flexBasis = parseInt(style.getPropertyValue("flex-basis", 10)); // TODO what about percentage values ?

    if (!isNaN(flexBasis)) {
      minWidth = flexBasis;
    }
  }

  return marginStart + minWidth + marginEnd;
}

var MONITORED_DIMENSIONS = {
  horizontal: ['width', 'scrollHeight'],
  vertical: ['height', 'scrollWidth'],
  none: []
};
var NO_OVERFLOW_INDICATOR = {};
var NO_DATA = {};
var UNCOLLAPSED_DYNAMIC_ITEMS = '[data-collapsible="dynamic"]:not([data-collapsed="true"]):not([data-collapsing="true"])';

var addAll = function addAll(sum, m) {
  return sum + m.size;
};

var addAllExceptOverflowIndicator = function addAllExceptOverflowIndicator(sum, m) {
  return sum + (m.isOverflowIndicator ? 0 : m.size);
}; // There should be no collapsible items here that are not already collapsed
// otherwise we would be collapsing, not overflowing


var lastOverflowableItem = function lastOverflowableItem(arr) {
  for (var i = arr.length - 1; i >= 0; i--) {
    var item = arr[i]; // TODO should we support a no-overflow attribute (maybe a priority 0)
    // to prevent an item from overflowing ?
    // TODO when all collapsible items are collapsed and we start overflowing,
    // should we leave collapsed items to last in the overflow priority ?

    if (!item.isOverflowIndicator) {
      return item;
    }
  }

  return null;
};

var OVERFLOWING = 1000;

var collapsedOnly = function collapsedOnly(status) {
  return status > 0 && status < 1000;
};

var includesOverflow = function includesOverflow(status) {
  return status >= OVERFLOWING;
};

var lastListItem = function lastListItem(listRef) {
  return listRef.current[listRef.current.length - 1];
};

var newlyCollapsed = function newlyCollapsed(visibleItems) {
  return visibleItems.some(function (item) {
    return item.collapsed && item.fullWidth === null;
  });
};

var hasUncollapsedDynamicItems = function hasUncollapsedDynamicItems(containerRef) {
  return containerRef.current.querySelector(UNCOLLAPSED_DYNAMIC_ITEMS) !== null;
};

var moveOverflowItem = function moveOverflowItem(fromStack, toStack) {
  var item = lastOverflowableItem(fromStack.current);

  if (item) {
    fromStack.current = fromStack.current.filter(function (i) {
      return i !== item;
    });
    toStack.current = toStack.current.concat(item);
    return item;
  } else {
    return null;
  }
};

var byDescendingPriority = function byDescendingPriority(m1, m2) {
  var result = m1.priority - m2.priority;

  if (result === 0) {
    result = m1.index - m2.index;
  }

  return result;
};

var getOverflowIndicator = function getOverflowIndicator(visibleRef) {
  return visibleRef.current.find(function (item) {
    return item.isOverflowIndicator;
  });
};

var Dimensions = {
  horizontal: {
    size: 'clientWidth',
    depth: 'clientHeight',
    scrollDepth: 'scrollHeight'
  },
  vertical: {
    size: 'clientHeight',
    depth: 'clientWidth',
    scrollDepth: 'scrollWidth'
  }
};

var measureContainerOverflow = function measureContainerOverflow(_ref) {
  var innerEl = _ref.current;
  var orientation = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'horizontal';
  var dim = Dimensions[orientation];
  var containerDepth = innerEl.parentNode[dim.depth];
  var scrollDepth = innerEl[dim.scrollDepth],
      contentSize = innerEl[dim.size];
  var isOverflowing = containerDepth < scrollDepth;
  return [isOverflowing, contentSize, containerDepth];
};

var useOverflowStatus = function useOverflowStatus() {
  var _useState = React.useState(null),
      _useState2 = _slicedToArray(_useState, 2),
      forceUpdate = _useState2[1]; // TODO make this easier to understand by storing the overflow and
  // collapse status as separate reference count fields


  var _useState3 = React.useState(0),
      _useState4 = _slicedToArray(_useState3, 2),
      overflowing = _useState4[0],
      _setOverflowing = _useState4[1];

  var overflowingRef = React.useRef(0);
  var setOverflowing = React.useCallback(function (value) {
    _setOverflowing(overflowingRef.current = value);
  }, [_setOverflowing]);
  var updateOverflowStatus = React.useCallback(function (value, force) {
    if (Math.abs(value) === OVERFLOWING) {
      if (value > 0 && !includesOverflow(overflowingRef.current)) {
        setOverflowing(overflowingRef.current + value);
      } else if (value < 0 && includesOverflow(overflowingRef.current)) {
        setOverflowing(overflowingRef.current + value);
      } else {
        forceUpdate({});
      }
    } else if (value !== 0) {
      setOverflowing(overflowingRef.current + value);
    } else if (force) {
      forceUpdate({});
    }
  }, [forceUpdate, overflowingRef, setOverflowing]);
  return [overflowingRef, overflowing, updateOverflowStatus];
};

var measureChildNodes = function measureChildNodes(_ref2, dimension) {
  var innerEl = _ref2.current;
  var measurements = Array.from(innerEl.childNodes).reduce(function (list, node, i) {
    var _node$dataset;

    var _ref3 = (_node$dataset = node === null || node === void 0 ? void 0 : node.dataset) !== null && _node$dataset !== void 0 ? _node$dataset : NO_DATA,
        collapsible = _ref3.collapsible,
        collapsed = _ref3.collapsed,
        collapsing = _ref3.collapsing,
        index = _ref3.index,
        _ref3$priority = _ref3.priority,
        priority = _ref3$priority === void 0 ? '1' : _ref3$priority,
        overflowIndicator = _ref3.overflowIndicator,
        overflowed = _ref3.overflowed;

    if (index) {
      var size = measureMinimumNodeSize(node, dimension);

      if (overflowed) {
        delete node.dataset.overflowed;
      }

      list.push({
        collapsible: collapsible,
        collapsed: collapsible ? collapsed === 'true' : undefined,
        collapsing: collapsing,
        // only to be populated in case of collapse
        // TODO check the role of this - especially the way we check it in useEffect
        // to detect collapse
        fullSize: null,
        index: parseInt(index, 10),
        isOverflowIndicator: overflowIndicator,
        label: node.title || node.innerText,
        priority: parseInt(priority, 10),
        size: size
      });
    }

    return list;
  }, []);
  return measurements.sort(byDescendingPriority);
};

var getElementForItem = function getElementForItem(ref, item) {
  return ref.current.querySelector(":scope > [data-index='".concat(item.index, "']"));
}; // value could be anything which might require a re-evaluation. In the case of tabs
// we might have selected an overflowed tab. Can we make this more efficient, only
// needs action if an overflowed item re-enters the visible section


function useOverflowObserver() {
  var orientation = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'horizontal';
  var label = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
  var ref = React.useRef(null);

  var _useOverflowStatus = useOverflowStatus(),
      _useOverflowStatus2 = _slicedToArray(_useOverflowStatus, 3),
      overflowingRef = _useOverflowStatus2[0],
      overflowing = _useOverflowStatus2[1],
      updateOverflowStatus = _useOverflowStatus2[2]; // const [, forceUpdate] = useState();


  var visibleRef = React.useRef([]);
  var overflowedRef = React.useRef([]);
  var collapsedRef = React.useRef([]);
  var collapsingRef = React.useRef(false);
  var rootDepthRef = React.useRef(null);
  var containerSizeRef = React.useRef(null);
  var horizontalRef = React.useRef(orientation === 'horizontal');
  var overflowIndicatorSizeRef = React.useRef(36); // should default by density

  var minSizeRef = React.useRef(0);
  var setContainerMinSize = React.useCallback(function (size) {
    var isHorizontal = horizontalRef.current;

    if (size === undefined) {
      var dimension = isHorizontal ? 'width' : 'height';

      var _ref$current$getBound = ref.current.getBoundingClientRect();

      size = _ref$current$getBound[dimension];
    }

    minSizeRef.current = size;
    var styleDimension = isHorizontal ? 'minWidth' : 'minHeight';
    ref.current.style[styleDimension] = size + 'px';
  }, [ref]);
  var markOverflowingItems = React.useCallback(function (visibleContentSize, containerSize) {
    var result = 0; // First pass, see if there is a collapsible item we can collapse. We won't
    // know how much space this frees up until the thing has re-rendered, so this
    // may kick off a chain of renders and remeasures if there are multiple collapsible
    // items and each yields only a part of the shrinkage we need to apply.
    //  That's the worst case scenario.

    if (visibleRef.current.some(function (item) {
      return item.collapsible && !item.collapsed;
    })) {
      for (var i = visibleRef.current.length - 1; i >= 0; i--) {
        var item = visibleRef.current[i];

        if (item.collapsible === 'instant' && !item.collapsed) {
          item.collapsed = true;
          var target = getElementForItem(ref, item);
          target.dataset.collapsed = true;
          collapsedRef.current.push(item); // We only ever collapse 1 item at a time. We now need to wait for
          // it to render, so we can re-measure and determine how much space
          // this has saved.

          return 1;
        } else if (item.collapsible === 'dynamic' && !item.collapsed && !item.collapsing) {
          item.collapsing = true;

          var _target = getElementForItem(ref, item);

          _target.dataset.collapsing = true;
          collapsedRef.current.push(item);
          ref.current.dataset.collapsing = true; // We only ever collapse 1 item at a time. We now need to wait for
          // it to render, so we can re-measure and determine how much space
          // this has saved.

          return 1;
        }
      }
    } // If no collapsible items, movin items from visible to overflowed queues


    while (visibleContentSize > containerSize) {
      var overflowedItem = moveOverflowItem(visibleRef, overflowedRef);

      if (overflowedItem === null) {
        // unable to overflow, all items are collapsed, this is our minimum width,
        // enforce it ...
        // TODO what if density changes
        //TODO probably not right, now we overflow even collapsed items, min width should be
        // overflow indicator width plus width of any non-overflowable items
        setContainerMinSize(visibleContentSize);
        break;
      }

      visibleContentSize -= overflowedItem.size;

      var _target2 = getElementForItem(ref, overflowedItem);

      _target2.dataset.overflowed = true;
      result = OVERFLOWING;
    }

    return result;
  }, []);
  var removeOverflowIfSpaceAllows = React.useCallback(function (containerSize) {
    var result = 0; // TODO calculate this without using fullWidth if we have OVERFLOW
    // Need a loop here where we first remove OVERFLOW, then potentially remove
    // COLLAPSE too
    // We want to re-introduce overflowed items before we start to restore collapsed items
    // When we are dealing with overflowed items, we just use the current width of collapsed items.

    var visibleContentSize = visibleRef.current.reduce(addAllExceptOverflowIndicator, 0);
    var diff = containerSize - visibleContentSize;

    if (collapsedOnly(overflowingRef.current)) {
      // find the next collapsed item, see how much extra space it would
      // occupy if restored. If we have enough space, restore it.
      while (collapsedRef.current.length) {
        var item = lastListItem(collapsedRef);
        var itemDiff = item.fullSize - item.size;

        if (diff >= itemDiff) {
          item.collapsed = false;
          item.size = item.fullSize; // Be careful before setting this to null, check the code in useEffect

          delete item.fullSize;
          var target = getElementForItem(ref, item);
          collapsedRef.current.pop();
          delete target.dataset.collapsed;
          diff = diff - itemDiff;
          result += 1;
        } else {
          break;
        }
      }

      return result;
    } else {
      while (overflowedRef.current.length > 0) {
        var _lastListItem = lastListItem(overflowedRef),
            nextSize = _lastListItem.size;

        if (diff >= nextSize) {
          var _ref4 = getOverflowIndicator(visibleRef) || NO_OVERFLOW_INDICATOR,
              _ref4$size = _ref4.size,
              overflowSize = _ref4$size === void 0 ? 0 : _ref4$size; // we can only ignore the width of overflow Indicator if either there is only one remaining
          // overflow item (so overflowIndicator will be removed) or diff is big enough to accommodate
          // the overflow Ind.


          if (overflowedRef.current.length === 1 || diff >= nextSize + overflowSize) {
            var overflowedItem = moveOverflowItem(overflowedRef, visibleRef);
            visibleContentSize += overflowedItem.size;

            var _target3 = getElementForItem(ref, overflowedItem);

            delete _target3.dataset.overflowed;
            diff = diff - overflowedItem.size;
            result = OVERFLOWING;
          } else {
            break;
          }
        } else {
          break;
        }
      }
    } // DOn't return OVERFLOWING unless there is no more overflow


    return result;
  }, [overflowingRef]);
  var initializeDynamicContent = React.useCallback(function () {
    var renderedSize = visibleRef.current.reduce(addAll, 0);
    var diff = renderedSize - containerSizeRef.current;

    for (var i = visibleRef.current.length - 1; i >= 0; i--) {
      var item = visibleRef.current[i];

      if (item.collapsible && !item.collapsed) {
        var target = getElementForItem(ref, item); // TODO where do we derive min width 28 + 8

        if (diff > item.size - 36) {
          // We really want to know if it has reached min-width, but we will have to
          // wait for it to render
          target.dataset.collapsed = item.collapsed = true;
          diff -= item.size;
        } else {
          target.dataset.collapsing = item.collapsing = true;
          break;
        }
      }
    }
  }, [containerSizeRef, ref, visibleRef]);
  var collapseCollapsingItem = React.useCallback(function (item, target) {
    target.dataset.collapsing = item.collapsing = false;
    target.dataset.collapsed = item.collapsed = true;
    var rest = visibleRef.current.filter(function (_ref5) {
      var collapsible = _ref5.collapsible,
          collapsed = _ref5.collapsed;
      return collapsible === 'dynamic' && !collapsed;
    });
    var last = rest.pop();

    if (last) {
      var lastTarget = getElementForItem(ref, last);
      lastTarget.dataset.collapsing = last.collapsing = true;
    } else {
      // Set minSize to current measured size
      // TODO check that this makes sense...suspect it doesn't
      setContainerMinSize();
    }
  }, [setContainerMinSize]);
  var restoreCollapsingItem = React.useCallback(function (item, target) {
    target.dataset.collapsing = item.collapsing = false; // we might have an opportunity to switch the next collapsed item to
    // collapsing here. If we don't do this, it will ge handled in the next resize
  }, []);
  var checkDynamicContent = React.useCallback(function (containerHasGrown) {
    // The order must matter here
    var collapsingItem = visibleRef.current.find(function (_ref6) {
      var collapsible = _ref6.collapsible,
          collapsing = _ref6.collapsing;
      return collapsible === 'dynamic' && collapsing;
    });
    var collapsedItem = visibleRef.current.find(function (_ref7) {
      var collapsible = _ref7.collapsible,
          collapsed = _ref7.collapsed;
      return collapsible === 'dynamic' && collapsed;
    });

    if (collapsingItem === undefined && collapsedItem === undefined) {
      return;
    }

    if (collapsingItem === undefined) {
      var _target4 = getElementForItem(ref, collapsedItem);

      _target4.dataset.collapsed = collapsedItem.collapsed = false;
      _target4.dataset.collapsing = collapsedItem.collapsing = true;
      return;
    }

    var target = getElementForItem(ref, collapsingItem);
    var dimension = horizontalRef.current ? 'width' : 'height';

    var _target$getBoundingCl = target.getBoundingClientRect(),
        size = _target$getBoundingCl[dimension];

    if (containerHasGrown && collapsedItem) {
      // We don't restore a collapsing item unless there is at least one collapsed item
      if (collapsedItem && size === collapsingItem.size) {
        restoreCollapsingItem(collapsingItem, target);
      }
    } else {
      var style = getComputedStyle(target);
      var minSize = parseInt(style.getPropertyValue("min-".concat(dimension)));

      if (size === minSize) {
        collapseCollapsingItem(collapsingItem, target);
      }
    }
  }, [collapseCollapsingItem, restoreCollapsingItem]);
  var resetMeasurements = React.useCallback(function () {
    var _measureContainerOver = measureContainerOverflow(ref, orientation),
        _measureContainerOver2 = _slicedToArray(_measureContainerOver, 3),
        isOverflowing = _measureContainerOver2[0],
        innerContainerSize = _measureContainerOver2[1],
        rootContainerDepth = _measureContainerOver2[2];

    containerSizeRef.current = innerContainerSize;
    rootDepthRef.current = rootContainerDepth;
    var hasDynamicItems = hasUncollapsedDynamicItems(ref);

    if (hasDynamicItems || isOverflowing) {
      var dimension = horizontalRef.current ? 'width' : 'height';
      var measurements = measureChildNodes(ref, dimension);
      visibleRef.current = measurements;
      overflowedRef.current = [];
    }

    if (hasDynamicItems) {
      // if we don't have overflow, but we do have dynamic collapse items, we need to monitor resize events
      //  to determine when the collapsing item reaches min-width. At which point it becomes collapsed, and
      // the next dynanic collapse item assumes collapsing status
      collapsingRef.current = true;
      ref.current.dataset.collapsing = true;

      if (isOverflowing) {
        // We will only encounter this scenario first-time in. Once we initialize for dynamic content,
        // there will be no more overflow (unless we decide to re-enable overflow once all dynamic
        // items are collapsed ).
        initializeDynamicContent();
      } else {
        var collapsingItem = lastListItem(visibleRef);
        var element = getElementForItem(ref, collapsingItem);
        element.dataset.collapsing = collapsingItem.collapsing = true;
      }
    } else if (isOverflowing) {
      // We may already have an overflowIndicator here, if caller is Tabstrip
      var renderedSize = visibleRef.current.reduce(addAllExceptOverflowIndicator, 0);
      var result = markOverflowingItems(renderedSize, innerContainerSize - overflowIndicatorSizeRef.current);
      updateOverflowStatus(+result);
    }
  }, [initializeDynamicContent, markOverflowingItems, orientation, updateOverflowStatus]);
  var resizeHandler = React.useCallback(function (_ref8) {
    var scrollHeight = _ref8.scrollHeight,
        _ref8$height = _ref8.height,
        height = _ref8$height === void 0 ? scrollHeight : _ref8$height,
        scrollWidth = _ref8.scrollWidth,
        _ref8$width = _ref8.width,
        width = _ref8$width === void 0 ? scrollWidth : _ref8$width;

    var _ref9 = horizontalRef.current ? [width, height] : [height, width],
        _ref10 = _slicedToArray(_ref9, 2),
        size = _ref10[0],
        depth = _ref10[1];

    var wasFullSize = overflowingRef.current === 0;
    var overflowDetected = depth > rootDepthRef.current;
    var containerHasGrown = size > containerSizeRef.current;
    containerSizeRef.current = size; // if (label === 'Tabstrip') {

    console.log("%cresizeHandler<".concat(label, ">\n%ccontainer grown\t").concat(containerHasGrown ? '✓' : '✗', "\noverflowDetected\t").concat(overflowDetected ? '✓' : '✗', "\ncontainerDepth=").concat(depth, " containerSize=").concat(size, "\n"), 'color:brown;font-weight: bold;', 'color:brown;'); // }

    if (containerHasGrown && size === minSizeRef.current) ; else if (collapsingRef.current) {
      checkDynamicContent(containerHasGrown);
    } else if (!wasFullSize && containerHasGrown) {
      var result = removeOverflowIfSpaceAllows(size); // Don't remove the overflowing status if there are remaining overflowed item(s).
      // Unlike collapsed items, overflowed is not a reference count.

      if (result !== OVERFLOWING || overflowedRef.current.length === 0) {
        updateOverflowStatus(-result);
      } else if (result === OVERFLOWING) {
        updateOverflowStatus(0, true);
      }
    } else if (wasFullSize && overflowDetected) {
      // TODO if client is not using an overflow indicator, there is nothing to do here,
      // just let nature take its course. How do we know this ?
      // This is when we need to add width to measurements we are tracking
      resetMeasurements();
    } else if (!wasFullSize && overflowDetected) {
      // we're still overflowing
      var renderedSize = visibleRef.current.reduce(addAll, 0);

      if (size < renderedSize) {
        var _result = markOverflowingItems(renderedSize, size);

        updateOverflowStatus(+_result);
      }
    }
  }, [checkDynamicContent, label, removeOverflowIfSpaceAllows, resetMeasurements, markOverflowingItems, overflowingRef, updateOverflowStatus]);
  React.useLayoutEffect(function () {
    var dimension = horizontalRef.current ? 'width' : 'height';

    if (newlyCollapsed(visibleRef.current)) {
      // These are in reverse priority order, so last collapsed will always be first
      var _visibleRef$current$f = visibleRef.current.filter(function (item) {
        return item.collapsed;
      }),
          _visibleRef$current$f2 = _slicedToArray(_visibleRef$current$f, 1),
          collapsedItem = _visibleRef$current$f2[0];

      if (collapsedItem.fullSize === null) {
        var target = getElementForItem(ref, collapsedItem);

        if (target) {
          var collapsedSize = measureMinimumNodeSize(target, dimension);
          collapsedItem.fullSize = collapsedItem.size;
          collapsedItem.size = collapsedSize; // is the difference between collapsed size and original size enough ?
          // TODO we repeat this code a lot, factoer it out

          var renderedSize = visibleRef.current.reduce(addAll, 0);

          if (renderedSize > containerSizeRef.current) {
            var strategy = markOverflowingItems(renderedSize, containerSizeRef.current - overflowIndicatorSizeRef.current);
            updateOverflowStatus(+strategy);
          }
        }
      }
    } else if (includesOverflow(overflowing)) {
      var _target5 = ref.current.querySelector(":scope > [data-overflow-indicator='true']");

      if (_target5) {
        var _target5$dataset;

        var _ref11 = (_target5$dataset = _target5 === null || _target5 === void 0 ? void 0 : _target5.dataset) !== null && _target5$dataset !== void 0 ? _target5$dataset : NO_DATA,
            index = _ref11.index,
            _ref11$priority = _ref11.priority,
            priority = _ref11$priority === void 0 ? '1' : _ref11$priority;

        var item = {
          index: parseInt(index, 10),
          isOverflowIndicator: true,
          priority: parseInt(priority, 10),
          label: _target5.innerText,
          size: measureMinimumNodeSize(_target5, dimension)
        };
        overflowIndicatorSizeRef.current = item.size;
        visibleRef.current = visibleRef.current.concat(item).sort(byDescendingPriority);
      }
    } else if (getOverflowIndicator(visibleRef)) {
      visibleRef.current = visibleRef.current.filter(function (item) {
        return !item.isOverflowIndicator;
      });
    }
  }, [markOverflowingItems, overflowing, ref, updateOverflowStatus, visibleRef]); // Measurement occurs post-render, by necessity, need to trigger a render

  React.useLayoutEffect(function () {
    function measure() {
      return _measure.apply(this, arguments);
    }

    function _measure() {
      _measure = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return document.fonts.ready;

              case 2:
                if (ref.current !== null) {
                  resetMeasurements();
                }

              case 3:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));
      return _measure.apply(this, arguments);
    }

    if (orientation !== 'none') {
      measure();
    }
  }, [label, orientation, resetMeasurements]);
  useResizeObserver(ref, MONITORED_DIMENSIONS[orientation], resizeHandler);
  return [ref, overflowedRef.current, collapsedRef.current, resetMeasurements];
}

var _RESPONSIVE_ATTRIBUTE;

var COLLAPSIBLE = 'data-collapsible';
var RESPONSIVE_ATTRIBUTE = (_RESPONSIVE_ATTRIBUTE = {}, _defineProperty(_RESPONSIVE_ATTRIBUTE, COLLAPSIBLE, true), _defineProperty(_RESPONSIVE_ATTRIBUTE, 'data-pad-left', true), _defineProperty(_RESPONSIVE_ATTRIBUTE, 'data-pad-right', true), _RESPONSIVE_ATTRIBUTE);
var isResponsiveAttribute = function isResponsiveAttribute(propName) {
  return RESPONSIVE_ATTRIBUTE[propName];
};

var isCollapsible = function isCollapsible(propName) {
  return propName === COLLAPSIBLE;
};

var COLLAPSIBLE_VALUE = {
  dynanic: 'dynamic',
  instant: 'instant',
  "true": 'instant'
};

var collapsibleValue = function collapsibleValue(value) {
  var _COLLAPSIBLE_VALUE$va;

  return (_COLLAPSIBLE_VALUE$va = COLLAPSIBLE_VALUE[value]) !== null && _COLLAPSIBLE_VALUE$va !== void 0 ? _COLLAPSIBLE_VALUE$va : 'none';
};

var extractResponsiveProps = function extractResponsiveProps(props) {
  return Object.keys(props).reduce(function (result, propName) {
    var _result = _slicedToArray(result, 2),
        toolbarProps = _result[0],
        rest = _result[1];

    if (isResponsiveAttribute(propName)) {
      var value = isCollapsible(propName) ? collapsibleValue(props[propName]) : props[propName];
      toolbarProps[propName] = value;
      rest[propName] = undefined;
    }

    return result;
  }, [{}, {}]);
};

var css_248z$1 = ".uitk-light {\n  --appheader-separator: var(--uitk-grey40);\n}\n.uitk-dark {\n  --appheader-separator: var(--uitk-grey400);\n}\n\n.AppHeader-touchDensity {\n  --appheader-height: 76px;\n}\n\n.AppHeader-lowDensity {\n  --appheader-height: 60px;\n}\n\n.AppHeader-mediumDensity {\n  --appheader-height: 44px;\n}\n\n.AppHeader-highDensity {\n  --appheader-height: 32px;\n}\n\n.AppHeader {\n  --appheader-padding: calc(var(--uitk-space) * 3);\n  align-items: flex-start;\n  border-bottom: solid 1px var(--uitk-grey60);\n  box-shadow: var(--elevation2);\n  box-sizing: border-box;\n  display: flex;\n  height: var(--appheader-height);\n  overflow: hidden;\n  padding: 0 var(--appheader-padding);\n  width: 100%;\n}\n\n.AppHeader-innerContainer {\n  align-items: flex-end;\n  width: 100%;\n  overflow: hidden;\n  display: flex;\n  flex-wrap: wrap;\n  /* justify-content: space-between; */\n  flex: 1;\n  min-height: var(--appheader-height);\n}\n\n.AppHeader-innerContainer > .responsive-pillar {\n  width: 0;\n  height: var(--appheader-height);\n}\n\n.AppHeader-innerContainer > *:not(:last-child) {\n  /* margin-right: 48px; */\n}\n\n.AppHeader-navMenu {\n  margin-right: 12px;\n  padding-right: 8px;\n}\n\n.AppHeader-navMenu::after {\n  top: 0;\n  right: 0;\n  width: 1px;\n  bottom: 0;\n  content: '';\n  position: absolute;\n  background: var(--appheader-separator);\n}\n\n.AppHeader .Logo {\n  flex: 0 0 auto;\n  min-height: var(--appheader-height);\n}\n\n.AppHeader-innerContainer > .Tabstrip {\n  align-self: flex-end;\n  flex: 0 0 auto;\n  margin-left: 48px;\n}\n\n.AppHeader-innerContainer > [data-pad-left] {\n  margin-left: auto;\n}\n\n.AppHeader-innerContainer > [data-pad-right] {\n  margin-right: auto;\n}\n\n.AppHeader-innerContainer > .Toolbar {\n  justify-content: flex-end;\n  margin-left: 48px;\n}\n";
styleInject(css_248z$1);

var AppHeader = function AppHeader(_ref) {
  var children = _ref.children,
      className = _ref.className,
      densityProp = _ref.density,
      id = _ref.id,
      style = _ref.style;
  var density = useDensity(densityProp);

  var _useOverflowObserver = useOverflowObserver('horizontal'),
      _useOverflowObserver2 = _slicedToArray(_useOverflowObserver, 2),
      innerContainerRef = _useOverflowObserver2[0],
      overflowedItems = _useOverflowObserver2[1];

  return /*#__PURE__*/React__default['default'].createElement("div", {
    className: classnames__default['default']('AppHeader', "AppHeader-".concat(density, "Density"), className),
    id: id,
    style: style
  }, /*#__PURE__*/React__default['default'].createElement("div", {
    className: "AppHeader-innerContainer",
    ref: innerContainerRef
  }, /*#__PURE__*/React__default['default'].createElement(OverflowMenu, {
    className: "AppHeader-navMenu",
    iconName: "menu-burger",
    source: overflowedItems
  }), children));
};

var emptyClassName = "";
var IconClassNameContext = /*#__PURE__*/React.createContext(emptyClassName);
var Provider = IconClassNameContext.Provider,
    IconClassNameConsumer = IconClassNameContext.Consumer;

var IconClassNameProvider = function IconClassNameProvider(_ref) {
  var children = _ref.children,
      className = _ref.value;
  return /*#__PURE__*/React__default['default'].createElement(IconClassNameConsumer, null, function (outerClassName) {
    return /*#__PURE__*/React__default['default'].createElement(Provider, {
      value: classnames__default['default'](className, outerClassName)
    }, children);
  });
};

IconClassNameProvider.propTypes = {
  /**
   * You can wrap a node.
   */
  children: PropTypes__default['default'].node,

  /**
   * The CSS class name of `Icon`.
   */
  value: PropTypes__default['default'].string
};

var css_248z$2 = ".uitkButton {\n  align-items: center;\n  appearance: none;\n  border: 0;\n  border-radius: 0;\n  cursor: pointer;\n  display: inline-block;\n  height: var(--uitk-size-regular, 28px);\n  justify-content: center;\n  line-height: 1.3;\n  margin: 0;\n  min-width: 0;\n  min-height: 0;\n  padding: 0 var(--uitk-space);\n  position: relative;\n  text-align: center;\n  text-decoration: none;\n  transition: none;\n  user-select: none;\n  vertical-align: middle;\n  -webkit-appearance: none;\n  -webkit-tap-highlight-color: transparent;\n  width: var(--uitk-button-width);\n}\n\n.uitkButton-label {\n  align-items: center;\n  display: flex;\n  height: 100%;\n  justify-content: inherit;\n  position: relative;\n  white-space: pre;\n  width: 100%;\n}\n\n.uitkButton-icon {\n  letter-spacing: 0;\n}\n\n.uitkButton:not(:focus-visible) {\n  outline: 1px solid transparent;\n}\n\n.uitkButton:focus-visible {\n  outline-color: #2670a9;\n  outline-style: dotted;\n  outline-width: 2px;\n  outline-offset: 0;\n}\n\n.uitkButton-regular {\n  background: var(--uitk-action-regular-default-background);\n  color: var(--uitk-action-regular-default-color);\n  font-family: var(--uitk-action-regular-font-family);\n  font-size: var(--uitk-action-regular-font-size);\n  font-weight: var(--uitk-action-regular-font-weight);\n  letter-spacing: var(--uitk-action-regular-letter-spacing);\n  text-transform: var(--uitk-action-regular-text-transform);\n}\n\n.uitkButton-regular .uitkButton-icon {\n  color: var(--uitk-action-regular-default-icon);\n}\n\n.uitkButton-regular:hover {\n  background: var(--uitk-action-regular-hover-background);\n  color: var(--uitk-action-regular-hover-color);\n}\n\n.uitkButton-regular:hover .uitkButton-icon {\n  color: var(--uitk-action-regular-hover-icon);\n}\n\n.uitkButton-regular:active {\n  background: var(--uitk-action-regular-active-background);\n  color: var(--uitk-action-regular-active-color);\n}\n\n.uitkButton-regular:active .uitkButton-icon {\n  color: var(--uitk-action-regular-active-icon);\n}\n\n.uitkButton-regular.uitkButton-disabled {\n  color: var(--uitk-action-regular-default-color-fade-regular);\n  background: var(--uitk-action-regular-default-background-fade-graphical);\n}\n\n.uitkButton-regular.uitkButton-disabled .uitkButton-icon {\n  color: var(--uitk-action-regular-default-color-fade-graphical);\n}\n\n.uitkButton-cta {\n  background: var(--uitk-action-cta-default-background);\n  color: var(--uitk-action-cta-default-color);\n  font-family: var(--uitk-action-cta-font-family);\n  font-size: var(--uitk-action-cta-font-size);\n  font-weight: var(--uitk-action-cta-font-weight);\n  letter-spacing: var(--uitk-action-cta-letter-spacing);\n  text-transform: var(--uitk-action-cta-text-transform);\n}\n\n.uitkButton-cta .uitkButton-icon {\n  color: var(--uitk-action-cta-default-icon);\n}\n\n.uitkButton-cta:hover {\n  background: var(--uitk-action-cta-hover-background);\n  color: var(--uitk-action-cta-hover-color);\n}\n\n.uitkButton-cta:hover .uitkButton-icon {\n  color: var(--uitk-action-cta-hover-icon);\n}\n\n.uitkButton-cta:active {\n  background: var(--uitk-action-cta-active-background);\n  color: var(--uitk-action-cta-active-color);\n}\n\n.uitkButton-cta:active .uitkButton-icon {\n  color: var(--uitk-action-cta-active-icon);\n}\n\n.uitkButton-cta.uitkButton-disabled {\n  color: var(--uitk-action-cta-default-color-fade-regular);\n  background: var(--uitk-action-cta-default-background-fade-graphical);\n}\n\n.uitkButton-cta.uitkButton-disabled .uitkButton-icon {\n  color: var(--uitk-action-cta-default-color-fade-graphical);\n}\n\n.uitkButton-secondary {\n  background: var(--uitk-action-secondary-default-background);\n  color: var(--uitk-action-secondary-default-color);\n  font-family: var(--uitk-action-secondary-font-family);\n  font-size: var(--uitk-action-secondary-font-size);\n  font-weight: var(--uitk-action-secondary-font-weight);\n  letter-spacing: var(--uitk-action-secondary-letter-spacing);\n  text-transform: var(--uitk-action-secondary-text-transform);\n}\n\n.uitkButton-secondary .uitkButton-icon {\n  color: var(--uitk-action-secondary-default-icon);\n}\n\n.uitkButton-secondary:hover {\n  background: var(--uitk-action-secondary-hover-background);\n  color: var(--uitk-action-secondary-hover-color);\n}\n\n.uitkButton-secondary:hover .uitkButton-icon {\n  color: var(--uitk-action-secondary-hover-icon);\n}\n\n.uitkButton-secondary:active {\n  background: var(--uitk-action-secondary-active-background);\n  color: var(--uitk-action-secondary-active-color);\n}\n\n.uitkButton-secondary:active .uitkButton-icon {\n  color: var(--uitk-action-secondary-active-icon);\n}\n\n.uitkButton-secondary.uitkButton-disabled {\n  color: var(--uitk-action-secondary-default-color-fade-regular);\n  background: none;\n}\n\n.uitkButton-secondary.uitkButton-disabled .uitkButton-icon {\n  color: var(--uitk-action-secondary-default-color-fade-graphical);\n}\n\n.uitkButton-disabled {\n  cursor: var(--disabled-regular-cursor);\n}\n\n.uitkButton[href] {\n  display: inline-flex;\n}\n\n.uitkButton::-moz-focus-inner {\n  padding: 0;\n  border: 0;\n}\n";
styleInject(css_248z$2);

var ButtonVariantValues = ['regular', 'secondary', 'cta'];
var Button = /*#__PURE__*/React.forwardRef(function Button(_ref, ref) {
  var _ref$component = _ref.component,
      Component = _ref$component === void 0 ? 'button' : _ref$component,
      children = _ref.children,
      className = _ref.className,
      disabled = _ref.disabled,
      focusableWhenDisabled = _ref.focusableWhenDisabled,
      _ref$variant = _ref.variant,
      variant = _ref$variant === void 0 ? 'regular' : _ref$variant,
      props = _objectWithoutProperties(_ref, ["component", "children", "className", "disabled", "focusableWhenDisabled", "variant"]);

  var classBase = 'uitkButton';
  return /*#__PURE__*/React__default['default'].createElement(Component, _extends({
    "aria-disabled": disabled,
    className: classnames__default['default'](classBase, className, "".concat(classBase, "-").concat(variant), _defineProperty({}, "".concat(classBase, "-disabled"), disabled)),
    disabled: disabled && !focusableWhenDisabled,
    tabIndex: 0
  }, props, {
    ref: ref
  }), /*#__PURE__*/React__default['default'].createElement(IconClassNameProvider, {
    value: "".concat(classBase, "-icon")
  }, /*#__PURE__*/React__default['default'].createElement("span", {
    className: "".concat(classBase, "-label")
  }, children)));
});

var ButtonBarContext = /*#__PURE__*/React.createContext();

// SUPER HACKS AHEAD: The React team will hate this enough to hopefully give us
// a way to know the index of a descendant given a parent (will help generate
// IDs for accessibility a long with the ability create maximally composable
// component abstractions).
//
// This is all to avoid cloneElement. If we can avoid cloneElement then people
// can have arbitrary markup around MenuItems.  This basically takes advantage
// of react's render lifecycles to let us "register" descendants to an
// ancestor, so that we can track all the descendants and manage focus on them,
// etc.  The super hacks here are for the child to know it's index as well, so
// that it can set attributes, match against state from above, etc.

var DescendantContext = /*#__PURE__*/React.createContext(); // Allows SSR support.

var useEnhancedEffect = typeof window !== 'undefined' ? React.useLayoutEffect : React.useEffect; // eslint-disable-next-line react/prop-types

function DescendantProvider(_ref) {
  var items = _ref.items,
      setItems = _ref.setItems,
      props = _objectWithoutProperties(_ref, ["items", "setItems"]);

  // On the first render we say we're "assigning", and the children will push
  // into the array when they show up in their own useLayoutEffect.
  var assigning = React.useRef(true); // since children are pushed into the array in useLayoutEffect of the child,
  // children can't read their index on first render.  So we need to cause a
  // second render so they can read their index.

  var _useState = React.useState(),
      _useState2 = _slicedToArray(_useState, 2),
      forceUpdate = _useState2[1]; // parent useLayoutEffect is always last


  useEnhancedEffect(function () {
    if (assigning.current) {
      // At this point all of the children have pushed into the array so we set
      // assigning to false and force an update. Since we're in
      // useLayoutEffect, we won't get a flash of rendered content, it will all
      // happen synchronously. And now that this is false, children won't push
      // into the array on the forceUpdate
      assigning.current = false;
      forceUpdate({});
    } else {
      // After the forceUpdate completes, we end up here and set assigning back
      // to true for the next update from the app
      assigning.current = true;
    }

    return function () {
      // this cleanup function runs right before the next render, so it's the
      // right time to empty out the array to be reassigned with whatever shows
      // up next render.
      if (assigning.current) {
        // we only want to empty out the array before the next render cycle if
        // it was NOT the result of our forceUpdate, so being guarded behind
        // assigning.current works
        setItems([]);
      }
    };
  }, [items]);
  return /*#__PURE__*/React__default['default'].createElement(DescendantContext.Provider, _extends({}, props, {
    value: {
      setItems: setItems,
      assigning: assigning
    }
  }));
}

// Copied from https://gist.github.com/ryanflorence/10e9387f633f9d2e6f444a9bddaabf6e
function useDescendants() {
  return React.useState([]);
}

var css_248z$3 = ".uitkButtonBar {\n  width: 100%;\n  display: flex;\n  justify-content: flex-end;\n}\n\n.uitkButtonBar-alignLeft {\n  justify-content: flex-start;\n}\n\n.uitkButtonBar-stacked {\n  flex-direction: column;\n  justify-content: flex-start;\n}\n";
styleInject(css_248z$3);

var DefaultButtonsOrderByVariant = {
  cta: {
    order: 0,
    alignLeftOrder: 1,
    stackOrder: 2
  },
  regular: {
    order: 1,
    alignLeftOrder: 2,
    stackOrder: 1
  },
  secondary: {
    order: 2,
    alignLeftOrder: 0,
    stackOrder: 0
  }
};

function getPriorityForButton(item, field) {
  var variant = item && item.variant || 'regular';
  return item && item[field] !== undefined ? item[field] : DefaultButtonsOrderByVariant[variant][field];
}

var createComparatorForField = function createComparatorForField(field, sort, alignLeft, childrenData) {
  var equalityResult;

  if (field === 'order' || field === 'stackOrder') {
    equalityResult = sort === 'asc' ? 1 : 0;
  } else {
    equalityResult = alignLeft ? 1 : -1;
  }

  function createDescComparator(indexA, indexB) {
    var priorityA = getPriorityForButton(childrenData[indexA], field);
    var priorityB = getPriorityForButton(childrenData[indexB], field);

    if (priorityA == null && priorityB == null) {
      return 0;
    }

    if (priorityA == null) {
      return 1;
    }

    if (priorityB == null) {
      return -1;
    }

    if (priorityA === priorityB) {
      return equalityResult;
    }

    return priorityB - priorityA;
  }

  function createAscComparator() {
    return createDescComparator.apply(void 0, arguments) * -1;
  }

  return sort === 'asc' ? createAscComparator : createDescComparator;
};

function alignSecondaryChild(orderedChildrenData, sortOrder, alignLeft) {
  var noSecondaryChildren = {
    index: undefined,
    align: undefined
  };

  if (sortOrder === 'asc' || alignLeft) {
    var firstSecondaryChildIndex = orderedChildrenData.findIndex(function (childData) {
      return childData.variant === 'secondary';
    });

    if (firstSecondaryChildIndex !== -1) {
      var originalChildIndex = orderedChildrenData[firstSecondaryChildIndex].index;
      return {
        index: originalChildIndex,
        align: 'right'
      };
    } else {
      return noSecondaryChildren;
    }
  } else {
    var index = orderedChildrenData.length;

    while (index--) {
      if (orderedChildrenData[index].variant === 'secondary') {
        return {
          index: orderedChildrenData[index].index,
          align: 'left'
        };
      }
    }

    return noSecondaryChildren;
  }
}

var ButtonBar = /*#__PURE__*/React.forwardRef(function ButtonBar(props, ref) {
  var _classnames;

  var alignLeft = props.alignLeft,
      childrenProp = props.children,
      className = props.className,
      densityProp = props.density,
      disableAutoAlignment = props.disableAutoAlignment,
      _props$sortAlignLeft = props.sortAlignLeft,
      sortAlignLeft = _props$sortAlignLeft === void 0 ? 'desc' : _props$sortAlignLeft,
      _props$sortOrder = props.sortOrder,
      sortOrder = _props$sortOrder === void 0 ? 'desc' : _props$sortOrder,
      _props$sortStackOrder = props.sortStackOrder,
      sortStackOrder = _props$sortStackOrder === void 0 ? 'desc' : _props$sortStackOrder,
      _props$stackAtBreakpo = props.stackAtBreakpoint,
      stackAtBreakpoint = _props$stackAtBreakpo === void 0 ? 'xs' : _props$stackAtBreakpo,
      rest = _objectWithoutProperties(props, ["alignLeft", "children", "className", "density", "disableAutoAlignment", "sortAlignLeft", "sortOrder", "sortStackOrder", "stackAtBreakpoint", "theme"]);

  var _useDescendants = useDescendants(),
      _useDescendants2 = _slicedToArray(_useDescendants, 2),
      childrenData = _useDescendants2[0],
      setChildrenData = _useDescendants2[1];

  var density = useDensity(densityProp);
  var classBase = 'uitkButtonBar'; //TODO we need a mechanism to work with breakpoints. Have removed the Material UI useBreakPoint
  // hook. We can use something from the toolkit responsive work (not yet in this branch)

  var breakpointMatch = useBreakpoints({
    smallerThan: stackAtBreakpoint
  });
  var childrenArray = React.Children.toArray(childrenProp);
  var childrenIndexes = childrenArray.map(function (_, index) {
    return index;
  });
  var stackOrderComparator = createComparatorForField('stackOrder', sortStackOrder, alignLeft, childrenData);
  var orderComparator = createComparatorForField('order', sortOrder, alignLeft, childrenData);
  var alignLeftComparator = createComparatorForField('alignLeftOrder', sortAlignLeft, alignLeft, childrenData);
  var orderedChildrenIndexes;

  if (childrenData.length !== childrenIndexes.length) {
    orderedChildrenIndexes = childrenIndexes;
  } else {
    orderedChildrenIndexes = breakpointMatch ? childrenIndexes.sort(stackOrderComparator) : childrenIndexes.sort(alignLeft ? alignLeftComparator : orderComparator);
  }

  var secondaryChildAlignment = {
    index: undefined,
    align: undefined
  };

  if (!disableAutoAlignment) {
    secondaryChildAlignment = alignSecondaryChild(orderedChildrenIndexes.map(function (index) {
      return _objectSpread2({
        index: index
      }, childrenData[index]);
    }), sortOrder, alignLeft);
  }

  var hasSecondaryButtons = childrenData.some(function (buttonData) {
    return buttonData.variant === 'secondary';
  });
  var orderedChildren = orderedChildrenIndexes.map(function (index) {
    return childrenArray[index];
  });
  var buttonBarContext = React.useMemo(function () {
    return {
      density: density,
      stacked: breakpointMatch,
      alignedIndex: secondaryChildAlignment.index,
      align: secondaryChildAlignment.align
    };
  }, [density, breakpointMatch, secondaryChildAlignment.align, secondaryChildAlignment.index]);
  return /*#__PURE__*/React__default['default'].createElement(ButtonBarContext.Provider, {
    value: buttonBarContext
  }, /*#__PURE__*/React__default['default'].createElement(DescendantProvider, {
    items: childrenData,
    setItems: setChildrenData
  }, /*#__PURE__*/React__default['default'].createElement("div", _extends({
    "aria-label": "button bar",
    className: classnames__default['default'](className, classBase, (_classnames = {}, _defineProperty(_classnames, "".concat(classBase, "-stacked"), breakpointMatch), _defineProperty(_classnames, "".concat(classBase, "-alignLeft"), alignLeft), _defineProperty(_classnames, "".concat(classBase, "-autoAligning"), hasSecondaryButtons && !disableAutoAlignment), _classnames)),
    ref: ref,
    role: "region"
  }, rest), orderedChildren)));
});
ButtonBar.propTypes = {
  /**
   * By default ButtonBar lays buttons from right to left horizontally ordering action buttons by order prop.
   * Use this prop to lay button from left to right instead.
   * Actions buttons will be ordered by alignLeftOrder prop.
   */
  alignLeft: PropTypes__default['default'].bool,

  /**
   * A list of OrderButtons
   */
  children: PropTypes__default['default'].oneOfType([PropTypes__default['default'].node, PropTypes__default['default'].arrayOf(PropTypes__default['default'].element), PropTypes__default['default'].element]),

  /**
   * The className(s) of the component
   */
  className: PropTypes__default['default'].string,

  /**
   * Density of the DialogActionButtons
   */
  density: PropTypes__default['default'].oneOf(['touch', 'low', 'medium', 'high']),

  /**
   * By default ButtonBar aligns secondary buttons to the left while displayed horizontally
   * and to the right while aligned left or sorting ascending.
   * Use this prop to disable this behavior.
   */
  disableAutoAlignment: PropTypes__default['default'].bool,

  /**
   * By default ButtonBar sorts buttons in descending order.
   * Use this prop to change that when the button bar is NOT stacked and aligned left.
   */
  sortAlignLeft: PropTypes__default['default'].oneOf(['asc', 'desc']),

  /**
   * By default ButtonBar sorts buttons in descending order.
   * Use this prop to change that when the button bar is NOT stacked and NOT aligned left.
   */
  sortOrder: PropTypes__default['default'].oneOf(['asc', 'desc']),

  /**
   * By default ButtonBar sorts buttons in descending order.
   * Use this prop to change that when the button bar is stacked.
   */
  sortStackOrder: PropTypes__default['default'].oneOf(['asc', 'desc']),

  /**
   * When the viewport is equal to or smaller than the breakpoint the buttons will be stacked vertically.
   * Alternatively pass a screen width number in pixels.
   * Use `0` to disable this feature. Defaults to 'xs'.
   * Actions buttons will be ordered by stackOrder prop.
   */
  stackAtBreakpoint: PropTypes__default['default'].oneOfType([PropTypes__default['default'].oneOf(['xs', 'sm', 'md', 'lg', 'xl']), PropTypes__default['default'].number]),
  theme: PropTypes__default['default'].objectOf(PropTypes__default['default'].any)
};

// Copied from https://gist.github.com/ryanflorence/10e9387f633f9d2e6f444a9bddaabf6e
function useDescendant(descendant) {
  var _useContext = React.useContext(DescendantContext),
      assigning = _useContext.assigning,
      setItems = _useContext.setItems;

  var index = React.useRef(-1);
  React.useLayoutEffect(function () {
    if (assigning.current) {
      setItems(function (old) {
        index.current = old.length;
        return old.concat(descendant);
      });
    }
  }); // first render its wrong, after a forceUpdate in parent useLayoutEffect it's
  // right, and its all synchronous so we don't get any flashing

  return index.current;
}

var css_248z$4 = ".uitkOrderedButton {\n  margin-right: var(--uitk-space);\n}\n\n.uitkOrderedButton-stacked {\n  margin: 0 0 var(--uitk-space);\n}\n\n.uitkOrderedButton-alignLeft {\n  margin-right: auto;\n}\n\n.uitkOrderedButton-alignRight {\n  margin-left: auto;\n}\n";
styleInject(css_248z$4);

function capitalize(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

var OrderedButton = /*#__PURE__*/React.forwardRef(function OrderedButton(_ref, ref) {
  var _classnames;

  var className = _ref.className,
      alignProp = _ref.align,
      densityProp = _ref.density,
      order = _ref.order,
      alignLeftOrder = _ref.alignLeftOrder,
      stackOrder = _ref.stackOrder,
      variant = _ref.variant,
      restProps = _objectWithoutProperties(_ref, ["className", "align", "density", "order", "alignLeftOrder", "stackOrder", "variant"]);

  var index = useDescendant({
    order: order,
    stackOrder: stackOrder,
    alignLeftOrder: alignLeftOrder,
    variant: variant
  });

  var _useContext = React.useContext(ButtonBarContext),
      stacked = _useContext.stacked,
      densityContext = _useContext.density,
      alignContext = _useContext.align,
      alignedIndex = _useContext.alignedIndex;

  var density = densityProp || densityContext;
  var alignFromParent = index === alignedIndex ? alignContext : undefined;
  var align = alignProp || alignFromParent;
  var classBase = 'uitkOrderedButton';
  return /*#__PURE__*/React__default['default'].createElement(Button, _extends({
    className: classnames__default['default'](classBase, "".concat(classBase, "-").concat(density, "Density"), (_classnames = {}, _defineProperty(_classnames, "".concat(classBase, "-align").concat(align ? capitalize(align) : ''), align && !stacked), _defineProperty(_classnames, "".concat(classBase, "-stacked"), stacked), _classnames), className),
    density: density,
    ref: ref,
    variant: variant
  }, restProps));
});
OrderedButton.propTypes = {
  /**
   * Aligns the button (and any buttons before/after) it on the left/right
   * of the container
   */
  align: PropTypes__default['default'].oneOf(['left', 'right']),

  /**
   * The order the button will be rendered when NOT stacked and the button bar is aligned left order.
   * Buttons are ordered in descending order by default and then by their source order.
   * This defaults to 1 for `CTA`, 2 for `regular` and 0 for `secondary`
   */
  alignLeftOrder: PropTypes__default['default'].number,

  /**
   * The className(s) of the component
   */
  className: PropTypes__default['default'].string,

  /**
   * Density of the DialogActionButtons
   */
  density: PropTypes__default['default'].oneOf(['touch, low', 'medium', 'high']),

  /**
   * The order the button will be rendered when NOT stacked. Buttons are ordered
   * in descending order by default and then by their source order.
   * This defaults to 0 for `CTA`, 1 for `regular` and 2 for `secondary`
   */
  order: PropTypes__default['default'].number,

  /**
   * The order the button will be rendered when stacked. Buttons are ordered
   * in descending order by default and then by their source order.
   * This defaults to 2 for `CTA`, 1 for `regular` and 0 for `secondary`
   */
  stackOrder: PropTypes__default['default'].number
};

var css_248z$5 = ".uitkControlLabel {\n  align-items: flex-start;\n  display: inline-flex;\n  margin-top: var(--label-margin-top, 0);\n\n  font-family: var(--uitk-font-family);\n  font-size: var(--uitk-font-size-regular);\n  font-weight: var(--label-font-weight, var(--uitk-font-weight-regular));\n}\n\n.uitkControlLabel-text {\n  line-height: var(--uitk-line-height);\n  /* the default should be density aware. This can wait until density is avaiable via theme */\n  margin-left: var(--label-margin-left, 4px);\n  margin-right: var(--label-margin-right, 4px);\n  min-height: var(--label-min-height);\n  vertical-align: var(--label-vertical-align, center);\n}\n";
styleInject(css_248z$5);

// TODO Label positioning

var ControlLabel = function ControlLabel(_ref) {
  var children = _ref.children,
      className = _ref.className,
      label = _ref.label,
      _ref$labelPlacement = _ref.labelPlacement,
      labelPlacement = _ref$labelPlacement === void 0 ? 'left' : _ref$labelPlacement;
  var baseClass = 'uitkControlLabel';
  var startLabel = labelPlacement === 'left' || labelPlacement === 'top';
  var labelComponent = /*#__PURE__*/React__default['default'].createElement("span", {
    className: "".concat(baseClass, "-text")
  }, label);
  return /*#__PURE__*/React__default['default'].createElement("label", {
    className: classnames__default['default'](baseClass, "".concat(baseClass, "-").concat(labelPlacement), className)
  }, startLabel ? labelComponent : null, children, !startLabel ? labelComponent : null);
};

// Corresponds to 10 frames at 60 Hz.
// A few bytes payload overhead when lodash/debounce is ~3 kB and debounce ~300 B.
function debounce(func) {
  var wait = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 166;
  var timeout;

  function debounced() {
    var _this = this;

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    var later = function later() {
      func.apply(_this, args);
    };

    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  }

  debounced.clear = function () {
    clearTimeout(timeout);
  };

  return debounced;
}

// This is lifted from lodash - recreate using just the functionality we need

/**
 * lodash (Custom Build) <https://lodash.com/>
 * Build: `lodash modularize exports="npm" -o ./`
 * Copyright jQuery Foundation and other contributors <https://jquery.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */

/** Used as references for various `Number` constants. */
var INFINITY = 1 / 0;
/** `Object#toString` result references. */

var symbolTag = "[object Symbol]";
/**
 * Used to match `RegExp`
 * [syntax characters](http://ecma-international.org/ecma-262/7.0/#sec-patterns).
 */

var reRegExpChar = /[\\^$.*+?()[\]{}|]/g,
    reHasRegExpChar = RegExp(reRegExpChar.source);
/** Detect free variable `global` from Node.js. */

var freeGlobal = (typeof global === "undefined" ? "undefined" : _typeof(global)) == "object" && global && global.Object === Object && global;
/** Detect free variable `self`. */

var freeSelf = (typeof self === "undefined" ? "undefined" : _typeof(self)) == "object" && self && self.Object === Object && self;
/** Used as a reference to the global object. */

var root = freeGlobal || freeSelf || Function("return this")();
/** Used for built-in method references. */

var objectProto = Object.prototype;
/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */

var objectToString = objectProto.toString;
/** Built-in value references. */

var _Symbol = root.Symbol;
/** Used to convert symbols to primitives and strings. */

var symbolProto = _Symbol ? _Symbol.prototype : undefined,
    symbolToString = symbolProto ? symbolProto.toString : undefined;
/**
 * The base implementation of `_.toString` which doesn't convert nullish
 * values to empty strings.
 *
 * @private
 * @param {*} value The value to process.
 * @returns {string} Returns the string.
 */

function baseToString(value) {
  // Exit early for strings to avoid a performance hit in some environments.
  if (typeof value == "string") {
    return value;
  }

  if (isSymbol(value)) {
    return symbolToString ? symbolToString.call(value) : "";
  }

  var result = value + "";
  return result == "0" && 1 / value == -INFINITY ? "-0" : result;
}
/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */


function isObjectLike(value) {
  return !!value && _typeof(value) == "object";
}
/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */


function isSymbol(value) {
  return _typeof(value) == "symbol" || isObjectLike(value) && objectToString.call(value) == symbolTag;
}
/**
 * Converts `value` to a string. An empty string is returned for `null`
 * and `undefined` values. The sign of `-0` is preserved.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {string} Returns the string.
 * @example
 *
 * _.toString(null);
 * // => ''
 *
 * _.toString(-0);
 * // => '-0'
 *
 * _.toString([1, 2, 3]);
 * // => '1,2,3'
 */


function toString(value) {
  return value == null ? "" : baseToString(value);
}
/**
 * Escapes the `RegExp` special characters "^", "$", "\", ".", "*", "+",
 * "?", "(", ")", "[", "]", "{", "}", and "|" in `string`.
 *
 * @static
 * @memberOf _
 * @since 3.0.0
 * @category String
 * @param {string} [string=''] The string to escape.
 * @returns {string} Returns the escaped string.
 * @example
 *
 * _.escapeRegExp('[lodash](https://lodash.com/)');
 * // => '\[lodash\]\(https://lodash\.com/\)'
 */


function escapeRegExp(string) {
  string = toString(string);
  return string && reHasRegExpChar.test(string) ? string.replace(reRegExpChar, "\\$&") : string;
}

var getWithDefault = function getWithDefault(value, defaultValue) {
  return value === undefined ? defaultValue : value;
};

function ownerDocument(node) {
  return node && node.ownerDocument || document;
}

function ownerWindow(node) {
  var doc = ownerDocument(node);
  return doc.defaultView || window;
}

var refType = PropTypes__default['default'].oneOfType([PropTypes__default['default'].func, PropTypes__default['default'].object]);

/**
 * TODO v5: consider to make it private
 *
 * passes {value} to {ref}
 *
 * WARNING: Be sure to only call this inside a callback that is passed as a ref.
 * Otherwise make sure to cleanup previous {ref} if it changes. See
 * https://github.com/mui-org/material-ui/issues/13539
 *
 * useful if you want to expose the ref of an inner component to the public api
 * while still using it inside the component
 * @param ref a ref callback or ref object if anything falsy this is a no-op
 */
function setRef(ref, value) {
  if (typeof ref === 'function') {
    ref(value);
  } else if (ref) {
    ref.current = value;
  }
}

function useId(idOverride) {
  var _useState = React.useState(idOverride),
      _useState2 = _slicedToArray(_useState, 2),
      defaultId = _useState2[0],
      setDefaultId = _useState2[1];

  var id = idOverride || defaultId;
  React.useEffect(function () {
    if (defaultId == null) {
      // Fallback to this default id when possible.
      // Use the random value for client-side rendering only.
      // We can't use it server-side.
      setDefaultId("uitk-".concat(Math.round(Math.random() * 1e5)));
    }
  }, [defaultId]);
  return id;
}

var a11yContext = /*#__PURE__*/React__default['default'].createContext({});
function useA11yProps() {
  return React.useContext(a11yContext);
}

/**
 * Copied from MUI (v4.11.0) useControlled hook with one additional returned value
 * @see https://github.com/mui-org/material-ui/blob/master/packages/material-ui/src/utils/useControlled.js
 */

function useControlled(_ref) {
  var controlled = _ref.controlled,
      defaultProp = _ref["default"],
      name = _ref.name,
      _ref$state = _ref.state,
      state = _ref$state === void 0 ? 'value' : _ref$state;

  var _React$useRef = React.useRef(controlled !== undefined),
      isControlled = _React$useRef.current;

  var _React$useState = React.useState(defaultProp),
      _React$useState2 = _slicedToArray(_React$useState, 2),
      valueState = _React$useState2[0],
      setValue = _React$useState2[1];

  var value = isControlled ? controlled : valueState;

  if (process.env.NODE_ENV !== 'production') {
    React.useEffect(function () {
      if (isControlled !== (controlled !== undefined)) {
        console.error(["UI-Toolkit: A component is changing the ".concat(isControlled ? '' : 'un', "controlled ").concat(state, " state of ").concat(name, " to be ").concat(isControlled ? 'un' : '', "controlled."), 'Elements should not switch from uncontrolled to controlled (or vice versa).', "Decide between using a controlled or uncontrolled ".concat(name, " ") + 'element for the lifetime of the component.', "The nature of the state is determined during the first render, it's considered controlled if the value is not `undefined`.", 'More info: https://fb.me/react-controlled-components'].join('\n'));
      }
    }, [controlled]);

    var _React$useRef2 = React.useRef(defaultProp),
        defaultValue = _React$useRef2.current;

    React.useEffect(function () {
      if (!isControlled && defaultValue !== defaultProp) {
        console.error(["UI-Toolkit: A component is changing the default ".concat(state, " state of an uncontrolled ").concat(name, " after being initialized. ") + "To suppress this warning opt to use a controlled ".concat(name, ".")].join('\n'));
      }
    }, [JSON.stringify(defaultProp)]);
  }

  var setValueIfUncontrolled = React.useCallback(function (newValue) {
    if (!isControlled) {
      setValue(newValue);
    }
  }, []);
  return [value, setValueIfUncontrolled, isControlled];
}

var useChildRefs = function useChildRefs(children) {
  var childRefs = React.useRef([]);
  var childCount = React__default['default'].Children.count(children);

  if (childRefs.current.length !== childCount) {
    // add or remove refs
    childRefs.current = Array(childCount).fill(null).map(function (_, i) {
      return childRefs.current[i] || /*#__PURE__*/React.createRef();
    });
  }

  return childRefs.current;
};

var useEnhancedEffect$1 = typeof window !== "undefined" ? React.useLayoutEffect : React.useEffect;
/**
 * https://github.com/facebook/react/issues/14099#issuecomment-440013892
 *
 * @param {function} fn
 */

function useEventCallback(fn) {
  var ref = React.useRef(fn);
  useEnhancedEffect$1(function () {
    ref.current = fn;
  });
  return React.useCallback(function () {
    return (ref.current).apply(void 0, arguments);
  }, []);
}

// based on https://github.com/WICG/focus-visible/blob/v4.1.5/src/focus-visible.js
var hadKeyboardEvent = true;
var hadFocusVisibleRecently = false;
var hadFocusVisibleRecentlyTimeout = null;
var inputTypesWhitelist = {
  text: true,
  search: true,
  url: true,
  tel: true,
  email: true,
  password: true,
  number: true,
  date: true,
  month: true,
  week: true,
  time: true,
  datetime: true,
  "datetime-local": true
};
/**
 * Computes whether the given element should automatically trigger the
 * `focus-visible` class being added, i.e. whether it should always match
 * `:focus-visible` when focused.
 * @param {Element} node
 * @return {boolean}
 */

function focusTriggersKeyboardModality(node) {
  var type = node.type,
      tagName = node.tagName;

  if (tagName === "INPUT" && inputTypesWhitelist[type] && !node.readOnly) {
    return true;
  }

  if (tagName === "TEXTAREA" && !node.readOnly) {
    return true;
  }

  if (node.isContentEditable) {
    return true;
  }

  return false;
}
/**
 * Keep track of our keyboard modality state with `hadKeyboardEvent`.
 * If the most recent user interaction was via the keyboard;
 * and the key press did not include a meta, alt/option, or control key;
 * then the modality is keyboard. Otherwise, the modality is not keyboard.
 * @param {KeyboardEvent} event
 */


function handleKeyDown(event) {
  if (event.metaKey || event.altKey || event.ctrlKey) {
    return;
  }

  hadKeyboardEvent = true;
}
/**
 * If at any point a user clicks with a pointing device, ensure that we change
 * the modality away from keyboard.
 * This avoids the situation where a user presses a key on an already focused
 * element, and then clicks on a different element, focusing it with a
 * pointing device, while we still think we're in keyboard modality.
 */


function handlePointerDown() {
  hadKeyboardEvent = false;
}

function handleVisibilityChange() {
  if (this.visibilityState === "hidden") {
    // If the tab becomes active again, the browser will handle calling focus
    // on the element (Safari actually calls it twice).
    // If this tab change caused a blur on an element with focus-visible,
    // re-apply the class when the user switches back to the tab.
    if (hadFocusVisibleRecently) {
      hadKeyboardEvent = true;
    }
  }
}

function prepare(doc) {
  doc.addEventListener("keydown", handleKeyDown, true);
  doc.addEventListener("mousedown", handlePointerDown, true);
  doc.addEventListener("pointerdown", handlePointerDown, true);
  doc.addEventListener("touchstart", handlePointerDown, true);
  doc.addEventListener("visibilitychange", handleVisibilityChange, true);
}

function isFocusVisible(event) {
  var target = event.target;

  try {
    return target.matches(":focus-visible");
  } catch (error) {// browsers not implementing :focus-visible will throw a SyntaxError
    // we use our own heuristic for those browsers
    // rethrow might be better if it's not the expected error but do we really
    // want to crash if focus-visible malfunctioned?
  } // no need for validFocusTarget check. the user does that by attaching it to
  // focusable events only


  return hadKeyboardEvent || focusTriggersKeyboardModality(target);
}
/**
 * Should be called if a blur event is fired on a focus-visible element
 */


function handleBlurVisible() {
  // To detect a tab/window switch, we look for a blur event followed
  // rapidly by a visibility change.
  // If we don't see a visibility change within 100ms, it's probably a
  // regular focus change.
  hadFocusVisibleRecently = true;
  window.clearTimeout(hadFocusVisibleRecentlyTimeout);
  hadFocusVisibleRecentlyTimeout = window.setTimeout(function () {
    hadFocusVisibleRecently = false;
  }, 100);
}

function useIsFocusVisible() {
  var ref = React.useCallback(function (instance) {
    var node = ReactDOM.findDOMNode(instance);

    if (node != null) {
      prepare(node.ownerDocument);
    }
  }, []);

  if (process.env.NODE_ENV !== "production") {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    React.useDebugValue(isFocusVisible);
  }

  return {
    isFocusVisible: isFocusVisible,
    onBlurVisible: handleBlurVisible,
    ref: ref
  };
}

function useForkRef(refA, refB) {
  /**
   * This will create a new function if the ref props change and are defined.
   * This means react will call the old forkRef with `null` and the new forkRef
   * with the ref. Cleanup naturally emerges from this behavior
   */
  return React.useMemo(function () {
    if (refA == null && refB == null) {
      return null;
    }

    return function (refValue) {
      setRef(refA, refValue);
      setRef(refB, refValue);
    };
  }, [refA, refB]);
}

function useOverflowDetection(dependencies) {
  var targetRef = React.useRef();

  var _useState = React.useState(false),
      _useState2 = _slicedToArray(_useState, 2),
      isOverflowed = _useState2[0],
      setOverflowed = _useState2[1];

  var handleResize = React.useCallback(debounce(function () {
    var current = targetRef.current;

    if (!current) {
      // no component to measure yet
      isOverflowed && setOverflowed(false);
      return;
    }

    setOverflowed(current.offsetWidth < current.scrollWidth);
  }), [targetRef, isOverflowed]); // check on resizing

  React.useLayoutEffect(function () {
    // Multi window support
    var win = ownerWindow(targetRef.current);
    win.addEventListener("resize", handleResize);
    return function () {
      handleResize.clear();
      win.removeEventListener("resize", handleResize);
    };
  }, [targetRef, handleResize]);
  React.useLayoutEffect(handleResize, dependencies);
  return [targetRef, isOverflowed];
}

var css_248z$6 = ".uitk-light .uitkCheckboxBase {\n  --checkbox-outline-color: var(--uitk-grey90);\n  --checkbox-solid-color: var(--uitk-blue500);\n  --checkbox-tick-color: var(--white);\n}\n\n.uitk-dark .uitkCheckboxBase {\n  --checkbox-outline-color: var(--uitk-grey100);\n  --checkbox-solid-color: var(--uitk-blue400);\n  --checkbox-tick-color: var(--uitk-grey800);\n}\n\n.uitk-density-touch .uitkCheckboxBase {\n  --indeterminate-bar-y: 6;\n  --indeterminate-bar-height: 2px;\n  --icon-size: 18px;\n}\n.uitk-density-low .uitkCheckboxBase {\n  --indeterminate-bar-y: 6;\n  --indeterminate-bar-height: 2px;\n  --icon-size: 16px;\n}\n.uitk-density-medium .uitkCheckboxBase {\n  --indeterminate-bar-y: 5;\n  --indeterminate-bar-height: 3px;\n  --icon-size: 14px;\n}\n.uitk-density-high .uitkCheckboxBase {\n  --indeterminate-bar-y: 5;\n  --indeterminate-bar-height: 3px;\n  --icon-size: 12px;\n}\n\n.uitkCheckboxBase {\n  background: none;\n  position: relative;\n}\n\n.uitkCheckboxBase:focus-visible:before,\n.uitkCheckboxBase-focusVisible:before {\n  content: '';\n  display: block;\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: var(--icon-size);\n  height: var(--icon-size);\n  background: transparent;\n  outline: var(--uitk-focus-outline);\n}\n\n.uitkCheckboxBase-icon {\n  fill: transparent;\n  flex-grow: 0;\n  height: var(--icon-size);\n  overflow: visible;\n  stroke: var(--checkbox-outline-color);\n  width: var(--icon-size);\n}\n\n.uitkCheckboxBase-icon-tick {\n  fill: var(--checkbox-tick-color);\n}\n\n.uitkCheckboxBase-input {\n  top: 0;\n  left: 0;\n  width: 100%;\n  cursor: inherit;\n  height: 100%;\n  margin: 0;\n  opacity: 0;\n  padding: 0;\n  z-index: 1;\n  position: absolute;\n}\n\n.uitkCheckboxBase-checked .uitkCheckboxBase-icon {\n  stroke-width: 0;\n  fill: var(--checkbox-solid-color);\n}\n\n.uitkCheckboxBase-indeterminate .uitkCheckboxBase-icon {\n  fill: transparent;\n}\n.uitkCheckboxBase-indeterminate .uitkCheckboxBase-icon-tick {\n  fill: var(--checkbox-solid-color);\n  y: var(--indeterminate-bar-y);\n  height: var(--indeterminate-bar-height);\n}\n";
styleInject(css_248z$6);

var CheckboxIcon = function CheckboxIcon(_ref) {
  var className = _ref.className;
  return /*#__PURE__*/React__default['default'].createElement("svg", {
    "aria-hidden": "true",
    className: className,
    focusable: "false",
    shapeRendering: "crispEdges",
    viewBox: "0 0 14 14"
  }, /*#__PURE__*/React__default['default'].createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/React__default['default'].createElement("rect", {
    height: "13",
    width: "13",
    x: "0.5",
    y: "0.5"
  })));
};

var CheckboxCheckedIcon = function CheckboxCheckedIcon(_ref) {
  var className = _ref.className;
  return /*#__PURE__*/React__default['default'].createElement("svg", {
    "aria-hidden": "true",
    className: className,
    focusable: "false",
    shapeRendering: "crispEdges",
    viewBox: "0 0 14 14"
  }, /*#__PURE__*/React__default['default'].createElement("g", {
    fillRule: "evenodd"
  }, /*#__PURE__*/React__default['default'].createElement("rect", {
    height: "14",
    width: "14",
    x: "0",
    y: "0"
  }), /*#__PURE__*/React__default['default'].createElement("polygon", {
    className: "".concat(className, "-tick"),
    fillRule: "nonzero",
    points: "12 4.22226066 10.6259221 3 5.58277771 8.37894955 3.3179086 6.13993399 2 7.40754746 5.63993779 11"
  })));
};

var CheckboxIndeterminateIcon = function CheckboxIndeterminateIcon(_ref) {
  var className = _ref.className;
  return /*#__PURE__*/React__default['default'].createElement("svg", {
    "aria-hidden": "true",
    className: className,
    focusable: "false",
    shapeRendering: "crispEdges",
    viewBox: "0 0 14 14"
  }, /*#__PURE__*/React__default['default'].createElement("g", {
    fillRule: "evenodd",
    strokeWidth: "1"
  }, /*#__PURE__*/React__default['default'].createElement("rect", {
    height: "13",
    width: "13",
    x: "0.5",
    y: "0.5"
  }), /*#__PURE__*/React__default['default'].createElement("rect", {
    className: "".concat(className, "-tick"),
    height: "2",
    strokeWidth: "0",
    width: "8",
    x: "3",
    y: "6"
  })));
};

var CheckboxBase = /*#__PURE__*/React.forwardRef(function CheckboxBase(_ref, ref) {
  var _classnames;

  var checkedProp = _ref.checked,
      classNameProp = _ref.className,
      defaultChecked = _ref.defaultChecked,
      disabled = _ref.disabled,
      indeterminate = _ref.indeterminate,
      inputProps = _ref.inputProps,
      onBlur = _ref.onBlur,
      onChange = _ref.onChange,
      onFocus = _ref.onFocus,
      rest = _objectWithoutProperties(_ref, ["checked", "className", "defaultChecked", "disabled", "indeterminate", "density", "inputProps", "onBlur", "onChange", "onFocus"]);

  var inputRef = React.useRef(false);
  var classBase = 'uitkCheckboxBase';

  var _useControlled = useControlled({
    controlled: checkedProp,
    "default": Boolean(defaultChecked),
    name: 'Checkbox',
    state: 'checked'
  }),
      _useControlled2 = _slicedToArray(_useControlled, 2),
      checked = _useControlled2[0],
      setChecked = _useControlled2[1];

  var _useState = React.useState(false),
      _useState2 = _slicedToArray(_useState, 2),
      focusVisible = _useState2[0],
      setFocusVisible = _useState2[1];

  var handleChange = function handleChange(evt) {
    var value = evt.target.checked;
    setChecked(value);
    onChange && onChange(evt, value);
  };

  var handleFocus = React.useCallback(function (event) {
    // Fix for https://github.com/facebook/react/issues/7769
    if (!inputRef.current) {
      inputRef.current = event.currentTarget;
    } // TODO :focus-visible not yet supported on Safari, so we'll need to use the
    // useIsFocusVisible polyfill


    if (inputRef.current.matches(':focus-visible')) {
      setFocusVisible(true);
    }

    onFocus && onFocus(event);
  }, [onFocus]);
  var handleBlur = React.useCallback(function (event) {
    setFocusVisible(false);
    onBlur && onBlur(event);
  }, [onBlur]);

  var finalInputProps = _objectSpread2({
    'aria-checked': indeterminate ? 'mixed' : checked
  }, inputProps);

  var className = classnames__default['default'](classBase, classNameProp, (_classnames = {}, _defineProperty(_classnames, "".concat(classBase, "-checked"), checked), _defineProperty(_classnames, "".concat(classBase, "-focusVisible"), focusVisible), _defineProperty(_classnames, "".concat(classBase, "-indeterminate"), indeterminate), _classnames));
  return /*#__PURE__*/React__default['default'].createElement("span", _extends({}, rest, {
    className: className,
    ref: ref
  }), /*#__PURE__*/React__default['default'].createElement("span", {
    className: "".concat(classBase, "-label")
  }, /*#__PURE__*/React__default['default'].createElement("input", _extends({}, finalInputProps, {
    checked: checkedProp,
    className: "".concat(classBase, "-input"),
    "data-indeterminate": indeterminate,
    defaultChecked: defaultChecked,
    disabled: disabled,
    onBlur: handleBlur,
    onChange: handleChange,
    onFocus: handleFocus,
    ref: inputRef,
    type: "checkbox"
  })), indeterminate ? /*#__PURE__*/React__default['default'].createElement(CheckboxIndeterminateIcon, {
    className: "".concat(classBase, "-icon")
  }) : checked ? /*#__PURE__*/React__default['default'].createElement(CheckboxCheckedIcon, {
    className: "".concat(classBase, "-icon")
  }) : /*#__PURE__*/React__default['default'].createElement(CheckboxIcon, {
    className: "".concat(classBase, "-icon")
  })));
});

var css_248z$7 = ".uitk-density-touch .uitkCheckbox {\n  --label-margin-left: 12px;\n  --label-min-height: 20px;\n}\n\n.uitk-density-low .uitkCheckbox {\n  --label-margin-left: 9px;\n  --label-min-height: 18px;\n}\n\n.uitk-density-medium .uitkCheckbox {\n  --label-margin-left: 6px;\n  --label-min-height: 16px;\n}\n\n.uitk-density-high .uitkCheckbox {\n  --label-margin-left: 3px;\n  --label-min-height: 14px;\n}\n\n.uitkCheckbox {\n  --label-margin-right: calc(var(--uitk-space) * 3);\n  --label-margin-top: calc(var(--uitk-space) * 0.75);\n  --label-vertical-align: baseline;\n  font-size: var(--uitk-font-size-regular);\n  line-height: 1;\n}\n\n.uitkCheckbox-disabled {\n  pointer-events: visible;\n}\n\n.uitkCheckbox-label {\n  vertical-align: baseline;\n}\n";
styleInject(css_248z$7);

var Checkbox = /*#__PURE__*/React.forwardRef(function Checkbox(props, ref) {
  var checked = props.checked,
      className = props.className,
      defaultChecked = props.defaultChecked,
      disabled = props.disabled,
      indeterminate = props.indeterminate,
      label = props.label,
      LabelProps = props.LabelProps,
      onChange = props.onChange,
      rest = _objectWithoutProperties(props, ["checked", "className", "defaultChecked", "density", "disabled", "indeterminate", "inputProps", "label", "LabelProps", "onChange"]);

  var baseClass = 'uitkCheckbox';
  return /*#__PURE__*/React__default['default'].createElement("div", _extends({}, rest, {
    className: classnames__default['default'](baseClass, className, _defineProperty({}, "".concat(baseClass, "-disabled}"), disabled)),
    "data-jpmui-test": "checkbox",
    ref: ref
  }), /*#__PURE__*/React__default['default'].createElement(ControlLabel, _extends({
    labelPlacement: "right"
  }, LabelProps, {
    disabled: disabled,
    label: label
  }), /*#__PURE__*/React__default['default'].createElement(CheckboxBase, {
    checked: checked,
    defaultChecked: defaultChecked,
    indeterminate: indeterminate,
    onChange: onChange
  })));
});

var css_248z$8 = "";
styleInject(css_248z$8);

var DialogActions = /*#__PURE__*/React.forwardRef(function DialogActions(props, ref) {
  var className = props.className,
      children = props.children,
      rest = _objectWithoutProperties(props, ["classes", "className", "children"]);

  var classBase = 'uitkDialogActions';
  return /*#__PURE__*/React__default['default'].createElement("div", _extends({}, rest, {
    className: classnames__default['default'](classBase, className, className),
    ref: ref
  }), children);
});
DialogActions.propTypes = {
  children: PropTypes__default['default'].node,

  /**
   * The className(s) of the component
   */
  className: PropTypes__default['default'].string
};

var DialogContext = /*#__PURE__*/React.createContext();

var css_248z$9 = ".uitk-density-touch .uitkDialogContent {\n  min-height: 20px;\n}\n.uitk-density-low .uitkDialogContent {\n  min-height: 18px;\n}\n.uitk-density-medium .uitkDialogContent {\n  min-height: 16px;\n}\n.uitk-density-high .uitkDialogContent {\n  min-height: 14px;\n}\n.uitkDialogContent {\n  flex: 1 1 auto;\n  font-size: var(--uitk-font-size-regular);\n  overflow: visible;\n  padding-top: calc(var(--uitk-space) * 2);\n  padding-bottom: calc(var(--uitk-space) * 3);\n  font-weight: var(--uitk-font-weightregular);\n  line-height: 1.3;\n}\n";
styleInject(css_248z$9);

var DialogContent = /*#__PURE__*/React.forwardRef(function DialogContent(props, ref) {
  var _classnames;

  var children = props.children,
      className = props.className,
      dividers = props.dividers,
      rest = _objectWithoutProperties(props, ["children", "className", "dividers"]);

  var _useContext = React.useContext(DialogContext),
      state = _useContext.state;

  var classBase = 'uitkDialogContent';
  return /*#__PURE__*/React__default['default'].createElement("div", _extends({}, rest, {
    className: classnames__default['default'](classBase, className, (_classnames = {}, _defineProperty(_classnames, "".concat(classBase, "-dividers"), dividers), _defineProperty(_classnames, "".concat(classBase, "-leftGutter"), !!state), _classnames), className),
    ref: ref
  }), children);
});
DialogContent.propTypes = {
  /**
   * @external - material-ui
   */
  children: PropTypes__default['default'].node,

  /**
   * The className(s) of the component
   */
  className: PropTypes__default['default'].string,

  /**
   * @external - material-ui
   */
  classes: PropTypes__default['default'].objectOf(PropTypes__default['default'].string)
};

var css_248z$a = ".accessibleText {\n  display: block;\n  position: absolute;\n  width: 1px;\n  height: 1px;\n  overflow: hidden;\n  top: 0;\n  left: 0;\n  opacity: 0;\n}\n\n.Icon {\n  color: var(--uitk-grey300);\n  speak: none;\n  display: inline-block;\n  position: relative;\n  box-sizing: border-box;\n  font-style: normal;\n  font-family: 'uitk-icons' !important;\n  font-weight: normal;\n  line-height: 1;\n  font-variant: normal;\n  text-transform: none;\n  -webkit-font-smoothing: antialiased;\n}\n\n.Icon-content {\n  display: block;\n}\n\n.small.Icon .Icon-content {\n  font-size: var(--uitk-size-icon-small);\n}\n\n.small.Icon .Svg-content {\n  width: 18px;\n  height: 18px;\n}\n\n.medium.Icon .Icon-content {\n  font-size: var(--uitk-size-icon-medium);\n}\n\n.large.Icon .Icon-content {\n  font-size: var(--uitk-size-icon-large);\n}\n\n.uitk-icon-notification-solid:before {\n  content: '\\e900';\n}\n.uitk-icon-alert-solid:before {\n  content: '\\e900';\n}\n.uitk-icon-notification:before {\n  content: '\\e901';\n}\n.uitk-icon-alert:before {\n  content: '\\e901';\n}\n.uitk-icon-attach:before {\n  content: '\\e902';\n}\n.uitk-icon-error-execute:before {\n  content: '\\e903';\n}\n.uitk-icon-cancel:before {\n  content: '\\e903';\n}\n.uitk-icon-bar-chart:before {\n  content: '\\e904';\n}\n.uitk-icon-chart:before {\n  content: '\\e904';\n}\n.uitk-icon-line-chart:before {\n  content: '\\e905';\n}\n.uitk-icon-charline:before {\n  content: '\\e905';\n}\n.uitk-icon-chartline:before {\n  content: '\\e905';\n}\n.uitk-icon-line-chart-solid:before {\n  content: '\\e906';\n}\n.uitk-icon-charline-solid:before {\n  content: '\\e906';\n}\n.uitk-icon-chartline-solid:before {\n  content: '\\e906';\n}\n.uitk-icon-chatting-solid:before {\n  content: '\\e907';\n}\n.uitk-icon-chat-busy-solid:before {\n  content: '\\e907';\n}\n.uitk-icon-chatting:before {\n  content: '\\e908';\n}\n.uitk-icon-chat-busy:before {\n  content: '\\e908';\n}\n.uitk-icon-chat-group-solid:before {\n  content: '\\e909';\n}\n.uitk-icon-chat-group:before {\n  content: '\\e90a';\n}\n.uitk-icon-chat-solid:before {\n  content: '\\e90b';\n}\n.uitk-icon-chat:before {\n  content: '\\e90c';\n}\n.uitk-icon-clone:before {\n  content: '\\e90d';\n}\n.uitk-icon-close:before {\n  content: '\\e90e';\n}\n.uitk-icon-column-chooser:before {\n  content: '\\e910';\n}\n.uitk-icon-delete-solid:before {\n  content: '\\e911';\n}\n.uitk-icon-delete:before {\n  content: '\\e912';\n}\n.uitk-icon-document:before {\n  content: '\\e913';\n}\n.uitk-icon-add-document:before {\n  content: '\\e914';\n}\n.uitk-icon-document-add:before {\n  content: '\\e914';\n}\n.uitk-icon-csv:before {\n  content: '\\e915';\n}\n.uitk-icon-document-csv:before {\n  content: '\\e915';\n}\n.uitk-icon-pdf:before {\n  content: '\\e916';\n}\n.uitk-icon-document-pdf:before {\n  content: '\\e916';\n}\n.uitk-icon-remove-document:before {\n  content: '\\e917';\n}\n.uitk-icon-document-remove:before {\n  content: '\\e917';\n}\n.uitk-icon-run-report:before {\n  content: '\\e918';\n}\n.uitk-icon-document-run:before {\n  content: '\\e918';\n}\n.uitk-icon-schedule-time:before {\n  content: '\\e919';\n}\n.uitk-icon-document-schedule-time:before {\n  content: '\\e919';\n}\n.uitk-icon-xls:before {\n  content: '\\e91a';\n}\n.uitk-icon-document-xls:before {\n  content: '\\e91a';\n}\n.uitk-icon-chevron-down:before {\n  content: '\\e91b';\n}\n.uitk-icon-down-arrow:before {\n  content: '\\e91b';\n}\n.uitk-icon-edit:before {\n  content: '\\e91c';\n}\n.uitk-icon-edit-solid:before {\n  content: '\\e91d';\n}\n.uitk-icon-export-solid:before {\n  content: '\\e91e';\n}\n.uitk-icon-export:before {\n  content: '\\e91f';\n}\n.uitk-icon-favorite-solid:before {\n  content: '\\e920';\n}\n.uitk-icon-favorite:before {\n  content: '\\e921';\n}\n.uitk-icon-filter-solid:before {\n  content: '\\e922';\n}\n.uitk-icon-filter:before {\n  content: '\\e923';\n}\n.uitk-icon-flag-solid:before {\n  content: '\\e924';\n}\n.uitk-icon-flag:before {\n  content: '\\e925';\n}\n.uitk-icon-grid-solid:before {\n  content: '\\e926';\n}\n.uitk-icon-grid:before {\n  content: '\\e927';\n}\n.uitk-icon-user-group-solid:before {\n  content: '\\e928';\n}\n.uitk-icon-group-solid:before {\n  content: '\\e928';\n}\n.uitk-icon-user-group:before {\n  content: '\\e929';\n}\n.uitk-icon-group:before {\n  content: '\\e929';\n}\n.uitk-icon-help-secondary:before {\n  content: '\\e92b';\n}\n.uitk-icon-help:before {\n  content: '\\e92a';\n}\n.uitk-icon-help-solid:before {\n  content: '\\e92a';\n}\n.uitk-icon-home-solid:before {\n  content: '\\e92c';\n}\n.uitk-icon-home:before {\n  content: '\\e92d';\n}\n.uitk-icon-import-solid:before {\n  content: '\\e92e';\n}\n.uitk-icon-import:before {\n  content: '\\e92f';\n}\n.uitk-icon-info-secondary:before {\n  content: '\\e931';\n}\n.uitk-icon-info:before {\n  content: '\\e930';\n}\n.uitk-icon-info-solid:before {\n  content: '\\e930';\n}\n.uitk-icon-price-ladder:before {\n  content: '\\e932';\n}\n.uitk-icon-ladder:before {\n  content: '\\e932';\n}\n.uitk-icon-chevron-left:before {\n  content: '\\e933';\n}\n.uitk-icon-left-arrow:before {\n  content: '\\e933';\n}\n.uitk-icon-double-chevron-left:before {\n  content: '\\e934';\n}\n.uitk-icon-left-expand:before {\n  content: '\\e934';\n}\n.uitk-icon-linked:before {\n  content: '\\e935';\n}\n.uitk-icon-list:before {\n  content: '\\e936';\n}\n.uitk-icon-locked-solid:before {\n  content: '\\e937';\n}\n.uitk-icon-locked:before {\n  content: '\\e938';\n}\n.uitk-icon-maximize:before {\n  content: '\\e939';\n}\n.uitk-icon-maximise:before {\n  content: '\\e939';\n}\n.uitk-icon-menu:before {\n  content: '\\e93a';\n}\n.uitk-icon-menu-burger:before {\n  content: '\\e93a';\n}\n.uitk-icon-message-solid:before {\n  content: '\\e93b';\n}\n.uitk-icon-message:before {\n  content: '\\e93c';\n}\n.uitk-icon-minimize:before {\n  content: '\\e93d';\n}\n.uitk-icon-minimise:before {\n  content: '\\e93d';\n}\n.uitk-icon-overflow-menu:before {\n  content: '\\e93e';\n}\n.uitk-icon-more:before {\n  content: '\\e93e';\n}\n.uitk-icon-arrow-down:before {\n  content: '\\e93f';\n}\n.uitk-icon-movement-down:before {\n  content: '\\e93f';\n}\n.uitk-icon-arrow-up:before {\n  content: '\\e940';\n}\n.uitk-icon-movement-up:before {\n  content: '\\e940';\n}\n.uitk-icon-pause:before {\n  content: '\\e941';\n}\n.uitk-icon-call-solid:before {\n  content: '\\e942';\n}\n.uitk-icon-phone-solid:before {\n  content: '\\e942';\n}\n.uitk-icon-call:before {\n  content: '\\e943';\n}\n.uitk-icon-phone:before {\n  content: '\\e943';\n}\n.uitk-icon-pin-solid:before {\n  content: '\\e944';\n}\n.uitk-icon-pin:before {\n  content: '\\e945';\n}\n.uitk-icon-place-in:before {\n  content: '\\e946';\n}\n.uitk-icon-play-solid:before {\n  content: '\\e947';\n}\n.uitk-icon-play:before {\n  content: '\\e948';\n}\n.uitk-icon-print-solid:before {\n  content: '\\e949';\n}\n.uitk-icon-print:before {\n  content: '\\e94a';\n}\n.uitk-icon-redo:before {\n  content: '\\e94b';\n}\n.uitk-icon-undo:before {\n  content: '\\e94c';\n}\n.uitk-icon-refresh:before {\n  content: '\\e94d';\n}\n.uitk-icon-remove:before {\n  content: '\\e94e';\n}\n.uitk-icon-minus:before {\n  content: '\\e94e';\n}\n.uitk-icon-build-report:before {\n  content: '\\e94f';\n}\n.uitk-icon-report-builder:before {\n  content: '\\e94f';\n}\n.uitk-icon-chevron-right:before {\n  content: '\\e950';\n}\n.uitk-icon-right-arrow:before {\n  content: '\\e950';\n}\n.uitk-icon-double-chevron-right:before {\n  content: '\\e951';\n}\n.uitk-icon-right-expand:before {\n  content: '\\e951';\n}\n.uitk-icon-save-solid:before {\n  content: '\\e952';\n}\n.uitk-icon-save:before {\n  content: '\\e953';\n}\n.uitk-icon-search:before {\n  content: '\\e954';\n}\n.uitk-icon-settings-solid:before {\n  content: '\\e955';\n}\n.uitk-icon-settings:before {\n  content: '\\e956';\n}\n.uitk-icon-share-solid:before {\n  content: '\\e957';\n}\n.uitk-icon-share:before {\n  content: '\\e958';\n}\n.uitk-icon-swap:before {\n  content: '\\e959';\n}\n.uitk-icon-swap-switch:before {\n  content: '\\e959';\n}\n.uitk-icon-tear-out:before {\n  content: '\\e95a';\n}\n.uitk-icon-success-tick:before {\n  content: '\\e95b';\n}\n.uitk-icon-tick:before {\n  content: '\\e95b';\n}\n.uitk-icon-clock-solid:before {\n  content: '\\e95c';\n}\n.uitk-icon-time-solid:before {\n  content: '\\e95c';\n}\n.uitk-icon-clock:before {\n  content: '\\e95d';\n}\n.uitk-icon-time:before {\n  content: '\\e95d';\n}\n.uitk-icon-unlinked:before {\n  content: '\\e95e';\n}\n.uitk-icon-unlocked-solid:before {\n  content: '\\e95f';\n}\n.uitk-icon-unlocked:before {\n  content: '\\e960';\n}\n.uitk-icon-chevron-up:before {\n  content: '\\e961';\n}\n.uitk-icon-up-arrow:before {\n  content: '\\e961';\n}\n.uitk-icon-user-solid:before {\n  content: '\\e962';\n}\n.uitk-icon-user:before {\n  content: '\\e963';\n}\n.uitk-icon-visible-solid:before {\n  content: '\\e964';\n}\n.uitk-icon-visible:before {\n  content: '\\e965';\n}\n.uitk-icon-hidden:before {\n  content: '\\e966';\n}\n.uitk-icon-visible-off:before {\n  content: '\\e966';\n}\n.uitk-icon-warning-secondary:before {\n  content: '\\e968';\n}\n.uitk-icon-warning:before {\n  content: '\\e967';\n}\n.uitk-icon-warning-solid:before {\n  content: '\\e967';\n}\n.uitk-icon-micro-menu:before {\n  content: '\\e969';\n}\n.uitk-icon-more-vert:before {\n  content: '\\e969';\n}\n.uitk-icon-user-badge:before {\n  content: '\\e96a';\n}\n.uitk-icon-user-circled:before {\n  content: '\\e96a';\n}\n.uitk-icon-cut:before {\n  content: '\\e96d';\n}\n.uitk-icon-folder-closed:before {\n  content: '\\e96e';\n}\n.uitk-icon-folder:before {\n  content: '\\e96e';\n}\n.uitk-icon-loader:before {\n  content: '\\e96f';\n}\n.uitk-icon-move-all:before {\n  content: '\\e970';\n}\n.uitk-icon-move-vertical:before {\n  content: '\\e971';\n}\n.uitk-icon-move-updown:before {\n  content: '\\e971';\n}\n.uitk-icon-paste:before {\n  content: '\\e972';\n}\n.uitk-icon-add:before {\n  content: '\\e973';\n}\n.uitk-icon-plus:before {\n  content: '\\e973';\n}\n.uitk-icon-sum-solid:before {\n  content: '\\e974';\n}\n.uitk-icon-sigma-solid:before {\n  content: '\\e974';\n}\n.uitk-icon-sum:before {\n  content: '\\e975';\n}\n.uitk-icon-sigma:before {\n  content: '\\e975';\n}\n.uitk-icon-tree:before {\n  content: '\\e976';\n}\n.uitk-icon-calendar:before {\n  content: '\\e977';\n}\n.uitk-icon-folder-open:before {\n  content: '\\e978';\n}\n.uitk-icon-pivot:before {\n  content: '\\e979';\n}\n.uitk-icon-arrow-left:before {\n  content: '\\e97a';\n}\n.uitk-icon-arrow-right:before {\n  content: '\\e97b';\n}\n.uitk-icon-double-chevron-down:before {\n  content: '\\e97c';\n}\n.uitk-icon-down-expand:before {\n  content: '\\e97c';\n}\n.uitk-icon-double-chevron-up:before {\n  content: '\\e97d';\n}\n.uitk-icon-up-expand:before {\n  content: '\\e97d';\n}\n.uitk-icon-upload:before {\n  content: '\\e97e';\n}\n.uitk-icon-download:before {\n  content: '\\e97f';\n}\n.uitk-icon-triangle-right:before {\n  content: '\\e980';\n}\n.uitk-icon-triangle-right-filled:before {\n  content: '\\e980';\n}\n.uitk-icon-triangle-left:before {\n  content: '\\e981';\n}\n.uitk-icon-triangle-left-filled:before {\n  content: '\\e981';\n}\n.uitk-icon-triangle-up:before {\n  content: '\\e982';\n}\n.uitk-icon-triangle-up-filled:before {\n  content: '\\e982';\n}\n.uitk-icon-triangle-down:before {\n  content: '\\e983';\n}\n.uitk-icon-triangle-down-filled:before {\n  content: '\\e983';\n}\n.uitk-icon-copy:before {\n  content: '\\e984';\n}\n.uitk-icon-error-secondary:before {\n  content: '\\e986';\n}\n.uitk-icon-error:before {\n  content: '\\e985';\n}\n.uitk-icon-error-solid:before {\n  content: '\\e985';\n}\n.uitk-icon-commentary:before {\n  content: '\\e987';\n}\n.uitk-icon-pause-solid:before {\n  content: '\\e988';\n}\n.uitk-icon-success:before {\n  content: '\\e989';\n}\n.uitk-icon-success-secondary:before {\n  content: '\\e98a';\n}\n.uitk-icon-move-horizontal:before {\n  content: '\\e98b';\n}\n.uitk-icon-app-switcher:before {\n  content: '\\e98c';\n}\n.uitk-icon-close-small:before {\n  content: '\\e98d';\n}\n.uitk-icon-triangle-right-down:before {\n  content: '\\e98e';\n}\n.uitk-icon-send:before {\n  content: '\\e98f';\n}\n.uitk-icon-location:before {\n  content: '\\e990';\n}\n.uitk-icon-restore:before {\n  content: '\\e991';\n}\n";
styleInject(css_248z$a);

var ICON_SIZES = ['small', 'medium', 'large'];

// get the string passed as either the new accessibleText prop or
// as human readable name of the icon
var getAccessibleString = function getAccessibleString(accessibleText, name) {
  if (typeof accessibleText === 'boolean') {
    if (accessibleText) {
      return name;
    }
  } else {
    return accessibleText;
  }
}; // return the accessible text element with hiddenStyle props


var getAccessibleText = function getAccessibleText(accessibleText, brand, name) {
  if (accessibleText) {
    return /*#__PURE__*/React__default['default'].createElement("span", {
      className: "accessibleText"
    }, getAccessibleString(accessibleText, name));
  }
};

// TODO: memoize
var Icon = /*#__PURE__*/React.forwardRef(function Icon(_ref, ref) {
  var _classnames;

  var accessibleText = _ref.accessibleText,
      _ref$brand = _ref.brand,
      brand = _ref$brand === void 0 ? 'uitk' : _ref$brand,
      className = _ref.className,
      name = _ref.name,
      _ref$size = _ref.size,
      sizeProp = _ref$size === void 0 ? 'small' : _ref$size,
      _ref$svg = _ref.svg,
      svg = _ref$svg === void 0 ? null : _ref$svg,
      rest = _objectWithoutProperties(_ref, ["accessibleText", "brand", "className", "name", "size", "svg"]);

  var contentRef = React.useRef(null);
  var isSize = ICON_SIZES.indexOf(sizeProp) !== -1;
  var classNameFromContext = React.useContext(IconClassNameContext);
  React.useEffect(function () {
    if (svg && contentRef.current) {
      contentRef.current.innerHTML = svg;
    }
  }, [contentRef, svg]); // TODO confirm svg is indeed an SVG if children passed

  return /*#__PURE__*/React__default['default'].createElement("span", _extends({
    className: classnames__default['default']('Icon', "".concat(brand, "-wrap-icon"), className, isSize && sizeProp, classNameFromContext)
  }, rest, {
    ref: ref
  }), /*#__PURE__*/React__default['default'].createElement("span", {
    "aria-hidden": "true",
    className: classnames__default['default']('Icon-content', (_classnames = {}, _defineProperty(_classnames, "".concat(brand, "-icon-").concat(name), name), _defineProperty(_classnames, 'Svg-content', svg !== null), _classnames)),
    ref: contentRef,
    style: !isSize ? {
      fontSize: "".concat(sizeProp, "px")
    } : undefined
  }), getAccessibleText(accessibleText, brand, name));
});

var State = Object.freeze({
  ERROR: 'error',
  SUCCESS: 'success',
  WARNING: 'warning',
  INFO: 'info'
});

var css_248z$b = ".uitkStateIcon {\n  margin-right: 8px;\n  line-height: 1.33333333em;\n}\n\n.uitkStateIcon-warning {\n  color: var(--uitk-status-warning-color);\n}\n\n.uitkStateIcon-info {\n  color: var(--uitk-status-info-color);\n}\n\n.uitkStateIcon-success {\n  color: var(--uitk-status-success-color);\n}\n\n.uitkStateIcon-error {\n  color: var(--uitk-status-error-color);\n}\n";
styleInject(css_248z$b);

var _icons;
var icons = (_icons = {}, _defineProperty(_icons, State.ERROR, 'error'), _defineProperty(_icons, State.SUCCESS, 'tick'), _defineProperty(_icons, State.WARNING, 'warning'), _defineProperty(_icons, State.INFO, 'info'), _icons);

function StateIcon(props) {
  var className = props.className,
      state = props.state;
  var classBase = 'uitkStateIcon';
  return /*#__PURE__*/React__default['default'].createElement(Icon, {
    className: classnames__default['default'](classBase, "".concat(classBase, "-").concat(state), className),
    name: icons[state],
    size: 24
  });
}

StateIcon.propTypes = {
  /**
   * The className(s) of the component
   */
  className: PropTypes__default['default'].string,

  /**
   * state
   */
  state: PropTypes__default['default'].oneOf(['error', 'success', 'warning', 'info']).isRequired
};

var css_248z$c = ".uitk-density-touch .uitkDialogTitle {\n  --font-size: 24px;\n}\n.uitk-density-low .uitkDialogTitle {\n  --font-size: 24px;\n}\n.uitk-density-medium .uitkDialogTitle {\n  --font-size: 22px;\n}\n.uitk-density-high .uitkDialogTitle {\n  --font-size: 20px;\n}\n\n.uitkDialogTitle {\n  --close-button-offset: calc(var(--dialog-padding) * -1);\n  display: flex;\n  flex: 0 0 auto;\n  font-size: var(--font-size);\n  font-weight: 600;\n  line-height: var(--uitk-line-height);\n  min-height: 16px;\n  position: relative;\n}\n.uitkDialogTitle-close {\n  position: absolute;\n  right: var(--close-button-offset);\n  top: var(--close-button-offset);\n}\n";
styleInject(css_248z$c);

var DialogTitle = /*#__PURE__*/React.forwardRef(function DialogTitle(props, ref) {
  var children = props.children,
      className = props.className,
      onClose = props.onClose,
      rest = _objectWithoutProperties(props, ["children", "classes", "className", "onClose"]);

  var _useContext = React.useContext(DialogContext),
      state = _useContext.state;

  var classBase = 'uitkDialogTitle';
  return /*#__PURE__*/React__default['default'].createElement("div", _extends({
    className: classnames__default['default'](classBase, className),
    ref: ref
  }, rest), onClose && /*#__PURE__*/React__default['default'].createElement(Button, {
    className: "".concat(classBase, "-close"),
    onClick: onClose,
    variant: "secondary"
  }, /*#__PURE__*/React__default['default'].createElement(Icon, {
    accessibleText: "close dialog",
    className: "".concat(classBase, "-closeIcon"),
    name: "close",
    size: 14
  })), state && /*#__PURE__*/React__default['default'].createElement(StateIcon, {
    className: "".concat(classBase, "-stateIcon"),
    state: state
  }), children);
});
DialogTitle.propTypes = {
  children: PropTypes__default['default'].node,

  /**
   * The className(s) of the component
   */
  className: PropTypes__default['default'].string,
  onClose: PropTypes__default['default'].func
};

var useEnhancedEffect$2 = typeof window !== 'undefined' ? React.useLayoutEffect : React.useEffect;
/**
 * Portals provide a first-class way to render children into a DOM node
 * that exists outside the DOM hierarchy of the parent component.
 */

var Portal = /*#__PURE__*/React.forwardRef(function Portal(props, ref) {
  var children = props.children,
      container = props.container,
      _props$disablePortal = props.disablePortal,
      disablePortal = _props$disablePortal === void 0 ? false : _props$disablePortal,
      onRendered = props.onRendered;

  var _React$useState = React.useState(null),
      _React$useState2 = _slicedToArray(_React$useState, 2),
      mountNode = _React$useState2[0],
      setMountNode = _React$useState2[1];

  var _useThemeProps = useThemeProps(),
      themeName = _useThemeProps.theme.name,
      density = _useThemeProps.density;

  var handleRef = useForkRef( /*#__PURE__*/React.isValidElement(children) ? children.ref : null, ref);
  useEnhancedEffect$2(function () {
    if (!disablePortal) {
      //   setMountNode(getContainer(container) || document.body);
      setMountNode(document.body);
    }
  }, [container, disablePortal]);
  useEnhancedEffect$2(function () {
    if (mountNode && !disablePortal) {
      setRef(ref, mountNode);
      return function () {
        setRef(ref, null);
      };
    }

    return undefined;
  }, [ref, mountNode, disablePortal]);
  useEnhancedEffect$2(function () {
    if (onRendered && (mountNode || disablePortal)) {
      onRendered();
    }
  }, [onRendered, mountNode, disablePortal]);

  if (disablePortal) {
    if ( /*#__PURE__*/React.isValidElement(children)) {
      return /*#__PURE__*/React.cloneElement(children, {
        ref: handleRef
      });
    }

    return children;
  }

  return mountNode ? /*#__PURE__*/ReactDOM.createPortal( /*#__PURE__*/React.createElement(ThemeProvider, {
    density: density,
    theme: themeName
  }, children), mountNode) : mountNode;
});
Portal.propTypes = {
  /**
   * The children to render into the `container`.
   */
  children: PropTypes__default['default'].node,

  /**
   * A HTML element, component instance, or function that returns either.
   * The `container` will have the portal children appended to it.
   *
   * By default, it uses the body of the top-level document object,
   * so it's simply `document.body` most of the time.
   */
  container: PropTypes__default['default']
  /* @typescript-to-proptypes-ignore */
  .oneOfType([PropTypes__default['default'].object, PropTypes__default['default'].instanceOf(React.Component), PropTypes__default['default'].func]),

  /**
   * Disable the portal behavior.
   * The children stay within it's parent DOM hierarchy.
   */
  disablePortal: PropTypes__default['default'].bool,

  /**
   * Callback fired once the children has been mounted into the `container`.
   *
   * This prop will be deprecated and removed in v5, the ref can be used instead.
   */
  onRendered: PropTypes__default['default'].func
};

var defaultSelector = "\n[tabindex=\"0\"], \na:not([tabindex=\"-1\"]), \narea:not([tabindex=\"-1\"]), \ndetails:not([tabindex=\"-1\"]), \niframe:not([tabindex=\"-1\"]), \nselect:not([tabindex=\"-1\"]), \ntextarea:not([tabindex=\"-1\"]), \nbutton:not([tabindex=\"-1\"]), \ninput:not([tabindex=\"-1\"])\n";
/**
 * Used to reduce the number of intial nodes that are checked to see if tabbable.
 *
 * Not possible to immediately check if a node is tabbable because the node may be a custom element
 * and therefore could potentially have a tabbable node within its shadow root.
 */

var anyKeyboardFocusableElementSelector = '*:not(style):not(script):not(noscript):not(link):not([tabindex="-1"])';

function getActiveElement(node) {
  var doc = node && node.ownerDocument || document;
  return doc.activeElement;
}

var FocusTrap = function FocusTrap(props) {
  var containerRef = React.useRef(null);
  var trapStartRef = React.useRef(null);
  var trapEndRef = React.useRef(null);

  var _useState = React.useState(false),
      _useState2 = _slicedToArray(_useState, 2),
      hasFocus = _useState2[0],
      setHasFocus = _useState2[1];

  var active = props.active,
      children = props.children,
      className = props.className,
      tabEnabledSelectors = props.tabEnabledSelectors;
  React.useEffect(function () {
    var tabIndex = active ? '0' : '-1';
    trapStartRef.current.setAttribute('tabIndex', tabIndex);
    trapEndRef.current.setAttribute('tabIndex', tabIndex);
  }, [active]);
  /**
   * Finds all the elements in the given root node that can be focused by a 'tab' keypress.
   * In addition, the trap-start and -end sentinel nodes are excluded, and all contained
   * shadow roots are walked recursively.
   * @param {Node} rootNode The containing node from which traversal begins.
   * @param {string} selector The CSS selector used to query for matching, tabbable elements.
   */

  var findAllTabbableElements = function findAllTabbableElements(rootNode, selector) {
    var nodes = Array.prototype.slice.call(rootNode.querySelectorAll(anyKeyboardFocusableElementSelector));
    return nodes.reduce(function (foundNodes, node) {
      // Exclude sentinel nodes
      if (node === trapStartRef.current || node === trapEndRef.current) {
        return foundNodes;
      }

      if (!node.shadowRoot && node.matches(selector)) {
        // if this element is inside a shadowRoot then the host not the element itself is needed
        return foundNodes.concat(node.parentNode.host || node);
      }

      if (node.shadowRoot) {
        return foundNodes.concat(findAllTabbableElements(node.shadowRoot, selector));
      }

      return foundNodes;
    }, []);
  };
  /**
   * Given a list of elements and an index, the corresponding element is returned, if exists.
   * Alternatively, for a shadow root, the first tabbable element is returned.
   * @param {Node[]} tabbableElements A list of elements from which to select.
   * @param {number} index The list index.
   */


  var resolveElementAtIndex = function resolveElementAtIndex(tabbableElements, index) {
    if (tabbableElements.length >= 1) {
      var element = tabbableElements[index];

      if (element && element.shadowRoot) {
        return element.shadowRoot.querySelector(tabEnabledSelectors);
      }

      return element;
    }
  };
  /**
   * Return the first tabbable element within the content area.
   */


  var getFirstElement = function getFirstElement() {
    var tabbableElements = findAllTabbableElements(containerRef.current, tabEnabledSelectors);
    return resolveElementAtIndex(tabbableElements, 0);
  };
  /**
   * Return the last tabble element within the content area.
   */


  var getLastElement = function getLastElement() {
    var tabbableElements = findAllTabbableElements(containerRef.current, tabEnabledSelectors);
    return resolveElementAtIndex(tabbableElements, tabbableElements.length - 1);
  };
  /**
   * When the trap-start sentinel node gains focus, pass focus to either
   * the first or last tabbable element, depending on the direction of travel
   * (i.e. Tab or Shift+Tab).
   * @param {React.FocusEvent} event The synthetic focus event.
   */


  var handleTrapStartFocus = function handleTrapStartFocus(event) {
    var isEnteringFocusTrap = !hasFocus && getActiveElement(containerRef.current) === trapStartRef.current;
    var nextElement = isEnteringFocusTrap ? getFirstElement() : getLastElement();

    if (nextElement) {
      nextElement.focus();
    }

    event.preventDefault();
  };
  /**
   * When the trap-end sentinel node gains focus, pass focus
   * to the first tabbable element.
   * @param {React.FocusEvent} event The synthetic focus event.
   */


  var handleTrapEndFocus = function handleTrapEndFocus(event) {
    var nextElement = getFirstElement();

    if (nextElement) {
      nextElement.focus();
    }

    event.preventDefault();
  };

  return /*#__PURE__*/React__default['default'].createElement("div", {
    className: className,
    onFocus: function onFocus() {
      return setHasFocus(true);
    },
    ref: containerRef
  }, /*#__PURE__*/React__default['default'].createElement("div", {
    "aria-hidden": "true",
    onFocus: handleTrapStartFocus,
    ref: trapStartRef,
    tabIndex: "-1"
  }), children, /*#__PURE__*/React__default['default'].createElement("div", {
    "aria-hidden": "true",
    onFocus: handleTrapEndFocus,
    ref: trapEndRef,
    tabIndex: "-1"
  }));
};

FocusTrap.defaultProps = {
  tabEnabledSelectors: defaultSelector
};
FocusTrap.propTypes = {
  active: PropTypes__default['default'].bool,
  children: PropTypes__default['default'].node,
  className: PropTypes__default['default'].string,

  /**
   * comma separated string of query selectors which may need to be overidden for edge cases. Defaults to:
   * '[tabindex="0"], a:not([tabindex="-1"]), area:not([tabindex="-1"]), details:not([tabindex="-1"]), iframe:not([tabindex="-1"]), select:not([tabindex="-1"]), textarea:not([tabindex="-1"]), button:not([tabindex="-1"]), input:not([tabindex="-1"])'
   */
  tabEnabledSelectors: PropTypes__default['default'].string
};

var ScrimContext = /*#__PURE__*/React.createContext(null);

var css_248z$d = ".uitk-light {\n  -uitk-scrim-bg: rgba(0, 0, 0, 0.8);\n  -uitk-scrim-lighter-bg: var(--white-fade-80);\n}\n\n.uitk-dark {\n  -uitk-scrim-bg: rgba(0, 0, 0, 0.7);\n  -uitk-scrim-lighter-bg: var(--uitk-grey800-fade-80);\n}\n\n.uitkScrim {\n  top: 0;\n  left: 0;\n  right: 0;\n  width: 100%;\n  bottom: 0;\n  height: 100%;\n  display: flex;\n  z-index: 1199;\n  position: fixed;\n  align-items: center;\n  justify-content: center;\n  background-color: var(--uitk-scrim-bg, rgba(0, 0, 0, 0.8));\n  -webkit-tap-highlight-color: transparent;\n}\n\n.uitkScrim:focus {\n  outline: none;\n}\n\n.uitkScrim-containerFix {\n  position: absolute;\n  z-index: calc(var(--uitk-zindex-appbar) - 1);\n}\n\n.uitkScrim-lighter {\n  background-color: var(--uitk-scrim-lighter-bg, var(--white-fade-80));\n}\n";
styleInject(css_248z$d);

var Scrim = /*#__PURE__*/React.forwardRef(function Scrim(props, ref) {
  var _props$closeWithEscap = props.closeWithEscape,
      closeWithEscape = _props$closeWithEscap === void 0 ? false : _props$closeWithEscap,
      className = props.className,
      children = props.children,
      _props$containerFix = props.containerFix,
      containerFix = _props$containerFix === void 0 ? false : _props$containerFix,
      onBackDropClick = props.onBackDropClick,
      onClose = props.onClose,
      open = props.open,
      parentNode = props.parentNode,
      parentRef = props.parentRef,
      _props$returnFocus = props.returnFocus,
      returnFocus = _props$returnFocus === void 0 ? true : _props$returnFocus,
      tabEnabledSelectors = props.tabEnabledSelectors,
      variant = props.variant,
      zIndex = props.zIndex,
      rest = _objectWithoutProperties(props, ["closeWithEscape", "className", "children", "containerFix", "onBackDropClick", "onClose", "open", "parentNode", "parentRef", "returnFocus", "tabEnabledSelectors", "variant", "zIndex"]);

  var scrimRef = React.useRef(null);
  var setWrapperRef = useForkRef(ref, scrimRef);
  var focusedElement = React.useRef(null);
  var classRoot = 'uitkScrim';
  console.log("Scrim render");
  React.useEffect(function () {
    var undoAria = null;

    if (open) {
      focusedElement.current = document && document.activeElement;
      var parent = parentRef && parentRef.current !== undefined ? parentRef.current : parentNode;
      undoAria = parent ? ariaHidden.hideOthers(scrimRef.current, parent) : ariaHidden.hideOthers(scrimRef.current);
      scrimRef.current && scrimRef.current.focus();
      !containerFix && noScroll__default['default'].on();
    }

    return function () {
      if (open) {
        undoAria && undoAria();

        if (returnFocus) {
          var focusOptions = _typeof(returnFocus) === 'object' ? returnFocus : undefined;
          focusedElement.current && focusedElement.current.focus(focusOptions);
        }

        !containerFix && noScroll__default['default'].off();
      }
    };
  }, [containerFix, open, parentNode, parentRef, returnFocus]);

  var getBodyForContainer = function getBodyForContainer() {
    var _classnames;

    return /*#__PURE__*/React__default['default'].createElement("div", _extends({
      "aria-modal": "true",
      className: classnames__default['default'](className, classRoot, (_classnames = {}, _defineProperty(_classnames, "".concat(classRoot, "-containerFix"), containerFix), _defineProperty(_classnames, "".concat(classRoot, "-").concat(variant), variant !== 'standard'), _classnames)),
      "data-jpmui-test": "scrim",
      onClick: handleClick,
      onKeyDown: handleKeyDown,
      ref: setWrapperRef,
      role: "dialog",
      style: {
        zIndex: zIndex
      },
      tabIndex: 0
    }, rest), /*#__PURE__*/React__default['default'].createElement(ScrimContext.Provider, {
      value: onClose
    }, children));
  };

  var getBodyWithFocusTrap = function getBodyWithFocusTrap() {
    var _classnames2;

    return /*#__PURE__*/React__default['default'].createElement(FocusTrap, {
      active: true,
      tabEnabledSelectors: tabEnabledSelectors
    }, /*#__PURE__*/React__default['default'].createElement("div", _extends({
      "aria-modal": "true",
      className: classnames__default['default'](className, classRoot, (_classnames2 = {}, _defineProperty(_classnames2, "".concat(classRoot, "-containerFix"), containerFix), _defineProperty(_classnames2, "".concat(classRoot, "-").concat(variant), variant !== 'regular'), _classnames2)),
      "data-jpmui-test": "scrim",
      onClick: handleClick,
      onKeyDown: handleKeyDown,
      ref: setWrapperRef,
      role: "dialog",
      style: {
        zIndex: zIndex
      },
      tabIndex: 0
    }, rest), /*#__PURE__*/React__default['default'].createElement(ScrimContext.Provider, {
      value: onClose
    }, children)));
  };

  var handleKeyDown = function handleKeyDown(event) {
    if (event.key === 'Escape') {
      closeWithEscape && onClose && onClose();
    }
  };

  var handleClick = function handleClick() {
    onBackDropClick && onBackDropClick();
  };

  return /*#__PURE__*/React__default['default'].createElement(React__default['default'].Fragment, null, open && (containerFix ? getBodyForContainer() : getBodyWithFocusTrap()));
});
Scrim.propTypes = {
  /**
   * Child component of Scrim
   */
  children: PropTypes__default['default'].node,

  /**
   * The className(s) of the component
   */
  className: PropTypes__default['default'].string,

  /**
   * Prop to enable escape key to close scrim.
   * The default value of this props is false
   */
  closeWithEscape: PropTypes__default['default'].bool,

  /**
   * Prop to enable container use case.
   * It also sets the different z-index for usage in containers.
   * If present it will also override FocusTrap for Scrim.
   * Default value of containerFix is false.
   */
  containerFix: PropTypes__default['default'].bool,

  /**
   * The handler for backdrop click on Scrim.
   */
  onBackDropClick: PropTypes__default['default'].func,

  /**
   * The handler for onClose of Scrim
   */
  onClose: PropTypes__default['default'].func,

  /**
   * To maintainn open and close of the scrim
   */
  open: PropTypes__default['default'].bool,

  /**
   * Parent node for custom elements - as ref could not be passed.
   */
  // eslint-disable-next-line react/forbid-prop-types
  parentNode: PropTypes__default['default'].object,

  /**
   * Parent react ref which needs to be passed in container use case
   */
  parentRef: refType,

  /**
   * Prop to return focus to active element of when Scrim is closed.
   * The default value is true.
   */
  returnFocus: PropTypes__default['default'].oneOfType([PropTypes__default['default'].object, PropTypes__default['default'].bool]),

  /**
   * comma separated string of query selectors which may need to be overidden for edge cases. Defaults to:
   * '[tabindex="0"], a:not([tabindex="-1"]), area:not([tabindex="-1"]), details:not([tabindex="-1"]), iframe:not([tabindex="-1"]), select:not([tabindex="-1"]), textarea:not([tabindex="-1"]), button:not([tabindex="-1"]), input:not([tabindex="-1"])'
   */
  tabEnabledSelectors: PropTypes__default['default'].string,

  /**
   * Variant - Can be standard or lighter
   */
  variant: PropTypes__default['default'].oneOf(['regular', 'lighter']),

  /**
   * Prop to pass z-index for Scrim.
   */
  zIndex: PropTypes__default['default'].number
};

var css_248z$e = ".uitk-dark .uitkDialog {\n  --uitk-container1-border-color: var(--uitk-grey400);\n}\n\n.uitkDialog {\n  --dialog-padding: calc(var(--uitk-space) * 3);\n  background: var(--uitk-container1-background);\n  border-color: var(--uitk-container1-border-color);\n  border-width: var(--uitk-container1-border-width);\n  border-style: solid;\n  border-bottom-width: 2px;\n  box-sizing: border-box;\n  display: flex;\n  flex-direction: column;\n  font-family: var(--uitk-font-family);\n  inset: 0; /* what does this do ? */\n  max-height: 100%;\n  max-width: 100%;\n  overflow: auto;\n  padding: var(--dialog-padding);\n  position: relative;\n}\n\n@media (min-width: 0px) {\n  .uitkDialog {\n    max-height: 90%;\n    width: 100%;\n  }\n}\n@media (min-width: 600px) {\n  .uitkDialog {\n    max-height: 90%;\n    width: 60%;\n  }\n}\n@media (min-width: 960px) {\n  .uitkDialog {\n    max-height: 80%;\n    width: 50%;\n  }\n}\n";
styleInject(css_248z$e);

/**
 * The Dialog is a window that contains text and interactive components.
 * By default, Dialog is non-modal, but supports modal behaviour as well.
 */

var Dialog = /*#__PURE__*/React.forwardRef(function Dialog(props, ref) {
  var children = props.children,
      className = props.className,
      onClose = props.onClose,
      openProp = props.open,
      state = props.state,
      width = props.width,
      enableBackdropClick = props.enableBackdropClick,
      rest = _objectWithoutProperties(props, ["children", "className", "density", "height", "onClose", "onEntered", "open", "state", "tabEnabledSelectors", "width", "enableBackdropClick", "ScrimProps", "maxWidth"]);

  var _useState = React.useState(openProp),
      _useState2 = _slicedToArray(_useState, 2),
      open = _useState2[0],
      setOpen = _useState2[1];

  React.useEffect(function () {
    setOpen(openProp);
  }, [openProp]);
  var classBase = 'uitkDialog';
  var handleClose = React.useCallback(function () {
    onClose && onClose();
    setOpen(false);
  }, [onClose, setOpen]);
  var handleBackdropClick = React.useCallback(function () {
    if (enableBackdropClick) {
      handleClose();
    }
  }, [enableBackdropClick, handleClose]);
  var dialogClasses = classnames__default['default'](classBase, className, _defineProperty({}, "".concat(classBase, "-infoShadow"), state === 'info'));
  return open ? /*#__PURE__*/React__default['default'].createElement(DialogContext.Provider, {
    value: {
      state: state
    }
  }, /*#__PURE__*/React__default['default'].createElement(Portal, null, /*#__PURE__*/React__default['default'].createElement(Scrim, {
    open: open,
    closeWithEscape: true,
    onBackDropClick: handleBackdropClick,
    onClose: handleClose // variant="lighter"

  }, /*#__PURE__*/React__default['default'].createElement("div", _extends({}, rest, {
    className: classnames__default['default'](dialogClasses),
    role: "presentation",
    style: {
      width: width
    }
  }), children)))) : null;
});
Dialog.propTypes = {
  /**
   * @external - material-ui
   */
  children: PropTypes__default['default'].node,

  /**
   * The className(s) of the component
   */
  className: PropTypes__default['default'].string,

  /**
   * @external - material-ui
   */
  disableEscapeKeyDown: PropTypes__default['default'].bool,

  /**
   * if set to true enables backdrop click
   */
  enableBackdropClick: PropTypes__default['default'].bool,

  /**
   * @external - material-ui
   */
  fullScreen: PropTypes__default['default'].bool,

  /**
   * @external - material-ui
   */
  fullWidth: PropTypes__default['default'].bool,

  /**
   * Dialog height. This will override any built-in responsive behaviour.
   */
  height: PropTypes__default['default'].oneOfType([PropTypes__default['default'].number, PropTypes__default['default'].string]),

  /**
   * @external - material-ui
   */
  maxWidth: PropTypes__default['default'].oneOf(['xs', 'sm', 'md', 'lg', false]),

  /**
   * @external - material-ui
   */
  onBackdropClick: PropTypes__default['default'].func,

  /**
   * @external - material-ui
   */
  onClose: PropTypes__default['default'].func,

  /**
   * @external - material-ui
   */
  onEnter: PropTypes__default['default'].func,

  /**
   * @external - material-ui
   */
  onEntered: PropTypes__default['default'].func,

  /**
   * @external - material-ui
   */
  onEntering: PropTypes__default['default'].func,

  /**
   * @external - material-ui
   */
  onEscapeKeyDown: PropTypes__default['default'].func,

  /**
   * @external - material-ui
   */
  onExit: PropTypes__default['default'].func,

  /**
   * @external - material-ui
   */
  onExited: PropTypes__default['default'].func,

  /**
   * @external - material-ui
   */
  onExiting: PropTypes__default['default'].func,

  /**
   * @external - material-ui
   */
  open: PropTypes__default['default'].bool,

  /**
   * state
   */
  state: PropTypes__default['default'].oneOf(['error', 'success', 'warning', 'info']),

  /**
   * comma separated string of query selectors which may need to be overidden for edge cases. Defaults to:
   * '[tabindex="0"], a:not([tabindex="-1"]), area:not([tabindex="-1"]), details:not([tabindex="-1"]), iframe:not([tabindex="-1"]), select:not([tabindex="-1"]), textarea:not([tabindex="-1"]), button:not([tabindex="-1"]), input:not([tabindex="-1"])'
   */
  tabEnabledSelectors: PropTypes__default['default'].string,

  /**
   * Dialog width. This will override any built-in responsive behaviour.
   */
  width: PropTypes__default['default'].oneOfType([PropTypes__default['default'].number, PropTypes__default['default'].string])
};

var Popper = function Popper(_ref) {
  var anchorEl = _ref.anchorEl,
      children = _ref.children,
      className = _ref.className,
      _ref$offsetY = _ref.offsetY,
      offsetY = _ref$offsetY === void 0 ? 0 : _ref$offsetY,
      open = _ref.open,
      _ref$placement = _ref.placement,
      placement = _ref$placement === void 0 ? 'bottom-start' : _ref$placement,
      role = _ref.role;

  var _React$useState = React__default['default'].useState(null),
      _React$useState2 = _slicedToArray(_React$useState, 2),
      popperElement = _React$useState2[0],
      setPopperElement = _React$useState2[1];

  var _usePopper = reactPopper.usePopper(anchorEl, popperElement, {
    placement: placement,
    modifiers: {
      name: 'offset',
      options: {
        offset: [0, offsetY]
      }
    }
  }),
      styles = _usePopper.styles,
      attributes = _usePopper.attributes;

  if (!open) {
    return null;
  }

  return /*#__PURE__*/React__default['default'].createElement(Portal, null, /*#__PURE__*/React__default['default'].createElement("div", _extends({
    className: className,
    ref: setPopperElement,
    role: role,
    style: _objectSpread2({}, styles.popper)
  }, attributes.popper), children));
};

var popperPlacement = {
  bottom: "bottom-start",
  top: "top-start"
};
var usePopperPositioning = function usePopperPositioning(anchorEl, popperRef, isOpen) {
  var _useState = React.useState(undefined),
      _useState2 = _slicedToArray(_useState, 2),
      maxHeight = _useState2[0],
      setMaxHeight = _useState2[1];

  var _useState3 = React.useState(popperPlacement.bottom),
      _useState4 = _slicedToArray(_useState3, 2),
      popperPosition = _useState4[0],
      setPopperPosition = _useState4[1];

  var preferredPopperHeight = React.useRef(-1);
  var availableSpace = React.useRef([0, 0]);

  var _availableSpace$curre = _slicedToArray(availableSpace.current, 2),
      spaceAbove = _availableSpace$curre[0],
      spaceBelow = _availableSpace$curre[1];

  var anchor = anchorEl.current;
  React.useLayoutEffect(function () {
    // Measure the popper on first render only and save its preferred height
    if (isOpen && popperRef.current && preferredPopperHeight.current === -1) {
      preferredPopperHeight.current = popperRef.current.offsetHeight;
    }
  }, [isOpen, popperRef]);
  var measure = React.useCallback(function () {
    var _ownerWindow = ownerWindow(anchor),
        viewportHeight = _ownerWindow.innerHeight;

    var _anchor$getBoundingCl = anchor.getBoundingClientRect(),
        top = _anchor$getBoundingCl.top,
        bottom = _anchor$getBoundingCl.bottom;

    availableSpace.current = [Math.max(0, top), Math.max(0, viewportHeight - bottom)];
  }, [anchor]);
  React.useEffect(function () {
    if (anchor && isOpen) {
      measure();
      var win = ownerWindow(anchor);
      win.addEventListener("resize", measure);
      win.addEventListener("scroll", measure);
      return function () {
        win.removeEventListener("resize", measure);
        win.removeEventListener("scroll", measure);
      };
    }
  }, [anchor, measure, isOpen]);
  React.useLayoutEffect(function () {
    if (isOpen) {
      var newMaxHeight = undefined;
      var position = undefined;

      if (spaceBelow >= preferredPopperHeight.current) {
        newMaxHeight = undefined;
        position = popperPlacement.bottom;
      } else if (spaceAbove > preferredPopperHeight.current) {
        newMaxHeight = undefined;
        position = popperPlacement.top;
      } else if (spaceAbove > spaceBelow) {
        newMaxHeight = spaceAbove;
        position = popperPlacement.top;
      } else {
        newMaxHeight = spaceBelow - 12;
        position = popperPlacement.bottom;
      }

      setMaxHeight(newMaxHeight);
      setPopperPosition(position);
    } else {
      // Reset on popper close
      setMaxHeight(undefined);
      setPopperPosition(undefined);
    }
  }, [isOpen, spaceAbove, spaceBelow]);
  return [popperPosition, maxHeight];
};

var css_248z$f = ".Highlighter-highlight {\n  font-family: uitk-sans;\n  font-weight: 700;\n}\n";
styleInject(css_248z$f);

var Highlighter = function Highlighter(props) {
  var matchPattern = props.matchPattern,
      _props$text = props.text,
      text = _props$text === void 0 ? '' : _props$text;
  var matchRegex = typeof matchPattern === 'string' ? new RegExp("(".concat(escapeRegExp(matchPattern), ")"), 'gi') : matchPattern;
  return /*#__PURE__*/React__default['default'].createElement(React__default['default'].Fragment, null, text.split(matchRegex).map(function (part, index) {
    return part.match(matchRegex) ? /*#__PURE__*/React__default['default'].createElement("strong", {
      className: "Highlighter-highlight",
      key: "".concat(index, "-").concat(part)
    }, part) : part;
  }));
};

var css_248z$g = ".ListItem {\n  color: var(--uitk-select-default-color);\n  background: var(--uitk-select-default-background);\n  text-align: var(--uitk-select-default-text-align);\n  line-height: var(--uitk-line-height);\n  left: 0;\n  right: 0;\n  display: flex;\n  position: relative;\n  box-sizing: border-box;\n  align-items: center;\n}\n\n.ListItem:not(:last-of-type) {\n  border-bottom: 1px solid var(--uitk-select-default-background);\n}\n\n.ListItem:last-child {\n  border-bottom: none;\n}\n\n.ListItem.ListItem-highlighted:not(.ListItem-selected) {\n  background: var(--uitk-select-active-background);\n  cursor: pointer;\n}\n.ListItem-textWrapper {\n  flex: 1;\n  overflow: hidden;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n}\n.ListItem-selected {\n  color: var(--uitk-select-selected-color);\n  background: var(--uitk-select-selected-background);\n}\n.ListItem-disabled {\n  cursor: not-allowed;\n  opacity: 0.7;\n}\n.ListItem-focusVisible:after {\n  top: 2px;\n  left: 2px;\n  right: 2px;\n  bottom: 2px;\n  content: '';\n  position: absolute;\n  outline-style: dotted;\n  outline-width: 2px;\n  outline-offset: 0;\n}\n.ListItem-focusVisible.ListItem-selected:after {\n  outline-color: var(--white);\n}\n.ListItem-touchDensity {\n  padding: 0 var(--uitk-space-touch);\n  font-size: var(--uitk-font-size-70);\n}\n.ListItem-lowDensity {\n  padding: 0 var(--uitk-space-low);\n  font-size: var(--uitk-font-size-60);\n}\n.ListItem-mediumDensity {\n  padding: 0 var(--uitk-space-medium);\n  font-size: var(--uitk-font-size-50);\n}\n.ListItem-highDensity {\n  padding: 0 var(--uitk-space-high);\n  font-size: var(--uitk-font-size-40);\n}\n";
styleInject(css_248z$g);

//   (theme) => {
//     const {
//       selectable: { getSelectable, selectableStates },
//       focusable: { getFocusable },
//       disabled: { getDisabled },
//       palette,
//       spacing,
//       typography,
//     } = theme.toolkit;
//     const defaultSelectableStyle = getSelectable(selectableStates.default);
//     const createDensityStyle = (density) => {
//       const spacingMixin = spacing[density].spacing;
//       const { lineHeight, size: fontSize } = typography;
//       return {
//         lineHeight,
//         fontSize: fontSize[densityToTypeSizePaletteIndex[density]],
//         padding: spacingMixin(0, 1, 0, 1),
//       };
//     };
//     return {
//       root: {
//         borderBottom: `1px solid ${defaultSelectableStyle.background}`,
//         ...defaultSelectableStyle,
//         "&$highlighted:not($selected)": getSelectable(selectableStates.active),
//       },
//       textHighlight: {},
//       highlighted: {},
//       selected: getSelectable(selectableStates.selected),
//       disabled: getDisabled(),
//       focusVisible: {
//         "&:after": {
//           content: '""',
//           position: "absolute",
//           top: 2,
//           right: 2,
//           bottom: 2,
//           left: 2,
//           ...getFocusable(),
//         },
//         "&$selected": {
//           "&:after": {
//             outlineColor: palette.white,
//           },
//         },
//       },
//       touchDensity: createDensityStyle("touch"),
//       lowDensity: createDensityStyle("low"),
//       mediumDensity: createDensityStyle("medium"),
//       highDensity: createDensityStyle("high"),
//     };
//   },
//   { name: "ListItem" }
// );
// just to keep line number parity
//

var ListItemBase = /*#__PURE__*/React.forwardRef(function ListItemBase(props, ref) {
  var className = props.className,
      selected = props.selected,
      highlighted = props.highlighted,
      focusVisible = props.focusVisible,
      disabled = props.disabled,
      children = props.children,
      itemTextHighlightPattern = props.itemTextHighlightPattern,
      densityProp = props.density,
      restProps = _objectWithoutProperties(props, ["className", "selected", "highlighted", "focusVisible", "tooltipText", "disabled", "children", "itemTextHighlightPattern", "density"]);

  var density = useDensity(densityProp); // const [openTooltip, setOpenTooltip] = useState(false);
  // const { Tooltip, enterDelay, leaveDelay, placement } = useTooltipContext();

  var _useRef = React.useRef(typeof children === "string"),
      detectTruncation = _useRef.current;

  var _useOverflowDetection = useOverflowDetection(),
      _useOverflowDetection2 = _slicedToArray(_useOverflowDetection, 2),
      overflowRef = _useOverflowDetection2[0],
      isOverflowed = _useOverflowDetection2[1];

  var setItemRef = useForkRef(overflowRef, ref); // useEffect(() => {
  //   if (detectTruncation) {
  //     const timeout = setTimeout(
  //       () => setOpenTooltip(highlighted),
  //       highlighted ? enterDelay : leaveDelay
  //     );
  //     return () => {
  //       clearTimeout(timeout);
  //     };
  //   }
  // }, [highlighted, enterDelay, leaveDelay, detectTruncation]);

  var renderItem = function renderItem() {
    return /*#__PURE__*/React__default['default'].createElement("div", _extends({
      "aria-label": typeof children === "string" ? children : undefined
    }, restProps, {
      className: classnames__default['default']("ListItem", "ListItem-".concat(density, "Density"), {
        "ListItem-highlighted": highlighted,
        "ListItem-selected": selected,
        "ListItem-focusVisible": focusVisible,
        "ListItem-disabled": disabled
      }, className),
      ref: detectTruncation ? ref : setItemRef
    }), detectTruncation ? /*#__PURE__*/React__default['default'].createElement("span", {
      className: "ListItem-textWrapper",
      ref: overflowRef
    }, itemTextHighlightPattern == null ? children : /*#__PURE__*/React__default['default'].createElement(Highlighter // classes={{ highlight: classes.textHighlight }}
    , {
      matchPattern: itemTextHighlightPattern,
      text: children
    })) : children);
  };

  return isOverflowed ? /*#__PURE__*/React__default['default'].createElement(React__default['default'].Fragment, null, renderItem()) : renderItem();
});
ListItemBase.propTypes = {
  /**
   * The content of the item.
   */
  children: PropTypes__default['default'].node,

  /**
   * The className(s) of the component.
   */
  className: PropTypes__default['default'].string,

  /**
   * The density of a component affects the style of the layout.
   *
   * A high density component uses minimal sizing and spacing to convey the intended UI design.
   * Conversely, a low density component, maximizes the use of space and size to convey the UI Design.
   */
  density: PropTypes__default['default'].oneOf(["touch", "low", "medium", "high"]),

  /**
   * If `true`, the component will be disabled.
   */
  disabled: PropTypes__default['default'].bool,

  /**
   * If `true`, the component will have a focus ring around it.
   */
  focusVisible: PropTypes__default['default'].bool,

  /**
   * If `true`, the component will have the highlighted style.
   */
  highlighted: PropTypes__default['default'].bool,

  /**
   * Used for providing text highlight.
   *
   * It can be a capturing regex or a string for a straightforward string matching.
   */
  itemTextHighlightPattern: PropTypes__default['default'].oneOfType([PropTypes__default['default'].instanceOf(RegExp), PropTypes__default['default'].string]),

  /**
   * If `true`, the component will have the selected style.
   */
  selected: PropTypes__default['default'].bool,

  /**
   * Text displayed in tooltip when item text is truncated.
   *
   * Node that it will detect item text truncation only when its children is a string.
   */
  tooltipText: PropTypes__default['default'].string
};
var ListItemBase$1 = /*#__PURE__*/React.memo(ListItemBase);

var ListItemContext = /*#__PURE__*/React.createContext();
var useListItemContext = function useListItemContext() {
  var context = React.useContext(ListItemContext);

  if (context === undefined) {
    console.warn("useListItemContext must be used inside of a List or ListBase component.");
  }

  return context;
};

var ListStateContext = /*#__PURE__*/React.createContext();
var useListStateContext = function useListStateContext() {
  var context = React.useContext(ListStateContext);

  if (!context) {
    console.warn("useListStateContext must be used inside of a ListStateContext Provider.");
  }

  return context;
};

function useListItem() {
  var props = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  validateProps(props);
  var context = useListItemContext();

  var _useListStateContext = useListStateContext(),
      state = _useListStateContext.state,
      helpers = _useListStateContext.helpers;

  var setHighlightedIndex = helpers.setHighlightedIndex,
      setFocusVisible = helpers.setFocusVisible,
      handleSelect = helpers.handleSelect;
  var focusVisible = state.focusVisible,
      highlightedIndex = state.highlightedIndex,
      selectedItem = state.selectedItem,
      isDisabled = state.isDisabled,
      isMultiSelect = state.isMultiSelect;

  var index = props.index,
      item = props.item,
      onClick = props.onClick,
      onMouseMove = props.onMouseMove,
      _props$density = props.density,
      density = _props$density === void 0 ? context.density : _props$density,
      _props$id = props.id,
      id = _props$id === void 0 ? context.getItemId(index) : _props$id,
      _props$itemHeight = props.itemHeight,
      itemHeight = _props$itemHeight === void 0 ? context.getItemHeight(index) : _props$itemHeight,
      _props$itemToString = props.itemToString,
      itemToString = _props$itemToString === void 0 ? context.itemToString : _props$itemToString,
      _props$disabled = props.disabled,
      disabled = _props$disabled === void 0 ? item.disabled || isDisabled : _props$disabled,
      ariaPropsProp = props.ariaProps,
      styleProp = props.style,
      restProps = _objectWithoutProperties(props, ["index", "item", "onClick", "onMouseMove", "density", "id", "itemHeight", "itemToString", "disabled", "ariaProps", "style"]);

  var style = React.useMemo(function () {
    return _objectSpread2({
      height: itemHeight
    }, styleProp);
  }, // eslint-disable-next-line react-hooks/exhaustive-deps
  [itemHeight, JSON.stringify(styleProp)]);
  var highlighted = index === highlightedIndex;
  var selected = isMultiSelect ? selectedItem.indexOf(item) !== -1 : item === selectedItem;
  var handleClick = React.useCallback(function (event) {
    handleSelect(event, index, item);

    if (onClick) {
      onClick(event);
    }
  }, [handleSelect, index, item, onClick]);
  var handleMouseMove = React.useCallback(function (event) {
    setHighlightedIndex(index);
    setFocusVisible(false);

    if (onMouseMove) {
      onMouseMove(event);
    }
  }, [index, setFocusVisible, setHighlightedIndex, onMouseMove]);
  var disableMouseDown = React.useCallback(function (event) {
    event.preventDefault();
  }, []);
  var eventHandlers = {
    onClick: handleClick,
    onMouseMove: handleMouseMove
  };

  var ariaProps = _objectSpread2(_objectSpread2(_objectSpread2({
    role: "option"
  }, selected && {
    "aria-selected": true
  }), disabled && {
    "aria-disabled": true
  }), ariaPropsProp);

  return {
    item: item,
    itemToString: itemToString,
    itemProps: _objectSpread2(_objectSpread2(_objectSpread2({
      "data-option-index": index,
      id: id,
      style: style,
      density: density,
      disabled: disabled,
      selected: selected,
      highlighted: highlighted,
      focusVisible: focusVisible && highlighted,
      tooltipText: itemToString(item)
    }, ariaProps), restProps), disabled ? {
      onMouseDown: disableMouseDown
    } : eventHandlers)
  };
}
var useVirtualizedListItem = function useVirtualizedListItem() {
  var props = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var index = props.index,
      data = props.data,
      _props$style = props.style,
      style = _props$style === void 0 ? {} : _props$style; // Filter out inline width added by `react-window` so that it can only be defined using css.

  var itemHeight = style.height,
      restStyle = _objectWithoutProperties(style, ["width", "height"]);

  return useListItem({
    index: index,
    itemHeight: itemHeight,
    style: restStyle,
    item: data[index],
    ariaProps: {
      "aria-posinset": index + 1,
      "aria-setsize": data.length
    }
  });
};

var validateProps = function validateProps(props) {
  var index = props.index,
      item = props.item;
  /* eslint-disable react-hooks/rules-of-hooks */

  React.useEffect(function () {
    if (item === undefined) {
      console.warn("useListItem needs `item`.");
    }

    if (index === undefined) {
      console.warn("useListItem needs to know item's index.");
    }
  }, [index, item]);
  /* eslint-enable react-hooks/rules-of-hooks */
};

function useListItemHeight() {
  var density = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "medium";

  var _useTheme = useTheme(),
      toolkit = _useTheme.toolkit;

  return toolkit.size.getSize({
    variant: "stackable",
    density: density
  }).height;
}

function useListAutoSizer(props) {
  var responsive = props.responsive,
      width = props.width,
      height = props.height;

  var _useState = React.useState({
    width: width,
    height: height
  }),
      _useState2 = _slicedToArray(_useState, 2),
      size = _useState2[0],
      setSize = _useState2[1];

  var ref = React.useRef();
  var handleResize = React.useCallback(function handleResize(contentRect) {
    setSize({
      width: contentRect.width,
      height: contentRect.height
    });
  }, []);
  React.useLayoutEffect(function () {
    setSize({
      width: width,
      height: height
    });
  }, [width, height]);
  React.useLayoutEffect(function () {
    if (responsive) {
      handleResize(ref.current.getBoundingClientRect());
      var observer = new ResizeObserver(function (_ref) {
        var _ref2 = _slicedToArray(_ref, 1),
            contentRect = _ref2[0].contentRect;

        return handleResize(contentRect);
      });
      observer.observe(ref.current);
      return function () {
        observer.disconnect();
      };
    }
  }, [handleResize, responsive]);
  return [ref, size];
}

function scrollIntoView(item, list) {
  if (!item) {
    return;
  }

  var actions = computeScrollIntoView__default['default'](item, {
    boundary: list,
    block: "nearest",
    scrollMode: "if-needed"
  });
  actions.forEach(function (_ref) {
    var el = _ref.el,
        top = _ref.top,
        left = _ref.left;
    el.scrollTop = top;
    el.scrollLeft = left;
  });
}

var calcPreferredListHeight = function calcPreferredListHeight() {
  var props = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var borderless = props.borderless,
      _props$displayedItemC = props.displayedItemCount,
      displayedItemCount = _props$displayedItemC === void 0 ? 0 : _props$displayedItemC,
      _props$itemCount = props.itemCount,
      itemCount = _props$itemCount === void 0 ? 0 : _props$itemCount,
      _props$itemHeight = props.itemHeight,
      itemHeight = _props$itemHeight === void 0 ? 0 : _props$itemHeight,
      getItemHeight = props.getItemHeight;
  var preferredHeight = borderless ? 0 : 2; // if there is no item we render with the preferred count

  var preferredItemCount = itemCount === 0 ? displayedItemCount : Math.min(displayedItemCount, itemCount);

  if (typeof getItemHeight === "function") {
    preferredHeight += Array.from({
      length: preferredItemCount
    }).reduce(function (total, _, index) {
      return total + Number(getItemHeight(index));
    }, 0);
  } else {
    preferredHeight += preferredItemCount * Number(itemHeight);
  } // list height will be undefined if the item height can not be
  // converted to a number, for example rem or a percentage string


  return isNaN(preferredHeight) ? undefined : preferredHeight;
};

var isPlainObject = function isPlainObject(obj) {
  return Object.prototype.toString.call(obj) === "[object Object]";
};

function itemToString(item) {
  if (!isPlainObject(item)) {
    return String(item);
  }

  if (Object.prototype.hasOwnProperty.call(item, "label")) {
    return String(item.label);
  }

  console.warn(["itemToString: you've likely forgotten to set the label prop on the item object.", "You can also provide your own `itemToString` implementation."].join("\n"));
  return "";
}

var css_248z$h = ".List {\n  box-sizing: border-box;\n  overflow-y: auto;\n}\n.List:focus {\n  outline: none;\n}\n\n.List-wrapper:not(.List-borderless) {\n  /* container1 */\n  background: var(--uitk-container1-background);\n  border-color: var(--uitk-container1-border-color);\n  border-style: var(--uitk-container1-border-style);\n  border-width: var(--uitk-container1-border-width);\n  border-radius: var(--uitk-container1-border-radius);\n\n  box-sizing: border-box;\n}\n.List-wrapper {\n  position: relative;\n}\n.List-borderless {\n  border: none;\n}\n.List-disabled {\n  cursor: not-allowed;\n  opacity: 0.7;\n}\n";
styleInject(css_248z$h);

//   (theme) => {
//     const {
//       container: { getContainer },
//       disabled: { getDisabled },
//     } = theme.toolkit;
//     return {
//       root: {
//         boxSizing: "border-box",
//         overflowY: "auto",
//         "&:not($borderless)": getContainer(),
//         "&:focus": {
//           outline: "none",
//         },
//       },
//       wrapper: {
//         position: "relative",
//       },
//       borderless: {
//         border: "none",
//       },
//       disabled: getDisabled(),
//       touchDensity: {},
//       lowDensity: {},
//       mediumDensity: {},
//       highDensity: {},
//     };
//   },
//   { name: "List" }
// );

var ListboxContext = /*#__PURE__*/React.createContext();
var DefaultItem = /*#__PURE__*/React.memo(function DefaultItem(props) {
  var _useListItem = useListItem(props),
      item = _useListItem.item,
      itemToString = _useListItem.itemToString,
      itemProps = _useListItem.itemProps;

  return /*#__PURE__*/React__default['default'].createElement(ListItemBase$1, itemProps, itemToString(item));
}, reactWindow.areEqual);
var DefaultVirtualizedItem = /*#__PURE__*/React.memo(function DefaultVirtualizedItem(props) {
  var _useVirtualizedListIt = useVirtualizedListItem(props),
      item = _useVirtualizedListIt.item,
      itemToString = _useVirtualizedListIt.itemToString,
      itemProps = _useVirtualizedListIt.itemProps;

  return /*#__PURE__*/React__default['default'].createElement(ListItemBase$1, itemProps, itemToString(item));
}, reactWindow.areEqual);
/**
 * Listbox is the container for all list items. It is used as `outerElement` for
 * `react-window`.
 *
 * forwardRef gives `react-window` a way to attach a ref to listen to "scroll" events.
 * And `onScroll` is added by `react-window` so we pass it on.
 */

var Listbox = /*#__PURE__*/React.forwardRef(function Listbox(props, ref) {
  var style = props.style,
      onScroll = props.onScroll,
      children = props.children;

  var _useContext = React.useContext(ListboxContext),
      className = _useContext.className,
      borderless = _useContext.borderless,
      density = _useContext.density,
      disabled = _useContext.disabled,
      disableFocus = _useContext.disableFocus,
      listRef = _useContext.listRef,
      styleProp = _useContext.style,
      onScrollProp = _useContext.onScroll,
      restListProps = _objectWithoutProperties(_useContext, ["className", "borderless", "density", "disabled", "disableFocus", "listRef", "style", "onScroll"]);

  var setListRef = useForkRef(ref, listRef);

  var handleScroll = function handleScroll(event) {
    if (onScroll) {
      onScroll(event);
    }

    if (onScrollProp) {
      onScrollProp(event);
    }
  };

  return /*#__PURE__*/React__default['default'].createElement("div", _extends({
    className: classnames__default['default']("List", "".concat(density, "Density"), {
      borderless: borderless,
      disabled: disabled
    }, className),
    onScroll: handleScroll,
    ref: setListRef,
    style: _objectSpread2(_objectSpread2({}, style), styleProp),
    tabIndex: disabled || disableFocus ? null : 0
  }, restListProps), children);
});
Listbox.propTypes = {
  children: PropTypes__default['default'].node.isRequired,
  onScroll: PropTypes__default['default'].func,
  style: PropTypes__default['default'].objectOf(PropTypes__default['default'].oneOfType([PropTypes__default['default'].string, PropTypes__default['default'].number]))
};
var ListBase = /*#__PURE__*/React.forwardRef(function ListBase(props, ref) {
  var density = useDensity(props.density);

  var _useListStateContext = useListStateContext(),
      state = _useListStateContext.state; // Getting list id in the following order:
  // 1. Use the id prop if it's defined, otherwise..
  // 2. Use the id from list context if it's defined, or finally...
  // 3. Generate a random id.


  var generatedId = useId(props.id);
  var defaultId = getWithDefault(state.id, generatedId);
  var defaultItemHeight = useListItemHeight(density);
  var hasIndexer = typeof props.getItemAtIndex === "function";
  var hasVariableHeight = typeof props.getItemHeight === "function";

  var _props$id = props.id,
      id = _props$id === void 0 ? defaultId : _props$id,
      _props$source = props.source,
      source = _props$source === void 0 ? [] : _props$source,
      borderless = props.borderless,
      children = props.children,
      itemTextHighlightPattern = props.itemTextHighlightPattern,
      _props$itemCount = props.itemCount,
      itemCount = _props$itemCount === void 0 ? source.length : _props$itemCount,
      _props$itemToString = props.itemToString,
      itemToString$1 = _props$itemToString === void 0 ? itemToString : _props$itemToString,
      _props$itemHeight = props.itemHeight,
      itemHeight = _props$itemHeight === void 0 ? defaultItemHeight : _props$itemHeight,
      _props$getItemHeight = props.getItemHeight,
      getItemHeight = _props$getItemHeight === void 0 ? function () {
    return itemHeight;
  } : _props$getItemHeight,
      _props$getItemId = props.getItemId,
      getItemId = _props$getItemId === void 0 ? function (index) {
    return "".concat(id, "-item-").concat(index);
  } : _props$getItemId,
      _props$getItemIndex = props.getItemIndex,
      getItemIndex = _props$getItemIndex === void 0 ? function (item) {
    return source.indexOf(item);
  } : _props$getItemIndex,
      getItemAtIndex = props.getItemAtIndex,
      _props$overscanCount = props.overscanCount,
      overscanCount = _props$overscanCount === void 0 ? 10 : _props$overscanCount,
      _props$displayedItemC = props.displayedItemCount,
      displayedItemCount = _props$displayedItemC === void 0 ? 10 : _props$displayedItemC,
      virtualized = props.virtualized,
      width = props.width,
      height = props.height,
      maxWidth = props.maxWidth,
      maxHeight = props.maxHeight,
      minWidth = props.minWidth,
      minHeight = props.minHeight,
      ListPlaceholder = props.ListPlaceholder,
      _props$ListItem = props.ListItem,
      ListItem = _props$ListItem === void 0 ? virtualized ? DefaultVirtualizedItem : DefaultItem : _props$ListItem,
      listRefProp = props.listRef,
      restProps = _objectWithoutProperties(props, ["id", "source", "borderless", "children", "itemTextHighlightPattern", "itemCount", "itemToString", "itemHeight", "getItemHeight", "getItemId", "getItemIndex", "getItemAtIndex", "overscanCount", "displayedItemCount", "virtualized", "width", "height", "maxWidth", "maxHeight", "minWidth", "minHeight", "ListPlaceholder", "ListItem", "listRef"]);

  var highlightedIndex = state.highlightedIndex;
  var preferredHeight = getWithDefault(height, calcPreferredListHeight({
    borderless: borderless,
    displayedItemCount: displayedItemCount,
    itemCount: itemCount,
    itemHeight: itemHeight,
    getItemHeight: getItemHeight
  }));

  var _useListAutoSizer = useListAutoSizer({
    responsive: width === undefined || height === undefined,
    height: preferredHeight,
    width: width
  }),
      _useListAutoSizer2 = _slicedToArray(_useListAutoSizer, 2),
      containerRef = _useListAutoSizer2[0],
      autoSize = _useListAutoSizer2[1];
  /**
   * This is used to access `react-window` API
   * @see https://react-window.now.sh/#/api/FixedSizeList (under `Methods`)
   */


  var virtualizedListRef = React.useRef();
  var listRef = React.useRef();
  var setListRef = useForkRef(listRef, listRefProp);
  var setContainerRef = useForkRef(ref, containerRef);

  var scrollToIndex = function scrollToIndex(itemIndex) {
    scrollIntoView(listRef.current.querySelector("[data-option-index=\"".concat(itemIndex, "\"]")), listRef);
  };

  var scrollHandles = React.useMemo(function () {
    return {
      scrollToIndex: scrollToIndex,
      scrollToItem: function scrollToItem(item) {
        scrollToIndex(getItemIndex(item));
      },
      scrollTo: function scrollTo(scrollOffset) {
        listRef.current.scrollTop = scrollOffset;
      }
    };
  }, [getItemIndex]);
  var virtualizedScrollHandles = React.useMemo(function () {
    return {
      scrollToIndex: function scrollToIndex(itemIndex) {
        virtualizedListRef.current.scrollToItem(itemIndex);
      },
      scrollToItem: function scrollToItem(item) {
        virtualizedListRef.current.scrollToItem(getItemIndex(item));
      },
      scrollTo: function scrollTo(scrollOffset) {
        virtualizedListRef.current.scrollTo(scrollOffset);
      }
    };
  }, [getItemIndex]);
  React.useImperativeHandle(ref, function () {
    if (virtualized && virtualizedListRef.current) {
      return virtualizedScrollHandles;
    } else if (listRef.current) {
      return scrollHandles;
    }
  }, [virtualized, scrollHandles, virtualizedScrollHandles]);
  React.useLayoutEffect(function () {
    if (highlightedIndex == null) {
      return;
    }

    if (virtualized && virtualizedListRef.current) {
      virtualizedListRef.current.scrollToItem(highlightedIndex);
    } else if (listRef.current) {
      scrollToIndex(highlightedIndex);
    }
  }, [highlightedIndex, virtualized]);

  var renderList = function renderList() {
    if (React__default['default'].Children.count(children)) {
      return /*#__PURE__*/React__default['default'].createElement(Listbox, {
        style: autoSize
      }, /*#__PURE__*/React__default['default'].createElement(ListItemContext.Provider, {
        value: {
          density: density,
          getItemId: getItemId,
          getItemHeight: getItemHeight,
          itemToString: itemToString$1,
          itemTextHighlightPattern: itemTextHighlightPattern
        }
      }, children));
    }

    if (virtualized) {
      var VirtualizedList = hasVariableHeight ? reactWindow.VariableSizeList : reactWindow.FixedSizeList;
      return /*#__PURE__*/React__default['default'].createElement(ListItemContext.Provider, {
        value: {
          density: density,
          getItemId: getItemId,
          itemToString: itemToString$1,
          itemTextHighlightPattern: itemTextHighlightPattern
        }
      }, /*#__PURE__*/React__default['default'].createElement(VirtualizedList, {
        height: autoSize.height,
        itemCount: itemCount,
        itemData: source,
        itemSize: hasVariableHeight ? getItemHeight : itemHeight,
        outerElementType: Listbox,
        overscanCount: overscanCount,
        ref: virtualizedListRef,
        width: autoSize.width
      }, ListItem));
    }

    return /*#__PURE__*/React__default['default'].createElement(Listbox, {
      style: autoSize
    }, /*#__PURE__*/React__default['default'].createElement(ListItemContext.Provider, {
      value: {
        density: density,
        getItemId: getItemId,
        getItemHeight: getItemHeight,
        itemToString: itemToString$1,
        itemTextHighlightPattern: itemTextHighlightPattern
      }
    }, (hasIndexer ? Array.from({
      length: itemCount
    }) : source).map(function (item, index) {
      return /*#__PURE__*/React__default['default'].createElement(ListItem, {
        index: index,
        item: hasIndexer ? getItemAtIndex(index) : item,
        key: getItemId(index)
      });
    })));
  }; // TODO It's weird that List itself isn't the root element, ListWrapper is
  // THat means if client passes style, with margin, for example, it will break;


  return /*#__PURE__*/React__default['default'].createElement("div", {
    className: "List-wrapper",
    ref: setContainerRef,
    style: {
      minWidth: minWidth,
      minHeight: minHeight,
      width: getWithDefault(width, "100%"),
      height: getWithDefault(height, "100%"),
      maxWidth: getWithDefault(maxWidth, width),
      maxHeight: getWithDefault(maxHeight, preferredHeight)
    }
  }, itemCount === 0 && ListPlaceholder !== undefined ? /*#__PURE__*/React__default['default'].createElement(ListPlaceholder, {
    style: autoSize
  }) : /*#__PURE__*/React__default['default'].createElement(ListboxContext.Provider, {
    value: _objectSpread2(_objectSpread2({}, restProps), {}, {
      listRef: setListRef,
      id: id,
      density: density,
      borderless: borderless
    })
  }, renderList()));
});
ListBase.propTypes = {
  /**
   * The component used for item instead of the default.
   */
  ListItem: PropTypes__default['default'].func,

  /**
   * The component used when there are no items.
   */
  ListPlaceholder: PropTypes__default['default'].func,

  /**
   * If `true`, the component will have no border.
   */
  borderless: PropTypes__default['default'].bool,

  /**
   * Item nodes if the component is used declaratively.
   */
  children: PropTypes__default['default'].node,

  /**
   * The className(s) of the component.
   */
  className: PropTypes__default['default'].string,

  /**
   * The density of a component affects the style of the layout.
   *
   * A high density component uses minimal sizing and spacing to convey the intended UI design.
   * Conversely, a low density component, maximizes the use of space and size to convey the UI Design.
   */
  density: PropTypes__default['default'].oneOf(["touch", "low", "medium", "high"]),

  /**
   * If `true`, the component will not receive focus.
   *
   * Useful when list is used with other components to form a tightly coupled atomic component where
   * other components should receive focus instead. For instance, when used with an input to form a
   * combo box the list should not be focusable, the input should receive focus instead.
   */
  disableFocus: PropTypes__default['default'].bool,

  /**
   * If `true`, the component will be disabled.
   */
  disabled: PropTypes__default['default'].bool,

  /**
   * The number of items displayed in the visible area.
   *
   * Note that this determines the max height of the list if the list height is not set to 100%.
   *
   * @default 10
   */
  displayedItemCount: PropTypes__default['default'].number,

  /**
   * The indexer function used when there is no source. It should return a number.
   *
   * @param {number} index The item index.
   */
  getItemAtIndex: PropTypes__default['default'].func,

  /**
   * Used for providing customized item height. It should return a number or a string if item height
   * is in percentage. When used with `virtualized` prop a variable-height list will be rendered instead
   * of a fixed-height one.
   *
   * @param {number} index The item index.
   */
  getItemHeight: PropTypes__default['default'].func,

  /**
   * Used for providing customized item ids.
   *
   * @param {number} index The item index.
   */
  getItemId: PropTypes__default['default'].func,

  /**
   * The function for getting item's index.
   *
   * @param {object} item The item.
   */
  getItemIndex: PropTypes__default['default'].func,

  /**
   * Height of the component.
   */
  height: PropTypes__default['default'].oneOfType([PropTypes__default['default'].number, PropTypes__default['default'].string]),

  /**
   * Id of the component. If omitted a randomly generated id will be used.
   */
  id: PropTypes__default['default'].string,

  /**
   * The total number of items.
   *
   * Used for keyboard navigation (when `End` key is pressed) and when the list is virtualized.
   *
   * @default source.length
   */
  itemCount: PropTypes__default['default'].number,

  /**
   * Height of an item. I can be a number or a string if item height is in percentage. If omitted
   * default height values from Toolkit theme will be used.
   *
   * Note that when using a percentage value, the list must have a height.
   */
  itemHeight: PropTypes__default['default'].oneOfType([PropTypes__default['default'].number, PropTypes__default['default'].string]),

  /**
   * Used for providing text highlight.
   *
   * It can be a capturing regex or a string for a straightforward string matching.
   */
  itemTextHighlightPattern: PropTypes__default['default'].oneOfType([PropTypes__default['default'].instanceOf(RegExp), PropTypes__default['default'].string]),

  /**
   * Item `toString` function when list is not used declaratively and its items are objects
   * instead of strings. The string value is also used in tooltip when item text is truncated.
   *
   * If omitted, component will look for a `label` property on the data object.
   *
   * @param {object} item The item.
   */
  itemToString: PropTypes__default['default'].func,

  /**
   * Used for accessing the scrollable list node inside of the component. If you want to access
   * the outer wrapper node use `ref` instead.
   */
  listRef: refType,

  /**
   * Maximum list height.
   */
  maxHeight: PropTypes__default['default'].oneOfType([PropTypes__default['default'].number, PropTypes__default['default'].string]),

  /**
   * Maximum list width.
   */
  maxWidth: PropTypes__default['default'].oneOfType([PropTypes__default['default'].number, PropTypes__default['default'].string]),

  /**
   * Minimum list height.
   */
  minHeight: PropTypes__default['default'].oneOfType([PropTypes__default['default'].number, PropTypes__default['default'].string]),

  /**
   * Minimum list width.
   */
  minWidth: PropTypes__default['default'].oneOfType([PropTypes__default['default'].number, PropTypes__default['default'].string]),

  /**
   * @external - react-window
   *
   * The number of items to render outside of the visible area.
   *
   * @default 10
   */
  overscanCount: PropTypes__default['default'].number,

  /**
   * If `true`, the component will remember the last keyboard-interacted position
   * and highlight it when list is focused again.
   */
  restoreLastFocus: PropTypes__default['default'].bool,

  /**
   * Data source used. It should be an array of objects or strings.
   */
  source: PropTypes__default['default'].arrayOf(PropTypes__default['default'].any),

  /**
   * @external - react-window
   *
   * If `true`, list will be virtualized.
   * @see https://github.com/bvaughn/react-window
   */
  virtualized: PropTypes__default['default'].bool,

  /**
   * Width of the component.
   */
  width: PropTypes__default['default'].oneOfType([PropTypes__default['default'].number, PropTypes__default['default'].string])
};

function useList() {
  var _keyDownHandlers;

  var props = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  validateProps$1(props);
  var generatedId = useId(props.id);

  var _props$id = props.id,
      id = _props$id === void 0 ? generatedId : _props$id,
      _props$source = props.source,
      source = _props$source === void 0 ? [] : _props$source,
      _props$itemCount = props.itemCount,
      itemCount = _props$itemCount === void 0 ? source.length : _props$itemCount,
      _props$getItemId = props.getItemId,
      getItemId = _props$getItemId === void 0 ? function (index) {
    return "".concat(id, "-item-").concat(index);
  } : _props$getItemId,
      getItemAtIndexProp = props.getItemAtIndex,
      getItemIndexProp = props.getItemIndex,
      _props$displayedItemC = props.displayedItemCount,
      displayedItemCount = _props$displayedItemC === void 0 ? 10 : _props$displayedItemC,
      initialSelectedItem = props.initialSelectedItem,
      selectionVariant = props.selectionVariant,
      disabled = props.disabled,
      onBlur = props.onBlur,
      onChange = props.onChange,
      onFocus = props.onFocus,
      onKeyDown = props.onKeyDown,
      onMouseLeave = props.onMouseLeave,
      onSelect = props.onSelect,
      restoreLastFocus = props.restoreLastFocus,
      highlightedIndexProp = props.highlightedIndex,
      selectedItemProp = props.selectedItem,
      tabToSelect = props.tabToSelect,
      restProps = _objectWithoutProperties(props, ["id", "source", "itemCount", "getItemId", "getItemAtIndex", "getItemIndex", "displayedItemCount", "initialSelectedItem", "selectionVariant", "disabled", "onBlur", "onChange", "onFocus", "onKeyDown", "onMouseLeave", "onSelect", "restoreLastFocus", "highlightedIndex", "selectedItem", "tabToSelect"]);

  var _useIsFocusVisible = useIsFocusVisible(),
      isFocusVisible = _useIsFocusVisible.isFocusVisible,
      onBlurVisible = _useIsFocusVisible.onBlurVisible,
      focusVisibleRef = _useIsFocusVisible.ref;

  var _useRef = React.useRef(selectionVariant === "deselectable"),
      isDeselectable = _useRef.current;

  var _useRef2 = React.useRef(selectionVariant === "multiple" || Array.isArray(initialSelectedItem) || Array.isArray(selectedItemProp)),
      isMultiSelect = _useRef2.current;

  var getItemIndex = React.useCallback(function (item) {
    return source.indexOf(item);
  }, [source]);
  var getItemAtIndex = React.useCallback(function (index) {
    return source[index];
  }, [source]);
  var indexComparator = React.useCallback(function (a, b) {
    return getItemIndex(a) - getItemIndex(b);
  }, [getItemIndex]); // Only use getItemIndex and getItemAtIndex if both are defined; otherwise keep the defaults

  if (typeof getItemIndexProp === "function" && typeof getItemAtIndexProp === "function") {
    getItemIndex = getItemIndexProp;
    getItemAtIndex = getItemAtIndexProp;
  }

  var rootRef = React.useRef();

  var _useState = React.useState(false),
      _useState2 = _slicedToArray(_useState, 2),
      focusVisible = _useState2[0],
      setFocusVisible = _useState2[1];

  var _useState3 = React.useState(-1),
      _useState4 = _slicedToArray(_useState3, 2),
      lastFocusedIndex = _useState4[0],
      setLastFocusedIndex = _useState4[1];

  var _useControlled = useControlled({
    controlled: selectedItemProp,
    "default": getWithDefault(initialSelectedItem, isMultiSelect ? [] : null),
    name: "useList",
    state: "selectedItem"
  }),
      _useControlled2 = _slicedToArray(_useControlled, 2),
      selectedItem = _useControlled2[0],
      setSelectedItem = _useControlled2[1];

  var _useControlled3 = useControlled({
    controlled: highlightedIndexProp,
    name: "useList",
    state: "highlightedIndex"
  }),
      _useControlled4 = _slicedToArray(_useControlled3, 2),
      highlightedIndex = _useControlled4[0],
      setHighlightedIndex = _useControlled4[1];

  var handleSingleSelect = React.useCallback(function (event, index, item) {
    var isSelected = item === selectedItem;
    var nextItem;

    if (isSelected && !isDeselectable) {
      return;
    }

    if (!isSelected) {
      nextItem = item;
      setHighlightedIndex(index);
    } else {
      nextItem = null;
    }

    setSelectedItem(nextItem);

    if (onChange) {
      onChange(event, nextItem);
    }
  }, [isDeselectable, onChange, selectedItem, setHighlightedIndex, setSelectedItem]);
  var handleMultiSelect = React.useCallback(function (event, index, item) {
    var isSelected = selectedItem.indexOf(item) !== -1;
    var nextItems = selectedItem;

    if (!isSelected) {
      nextItems = nextItems.concat(item).sort(indexComparator);
      setHighlightedIndex(index);
    } else {
      nextItems = nextItems.filter(function (selected) {
        return selected !== item;
      });
    }

    setSelectedItem(nextItems);

    if (onChange) {
      onChange(event, nextItems);
    }
  }, [indexComparator, onChange, selectedItem, setHighlightedIndex, setSelectedItem]);
  var handleSelect = React.useCallback(function (event, index, item) {
    if (item == null || item.disabled) {
      return;
    }

    if (onSelect) {
      onSelect(event, item);
    }

    if (isMultiSelect) {
      handleMultiSelect(event, index, item);
    } else {
      handleSingleSelect(event, index, item);
    }
  }, [handleMultiSelect, handleSingleSelect, isMultiSelect, onSelect]);

  var saveFocusedIndex = function saveFocusedIndex(index) {
    setLastFocusedIndex(index);
    return index;
  };

  var keyDownHandlers = (_keyDownHandlers = {
    ArrowUp: function ArrowUp(event) {
      event.preventDefault();
      setHighlightedIndex(function (prevHighlightedIndex) {
        return saveFocusedIndex(Math.max(0, prevHighlightedIndex - 1));
      });
    },
    ArrowDown: function ArrowDown(event) {
      event.preventDefault();
      setHighlightedIndex(function (prevHighlightedIndex) {
        return saveFocusedIndex(Math.min(itemCount - 1, prevHighlightedIndex + 1));
      });
    },
    PageUp: function PageUp(event) {
      event.preventDefault();
      setHighlightedIndex(function (prevHighlightedIndex) {
        return saveFocusedIndex(Math.max(0, prevHighlightedIndex - displayedItemCount));
      });
    },
    PageDown: function PageDown(event) {
      event.preventDefault();
      setHighlightedIndex(function (prevHighlightedIndex) {
        return saveFocusedIndex(Math.min(itemCount - 1, prevHighlightedIndex + displayedItemCount));
      });
    },
    Home: function Home(event) {
      event.preventDefault();
      setHighlightedIndex(saveFocusedIndex(0));
    },
    End: function End(event) {
      event.preventDefault();
      setHighlightedIndex(saveFocusedIndex(itemCount - 1));
    },
    Enter: function Enter(event) {
      event.preventDefault();
      handleSelect(event, highlightedIndex, getItemAtIndex(highlightedIndex));
    }
  }, _defineProperty(_keyDownHandlers, " ", function _(event) {
    event.preventDefault();
    handleSelect(event, highlightedIndex, getItemAtIndex(highlightedIndex));
  }), _defineProperty(_keyDownHandlers, "Tab", function Tab(event) {
    if (tabToSelect) {
      handleSelect(event, highlightedIndex, getItemAtIndex(highlightedIndex));
    } else {
      setHighlightedIndex(undefined);
    }
  }), _keyDownHandlers);

  var handleKeyDown = function handleKeyDown(event) {
    if (isFocusVisible(event)) {
      setFocusVisible(true);
    }

    var handler = keyDownHandlers[event.key];

    if (handler) {
      handler(event);
    }

    if (onKeyDown) {
      onKeyDown(event);
    }
  };

  var handleFocus = function handleFocus(event) {
    if (isFocusVisible(event)) {
      setFocusVisible(true);
    } // Work out the index to highlight


    if (highlightedIndex === undefined) {
      var firstSelectedItem = isMultiSelect ? selectedItem[0] : selectedItem;
      setHighlightedIndex(Math.max(restoreLastFocus ? lastFocusedIndex : getItemIndex(firstSelectedItem), 0));
    }

    if (onFocus) {
      onFocus(event);
    }
  };

  var handleBlur = function handleBlur(event) {
    setHighlightedIndex(undefined);
    setFocusVisible(false);
    onBlurVisible();

    if (onBlur) {
      onBlur(event);
    }
  };

  var handleMouseLeave = function handleMouseLeave(event) {
    if (focusVisible) {
      // Get the root node of the component if we have access to it otherwise default to current document
      var rootNode = (rootRef.current || ownerDocument(event.currentTarget)).getRootNode();
      var listNode = rootNode.getElementById(id); // Safety check as `mouseleave` could have been accidentally triggered by an opening tooltip
      // when you use keyboard to navigate, hence the focusVisible check earlier

      if (listNode.contains(event.target)) {
        setHighlightedIndex(undefined);
      }
    } else {
      setHighlightedIndex(undefined);
    }

    if (onMouseLeave) {
      onMouseLeave(event);
    }
  };

  var eventHandlers = {
    onFocus: handleFocus,
    onBlur: handleBlur,
    onKeyDown: handleKeyDown,
    onMouseLeave: handleMouseLeave
  };
  var ariaProps = {
    role: "listbox",
    "aria-activedescendant": highlightedIndex >= 0 ? getItemId(highlightedIndex) : null
  };

  if (isMultiSelect) {
    ariaProps["aria-multiselectable"] = true;
  }

  return {
    focusableRef: useForkRef(rootRef, focusVisibleRef),
    state: {
      id: id,
      focusVisible: focusVisible,
      selectedItem: selectedItem,
      highlightedIndex: highlightedIndex,
      isMultiSelect: isMultiSelect,
      isDisabled: disabled
    },
    helpers: {
      setFocusVisible: setFocusVisible,
      setSelectedItem: setSelectedItem,
      setHighlightedIndex: setHighlightedIndex,
      keyDownHandlers: keyDownHandlers,
      isFocusVisible: isFocusVisible,
      onBlurVisible: onBlurVisible,
      handleSelect: handleSelect
    },
    listProps: _objectSpread2(_objectSpread2(_objectSpread2({
      id: id,
      source: source,
      itemCount: itemCount,
      displayedItemCount: displayedItemCount,
      getItemAtIndex: getItemAtIndex,
      getItemIndex: getItemIndex,
      getItemId: getItemId,
      disabled: disabled
    }, ariaProps), restProps), disabled ? {} : eventHandlers)
  };
}

var validateProps$1 = function validateProps(props) {
  if (process.env.NODE_ENV !== "production") {
    var source = props.source,
        itemCount = props.itemCount,
        getItemIndex = props.getItemIndex,
        getItemAtIndex = props.getItemAtIndex;
    var hasIndexer = typeof getItemIndex === "function" && typeof getItemAtIndex === "function";
    var hasNoIndexer = getItemIndex === undefined && getItemAtIndex === undefined;
    /* eslint-disable react-hooks/rules-of-hooks */

    React.useEffect(function () {
      warning__default['default'](source == null || Array.isArray(source), "`source` for useList must be an array.");
    }, [source]);
    React.useEffect(function () {
      warning__default['default'](hasNoIndexer || hasIndexer, "useList needs to have both `getItemIndex` and `getItemAtIndex`.");
      warning__default['default'](hasNoIndexer || itemCount !== undefined, "useList needs to have `itemCount` if an indexer is used.");
    }, [hasIndexer, hasNoIndexer, itemCount]);
    /* eslint-enable react-hooks/rules-of-hooks */
  }
};

var TYPE_SELECT_TIMEOUT = 1500;
function useTypeSelect(options) {
  var getItemAtIndex = options.getItemAtIndex,
      highlightedIndex = options.highlightedIndex,
      itemCount = options.itemCount,
      _options$itemToString = options.itemToString,
      itemToString$1 = _options$itemToString === void 0 ? itemToString : _options$itemToString,
      onTypeSelect = options.onTypeSelect,
      setFocusVisible = options.setFocusVisible,
      setHighlightedIndex = options.setHighlightedIndex;
  var getItemIndexForSearch = React.useCallback(function (searchTerm, fromIndex) {
    if (itemCount === 0) {
      return null;
    }

    var index = fromIndex || 0;

    while (index < itemCount) {
      var item = getItemAtIndex(index);
      var textValue = itemToString$1 ? itemToString$1(item) : item;

      if (textValue && textValue.match(new RegExp("^".concat(escapeRegExp(searchTerm)), "i"))) {
        return index;
      }

      index = index + 1;
    }

    return null;
  }, [itemCount, itemToString$1, getItemAtIndex]);
  var state = React.useRef({
    search: "",
    timeout: null
  }).current; // eslint-disable-next-line complexity

  var onKeyDownCapture = function onKeyDownCapture(event) {
    var character = getStringForKey(event.key);

    if (!character || event.ctrlKey || event.metaKey) {
      return;
    } // Do not propagate the Spacebar event if it's meant to be part of the search.
    // When we time out, the search term becomes empty, hence the check on length.
    // Trimming is to account for the case of pressing the Spacebar more than once,
    // which should cycle through the selection/deselection of the focused item.


    if (character !== " " || state.search.trim().length > 0) {
      event.preventDefault();
      event.stopPropagation();
    } // When typing same character sebsequently and *quickly*, we treat it as cyling through items
    // starting with that char instead of seaching for double character, because in most cases
    // there won't be any option having same characters at the beginning. This should be only
    // impacting beginning of the words because length of `character` would be 1.


    if (character !== state.search) {
      state.search += character;
    } // Prioritize items after the currently focused item, falling back to searching the whole list.
    // We want to cycle through choices when keep typing the same first character, hence the +1
    // condition. All subsequent characters should stay at the current item otherwise it will
    // always jumping around.


    var index = getItemIndexForSearch(state.search, state.search.length > 1 ? highlightedIndex : highlightedIndex + 1); // If no key found, search from the top.

    if (index == null) {
      index = getItemIndexForSearch(state.search);
    }

    if (index != null) {
      setFocusVisible(true); // TODO: Maybe we can repurpose this setHighlightedIndex so that the user controls it's meant to set
      // hightlighted index when expanded v.s. selected item when collapsed

      setHighlightedIndex(index);

      if (onTypeSelect) {
        onTypeSelect(index);
      }
    }

    clearTimeout(state.timeout);
    state.timeout = setTimeout(function () {
      state.search = "";
    }, TYPE_SELECT_TIMEOUT);
  };

  return {
    // Using a capturing listener to catch the keydown event before
    // other hooks in order to handle the Spacebar event.
    onKeyDownCapture: onKeyDownCapture
  };
}

function getStringForKey(key) {
  // If the key is of length 1, it is an ASCII value.
  // Otherwise, if there are no ASCII characters in the key name,
  // it is a Unicode character.
  // See https://www.w3.org/TR/uievents-key/
  if (key.length === 1 || !/^[A-Z]/i.test(key)) {
    return key;
  }

  return "";
}

// SUPER HACKS AHEAD: The React team will hate this enough to hopefully give us
// a way to know the index of a descendant given a parent (will help generate
// IDs for accessibility a long with the ability create maximally composable
// component abstractions).
//
// This is all to avoid cloneElement. If we can avoid cloneElement then people
// can have arbitrary markup around MenuItems.  This basically takes advantage
// of react's render lifecycles to let us "register" descendants to an
// ancestor, so that we can track all the descendants and manage focus on them,
// etc.  The super hacks here are for the child to know it's index as well, so
// that it can set attributes, match against state from above, etc.

var DescendantContext$1 = /*#__PURE__*/React.createContext();
function DescendantProvider$1(_ref) {
  var items = _ref.items,
      props = _objectWithoutProperties(_ref, ["items"]);

  // On the first render we say we're "assigning", and the children will push
  // into the array when they show up in their own useLayoutEffect.
  var assigning = React.useRef(true); // since children are pushed into the array in useLayoutEffect of the child,
  // children can't read their index on first render.  So we need to cause a
  // second render so they can read their index.

  var _useState = React.useState(),
      _useState2 = _slicedToArray(_useState, 2),
      forceUpdate = _useState2[1]; // parent useLayoutEffect is always last


  React.useLayoutEffect(function () {
    if (assigning.current) {
      // At this point all of the children have pushed into the array so we set
      // assigning to false and force an update. Since we're in
      // useLayoutEffect, we won't get a flash of rendered content, it will all
      // happen synchronously. And now that this is false, children won't push
      // into the array on the forceUpdate
      assigning.current = false;
      forceUpdate({});
    } else {
      // After the forceUpdate completes, we end up here and set assigning back
      // to true for the next update from the app
      assigning.current = true;
    }

    return function () {
      // this cleanup function runs right before the next render, so it's the
      // right time to empty out the array to be reassigned with whatever shows
      // up next render.
      if (assigning.current) {
        // we only want to empty out the array before the next render cycle if
        // it was NOT the result of our forceUpdate, so being guarded behind
        // assigning.current works
        items.current = [];
      }
    };
  }, [items]);
  return /*#__PURE__*/React__default['default'].createElement(DescendantContext$1.Provider, _extends({}, props, {
    value: {
      items: items,
      assigning: assigning
    }
  }));
}

var ListWithDescendants = /*#__PURE__*/React.forwardRef(function ListWithDescendants(props, ref) {
  var _useContext = React.useContext(DescendantContext$1),
      items = _useContext.items;

  var _useList = useList(_objectSpread2({
    source: items.current.length ? items.current : []
  }, props)),
      focusableRef = _useList.focusableRef,
      state = _useList.state,
      helpers = _useList.helpers,
      listProps = _useList.listProps;

  var highlightedIndex = state.highlightedIndex;
  var setHighlightedIndex = helpers.setHighlightedIndex,
      setFocusVisible = helpers.setFocusVisible;

  var disabled = listProps.disabled,
      disableTypeToSelect = listProps.disableTypeToSelect,
      getItemAtIndex = listProps.getItemAtIndex,
      itemCount = listProps.itemCount,
      itemToString = listProps.itemToString,
      onListKeyDownCapture = listProps.onKeyDownCapture,
      restListProps = _objectWithoutProperties(listProps, ["disabled", "disableTypeToSelect", "getItemAtIndex", "itemCount", "itemToString", "onKeyDownCapture"]);

  var _useTypeSelect = useTypeSelect({
    getItemAtIndex: getItemAtIndex,
    highlightedIndex: highlightedIndex,
    itemCount: itemCount,
    itemToString: itemToString,
    setFocusVisible: setFocusVisible,
    setHighlightedIndex: setHighlightedIndex
  }),
      onTypeSelectKeyDownCapture = _useTypeSelect.onKeyDownCapture;

  var setListRef = useForkRef(focusableRef, props.listRef);

  var handleKeyDownCapture = function handleKeyDownCapture(event) {
    if (disabled) {
      return;
    }

    if (onListKeyDownCapture) {
      onListKeyDownCapture(event);
    }

    if (!disableTypeToSelect && onTypeSelectKeyDownCapture) {
      onTypeSelectKeyDownCapture(event);
    }
  };

  return /*#__PURE__*/React__default['default'].createElement(ListStateContext.Provider, {
    value: {
      state: state,
      helpers: helpers
    }
  }, /*#__PURE__*/React__default['default'].createElement(ListBase, _extends({
    listRef: setListRef,
    ref: ref
  }, restListProps, {
    disabled: disabled,
    getItemAtIndex: getItemAtIndex,
    itemCount: itemCount,
    itemToString: itemToString,
    onKeyDownCapture: handleKeyDownCapture
  })));
});
ListWithDescendants.propTypes = {
  listRef: refType
};
var List = /*#__PURE__*/React.forwardRef(function List(props, ref) {
  var restProps = _objectWithoutProperties(props, ["Tooltip", "tooltipEnterDelay", "tooltipLeaveDelay", "tooltipPlacement"]);

  var itemsRef = React.useRef([]);
  return (
    /*#__PURE__*/
    // <TooltipContext.Provider
    //   value={{
    //     Tooltip,
    //     enterDelay: tooltipEnterDelay,
    //     leaveDelay: tooltipLeaveDelay,
    //     placement: tooltipPlacement
    //   }}
    // >
    React__default['default'].createElement(DescendantProvider$1, {
      items: itemsRef
    }, /*#__PURE__*/React__default['default'].createElement(ListWithDescendants, _extends({
      ref: ref
    }, restProps))) // </TooltipContext.Provider>

  );
});
List.propTypes = {
  /**
   * The component used for item instead of the default.
   */
  ListItem: PropTypes__default['default'].func,

  /**
   * The component used when there are no items.
   */
  ListPlaceholder: PropTypes__default['default'].func,

  /**
   * The component used for tooltip instead of the default.
   */
  Tooltip: PropTypes__default['default'].func,

  /**
   * If `true`, the component will have no border.
   */
  borderless: PropTypes__default['default'].bool,

  /**
   * The className(s) of the component.
   */
  className: PropTypes__default['default'].string,

  /**
   * The density of a component affects the style of the layout.
   *
   * A high density component uses minimal sizing and spacing to convey the intended UI design.
   * Conversely, a low density component, maximizes the use of space and size to convey the UI Design.
   */
  density: PropTypes__default['default'].oneOf(["touch", "low", "medium", "high"]),

  /**
   * If `true`, the component will not receive focus.
   *
   * Useful when list is used with other components to form a tightly coupled atomic component where
   * other components should receive focus instead. For instance, when used with an input to form a
   * combo box the list should not be focusable, the input should receive focus instead.
   */
  disableFocus: PropTypes__default['default'].bool,

  /**
   * User can quickly type first few characters of item by keyboard and highlight item matching
   * start of the label text. This feature can be turned off by setting this to `true`.
   *
   * @default false
   */
  disableTypeToSelect: PropTypes__default['default'].bool,

  /**
   * If `true`, the component will be disabled.
   */
  disabled: PropTypes__default['default'].bool,

  /**
   * The number of items displayed in the visible area.
   *
   * Note that this determines the max height of the list if the list height is not set to 100%.
   *
   * @default 10
   */
  displayedItemCount: PropTypes__default['default'].number,

  /**
   * The indexer function used when there is no source. It should return a number.
   *
   * @param {number} index The item index.
   */
  getItemAtIndex: PropTypes__default['default'].func,

  /**
   * Used for providing customized item height. It should return a number or a string if item height
   * is in percentage. When used with `virtualized` prop a variable-height list will be rendered instead
   * of a fixed-height one.
   *
   * @param {number} index The item index.
   */
  getItemHeight: PropTypes__default['default'].func,

  /**
   * Used for providing customized item ids.
   *
   * @param {number} index The item index.
   */
  getItemId: PropTypes__default['default'].func,

  /**
   * The indexer function used when there is no source. It should return a number.
   *
   * @param {number} item The item.
   */
  getItemIndex: PropTypes__default['default'].func,

  /**
   * Height of the component.
   */
  height: PropTypes__default['default'].oneOfType([PropTypes__default['default'].number, PropTypes__default['default'].string]),

  /**
   * Used for a controlled component.
   *
   * @see `selectedItem` prop
   */
  highlightedIndex: PropTypes__default['default'].number,

  /**
   * Id of the component. If omitted a randomly generated id will be used.
   */
  id: PropTypes__default['default'].string,

  /**
   * The item selected initially.
   */
  // eslint-disable-next-line react/forbid-prop-types
  initialSelectedItem: PropTypes__default['default'].any,

  /**
   * The total number of items.
   *
   * Used for keyboard navigation (when `End` key is pressed) and when the list is virtualized.
   *
   * @default source.length
   */
  itemCount: PropTypes__default['default'].number,

  /**
   * Height of an item. I can be a number or a string if item height is in percentage. If omitted
   * default height values from Toolkit theme will be used.
   *
   * Note that when using a percentage value, the list must have a height.
   */
  itemHeight: PropTypes__default['default'].oneOfType([PropTypes__default['default'].number, PropTypes__default['default'].string]),

  /**
   * Used for providing text highlight.
   *
   * It can be a capturing regex or a string for a straightforward string matching.
   */
  itemTextHighlightPattern: PropTypes__default['default'].oneOfType([PropTypes__default['default'].instanceOf(RegExp), PropTypes__default['default'].string]),

  /**
   * Item `toString` function when list is not used declaratively and its items are objects
   * instead of strings. The string value is also used in tooltip when item text is truncated.
   *
   * If omitted, component will look for a `label` property on the data object.
   *
   * @param {object} item The item.
   */
  itemToString: PropTypes__default['default'].func,

  /**
   * Used for accessing the scrollable list node inside of the component. If you want to access
   * the outer wrapper node use `ref` instead.
   */
  listRef: refType,

  /**
   * Maximum list height.
   */
  maxHeight: PropTypes__default['default'].oneOfType([PropTypes__default['default'].number, PropTypes__default['default'].string]),

  /**
   * Maximum list width.
   */
  maxWidth: PropTypes__default['default'].oneOfType([PropTypes__default['default'].number, PropTypes__default['default'].string]),

  /**
   * Minimum list height.
   */
  minHeight: PropTypes__default['default'].oneOfType([PropTypes__default['default'].number, PropTypes__default['default'].string]),

  /**
   * Minimum list width.
   */
  minWidth: PropTypes__default['default'].oneOfType([PropTypes__default['default'].number, PropTypes__default['default'].string]),

  /**
   * Callback fired when item selection is changed.
   *
   * Note the selection will be an array if `selectionVariant` is set to `multiple`.
   *
   * @param {object} event The event source of the callback.
   * @param {object} item The selected item(s).
   */
  onChange: PropTypes__default['default'].func,

  /**
   * Callback fired when item is selected, no matter whether a change is made.
   *
   * @param {object} event The event source of the callback.
   * @param {object} item The selected item.
   */
  onSelect: PropTypes__default['default'].func,

  /**
   * @external - react-window
   *
   * The number of items to render outside of the visible area.
   *
   * @default 10
   */
  overscanCount: PropTypes__default['default'].number,

  /**
   * If `true`, the component will remember the last keyboard-interacted position
   * and highlight it when list is focused again.
   */
  restoreLastFocus: PropTypes__default['default'].bool,

  /**
   * Used for a controlled component.
   *
   * @see `highlightedIndex` prop
   */
  // eslint-disable-next-line react/forbid-prop-types
  selectedItem: PropTypes__default['default'].any,

  /**
   * If `true`, multiple items can be selected or deselected.
   */
  selectionVariant: PropTypes__default['default'].oneOf(["default", "deselectable", "multiple"]),

  /**
   * Data source used. It should be an array of objects or strings.
   */
  source: PropTypes__default['default'].arrayOf(PropTypes__default['default'].any),

  /**
   * When set to `true`, 'Tab' key selects current highlighted item before focus is blurred away
   * from the component. This would be the desirable behaviour for any dropdown menu based
   * components like dropdown, combobox.
   *
   * @default false
   */
  tabToSelect: PropTypes__default['default'].bool,

  /**
   * The number of milliseconds to wait before showing the tooltip.
   *
   * @default 1500
   */
  tooltipEnterDelay: PropTypes__default['default'].number,

  /**
   * The number of milliseconds to wait before hiding the tooltip.
   *
   * @default 0
   */
  tooltipLeaveDelay: PropTypes__default['default'].number,

  /**
   * The position of the tooltip.
   *
   * @default top
   */
  tooltipPlacement: PropTypes__default['default'].oneOf(["right", "top", "left", "bottom"]),

  /**
   * @external - react-window
   *
   * If `true`, list will be virtualized.
   * @see https://github.com/bvaughn/react-window
   */
  virtualized: PropTypes__default['default'].bool,

  /**
   * Width of the component.
   */
  width: PropTypes__default['default'].oneOfType([PropTypes__default['default'].number, PropTypes__default['default'].string])
};

var FormFieldContext = /*#__PURE__*/React.createContext();

function useFormFieldProps() {

  // const formControlProps = useFormControl();
  var _ref2 = React.useContext(FormFieldContext) || {};
      _objectWithoutProperties(_ref2, ["setFocusVisible"]); // useLayoutEffect(() => {
  //   if (focusVisible !== undefined && setFocusVisible) {
  //     setFocusVisible(focusVisible);
  //   }
  // }, [focusVisible, setFocusVisible]);


  return {// inFormField: formControlProps !== undefined,
    // setFocusVisible,
    // ...formControlProps,
    // ...formFieldProps,
  };
}

var css_248z$i = ".DropdownButton:hover {\n  background-color: transparent;\n}\n\n.DropdownButton-content {\n  align-items: center;\n  flex: 1;\n  width: 100%;\n  display: flex;\n  white-space: nowrap;\n}\n\n.DropdownButton-buttonLabel {\n  width: 100%;\n  display: inline-block;\n  overflow: hidden;\n  text-align: left;\n  text-overflow: ellipsis;\n  text-transform: none;\n}\n\n.DropdownButton-mediumDensity .DropdownButton-buttonLabel {\n  font-size: 12px;\n  min-height: 16px;\n  font-family: uitk-sans;\n  font-weight: 400;\n  line-height: 1.3;\n  letter-spacing: 0;\n}\n\n.DropdownButton-content .DropdownButton-icon {\n  color: #4c505b;\n}\n.DropdownButton-mediumDensity .DropdownButton-icon {\n  box-sizing: content-box;\n  margin-top: 2px;\n  padding-left: 8px;\n}\n";
styleInject(css_248z$i);

var DropdownButton = /*#__PURE__*/React.forwardRef(function DropdownButton(_ref, ref) {
  var ariaHideOptionRole = _ref.ariaHideOptionRole,
      className = _ref.className,
      _ref$density = _ref.density,
      density = _ref$density === void 0 ? "medium" : _ref$density,
      disabled = _ref.disabled,
      iconName = _ref.iconName,
      iconSize = _ref.iconSize,
      label = _ref.label,
      labelId = _ref.labelId,
      fullWidth = _ref.fullWidth,
      rest = _objectWithoutProperties(_ref, ["ariaHideOptionRole", "className", "density", "disabled", "iconName", "iconSize", "isOpen", "label", "labelId", "inField", "fullWidth"]);

  useFormFieldProps();
  return /*#__PURE__*/React__default['default'].createElement(Button, _extends({
    className: classnames__default['default']("DropdownButton", "DropdownButton-".concat(density, "Density"), className, {
      "DropdownButton-fullwidth": fullWidth
    }) // classes={{
    //   focusVisible: focusVisibleClassName,
    // }}
    // We don't want the 'button' tag to be shown in the DOM to trigger some accessability testing
    // tool's false alarm on role of 'listbox'
    ,
    component: "div",
    "data-jpmui-test": "dropdown-button",
    density: density,
    disabled: disabled,
    ref: ref,
    variant: "secondary"
  }, rest), /*#__PURE__*/React__default['default'].createElement("div", {
    className: "DropdownButton-content"
  }, /*#__PURE__*/React__default['default'].createElement("span", {
    // 'hidden' so that screenreader won't be confused the additional 'option' which is just a label
    "aria-hidden": ariaHideOptionRole ? "true" : undefined,
    "aria-selected": "false",
    className: "DropdownButton-buttonLabel",
    id: labelId // 'option' role here is to suppress accessibility testing tool warning about 'listbox' missing children role.
    ,
    role: "option"
  }, label), /*#__PURE__*/React__default['default'].createElement(Icon, {
    className: "DropdownButton-icon",
    name: iconName,
    size: iconSize
  })));
});
DropdownButton.propTypes = {
  ariaHideOptionRole: PropTypes__default['default'].bool,
  buttonRef: refType,
  className: PropTypes__default['default'].string,
  density: PropTypes__default['default'].oneOf(["touch", "high", "medium", "low"]),
  disabled: PropTypes__default['default'].bool,
  fullWidth: PropTypes__default['default'].bool,
  iconName: PropTypes__default['default'].string.isRequired,
  iconSize: PropTypes__default['default'].number,
  inFormField: PropTypes__default['default'].bool,
  isOpen: PropTypes__default['default'].bool,
  label: PropTypes__default['default'].string,

  /**
   * Id for the label. This is needed for ARIA attributes.
   */
  labelId: PropTypes__default['default'].string,
  onBlur: PropTypes__default['default'].func,
  onFocus: PropTypes__default['default'].func,
  onKeyDown: PropTypes__default['default'].func,
  onKeyUp: PropTypes__default['default'].func
};

function useResolvedElement(subscriber, refOrElement) {
  // eslint-disable-next-line no-empty-function
  var callSubscriber = React.useCallback(function () {}, []); // The default ref has to be non-conditionally declared here whether or not
  // it'll be used as that's how hooks work.
  // @see https://reactjs.org/docs/hooks-rules.html#explanation
  // Default ref

  var ref = React.useRef(null);
  var refElement = React.useRef(null);
  var callbackRefElement = React.useRef(null);
  var callbackRef = React.useCallback(function (element) {
    callbackRefElement.current = element;
    callSubscriber();
  }, [callSubscriber]);
  var lastReportedElementRef = React.useRef(null);
  var cleanupRef = React.useRef();
  callSubscriber = React.useCallback(function () {
    var element = null;

    if (callbackRefElement.current) {
      element = callbackRefElement.current;
    } else if (refElement.current) {
      element = refElement.current;
    } else if (refOrElement instanceof HTMLElement) {
      element = refOrElement;
    }

    if (lastReportedElementRef.current === element) {
      return;
    }

    if (cleanupRef.current) {
      cleanupRef.current();
    }

    lastReportedElementRef.current = element; // Only calling the subscriber, if there's an actual element to report.

    if (element) {
      cleanupRef.current = subscriber(element);
    }
  }, [refOrElement, subscriber]);

  if (refOrElement && !(refOrElement instanceof HTMLElement)) {
    // Overriding the default ref with the given one
    ref = refOrElement;
  } // On each render, we check whether a ref changed, or if we got a new raw
  // element.


  React.useEffect(function () {
    // Note that this does not mean that "element" will necessarily be whatever
    // the ref currently holds. It'll simply "update" `element` each render to
    // the current ref value, but there's no guarantee that the ref value will
    // not change later without a render.
    // This may or may not be a problem depending on the specific use case.
    refElement.current = ref.current;
    callSubscriber();
  }, [callSubscriber, ref, refOrElement]);
  return {
    ref: ref,
    callbackRef: callbackRef
  };
}

function useResizeObserver$1() {
  var opts = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  // Saving the callback as a ref. With this, I don't need to put onResize in the
  // effect dep array, and just passing in an anonymous function without memoising
  // will not reinstantiate the hook's ResizeObserver
  var onResize = opts.onResize;
  var onResizeRef = React.useRef(undefined);
  onResizeRef.current = onResize;

  var _useState = React.useState({
    width: undefined,
    height: undefined
  }),
      _useState2 = _slicedToArray(_useState, 2),
      size = _useState2[0],
      setSize = _useState2[1]; // Using a single instance throughout the hook's lifetime


  var resizeObserverRef = React.useRef(); // In certain edge cases the RO might want to report a size change just after
  // the component unmounted.

  var didUnmount = React.useRef(false);
  React.useEffect(function () {
    return function () {
      didUnmount.current = true;
    };
  }, []); // Using a ref to track the previous width / height to avoid unnecessary renders

  var previous = React.useRef({
    width: undefined,
    height: undefined
  }); // This block is kinda like a useEffect, only it's called whenever a new
  // element could be resolved based on the ref option. It also has a cleanup
  // function.

  var _useResolvedElement = useResolvedElement(function (element) {
    if (opts.fullWidth) {
      // Initialising the RO instance
      if (!resizeObserverRef.current) {
        // Saving a single instance, used by the hook from this point on.
        resizeObserverRef.current = new ResizeObserver(function (entries) {
          if (!Array.isArray(entries)) {
            return;
          } // Since we only observe the one element, we don't need to loop over the
          // array


          if (!entries.length) {
            return;
          }

          var entry = entries[0]; // `Math.round` is in line with how CSS resolves sub-pixel values

          var newWidth = Math.round(entry.contentRect.width);
          var newHeight = Math.round(entry.contentRect.height);

          if (previous.current.width !== newWidth || previous.current.height !== newHeight) {
            var newSize = {
              width: newWidth,
              height: newHeight
            };

            if (onResizeRef.current) {
              onResizeRef.current(newSize);
            } else {
              previous.current.width = newWidth;
              previous.current.height = newHeight;

              if (!didUnmount.current) {
                setSize(newSize);
              }
            }
          }
        });
      }

      resizeObserverRef.current.observe(element);
    }

    return function () {
      if (resizeObserverRef.current) {
        resizeObserverRef.current.unobserve(element);
      }
    };
  }, opts.ref),
      ref = _useResolvedElement.ref,
      callbackRef = _useResolvedElement.callbackRef;

  return React.useMemo(function () {
    return {
      ref: ref,
      callbackRef: callbackRef,
      width: size.width,
      height: size.height
    };
  }, [ref, callbackRef, size]);
}

function useDropdown() {
  var props = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var isMultiSelect = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
  var a11yProps = useA11yProps();

  var _useFormFieldProps = useFormFieldProps(),
      formFieldFullWidth = _useFormFieldProps.fullWidth;

  var _props$ButtonProps = props.ButtonProps,
      ButtonProps = _props$ButtonProps === void 0 ? {} : _props$ButtonProps,
      ListItem = props.ListItem,
      ListProps = props.ListProps,
      _props$adaExceptions = props.adaExceptions;
  _props$adaExceptions = _props$adaExceptions === void 0 ? {} : _props$adaExceptions;

  var virtualized = _props$adaExceptions.virtualized,
      _props$borderless = props.borderless,
      borderless = _props$borderless === void 0 ? false : _props$borderless,
      buttonRefProp = props.buttonRef,
      densityProp = props.density,
      disabled = props.disabled,
      displayedItemCount = props.displayedItemCount,
      _props$fullWidth = props.fullWidth,
      fullWidthProp = _props$fullWidth === void 0 ? formFieldFullWidth : _props$fullWidth,
      iconName = props.iconName,
      iconSize = props.iconSize,
      idProp = props.id,
      _props$initialIsOpen = props.initialIsOpen,
      initialIsOpen = _props$initialIsOpen === void 0 ? false : _props$initialIsOpen,
      initialSelectedItem = props.initialSelectedItem,
      isOpenProp = props.isOpen,
      _props$itemToString = props.itemToString,
      itemToString$1 = _props$itemToString === void 0 ? itemToString : _props$itemToString,
      listWidthProp = props.listWidth,
      onBlurProp = props.onBlur,
      onButtonClickProp = props.onButtonClick,
      onChangeProp = props.onChange,
      onFocusProp = props.onFocus,
      onMouseLeave = props.onMouseLeave,
      onMouseOver = props.onMouseOver,
      onSelect = props.onSelect,
      selectedItemProp = props.selectedItem,
      source = props.source,
      widthProp = props.width,
      rest = _objectWithoutProperties(props, ["ButtonProps", "ListItem", "ListProps", "adaExceptions", "borderless", "buttonRef", "children", "density", "disabled", "displayedItemCount", "fullWidth", "iconName", "iconSize", "id", "initialIsOpen", "initialSelectedItem", "isOpen", "itemToString", "listWidth", "onBlur", "onButtonClick", "onChange", "onFocus", "onMouseLeave", "onMouseOver", "onSelect", "selectedItem", "source", "width"]);

  var id = useId(idProp);
  var buttonRef = React.useRef(null);
  var density = useDensity(densityProp);
  var isFullWidth = fullWidthProp !== undefined ? fullWidthProp : formFieldFullWidth;

  var _useResizeObserver = useResizeObserver$1({
    fullWidth: isFullWidth
  }),
      rootRef = _useResizeObserver.ref,
      observedWidth = _useResizeObserver.width;

  var onButtonKeyDown = ButtonProps.onKeyDown,
      onButtonKeyDownCapture = ButtonProps.onKeyDownCapture,
      restButtonProps = _objectWithoutProperties(ButtonProps, ["onKeyDown", "onKeyDownCapture"]);

  var _useControlled = useControlled({
    controlled: isOpenProp,
    "default": initialIsOpen,
    name: "useDropdown",
    state: "isOpen"
  }),
      _useControlled2 = _slicedToArray(_useControlled, 2),
      isOpen = _useControlled2[0],
      setIsOpen = _useControlled2[1];

  var listWidth = React.useMemo(function () {
    if (isFullWidth) {
      return observedWidth ? observedWidth : undefined;
    } else {
      return listWidthProp ? listWidthProp : widthProp;
    }
  }, [isFullWidth, listWidthProp, observedWidth, widthProp]);

  var _useList = useList(_objectSpread2({
    ListItem: ListItem,
    displayedItemCount: displayedItemCount,
    id: "".concat(id, "-list"),
    initialSelectedItem: initialSelectedItem,
    itemToString: itemToString$1,
    onChange: onChangeProp,
    onSelect: onSelect,
    selectedItem: selectedItemProp,
    selectionVariant: isMultiSelect ? "multiple" : "default",
    source: source,
    tabToSelect: !isMultiSelect,
    virtualized: virtualized,
    width: listWidth
  }, ListProps)),
      focusableRef = _useList.focusableRef,
      state = _useList.state,
      helpers = _useList.helpers,
      listProps = _useList.listProps;

  var selectedItem = state.selectedItem,
      highlightedIndex = state.highlightedIndex;
  var setHighlightedIndex = helpers.setHighlightedIndex,
      setFocusVisible = helpers.setFocusVisible;

  var onListBlur = listProps.onBlur,
      onListClick = listProps.onClick,
      onListFocus = listProps.onFocus,
      onListKeyDown = listProps.onKeyDown,
      listId = listProps.id,
      ariaActivedescendant = listProps["aria-activedescendant"],
      ariaMultiselectable = listProps["aria-multiselectable"],
      getItemAtIndex = listProps.getItemAtIndex,
      getItemIndex = listProps.getItemIndex,
      itemCount = listProps.itemCount,
      restListProps = _objectWithoutProperties(listProps, ["onBlur", "onClick", "onFocus", "onKeyDown", "id", "aria-activedescendant", "aria-multiselectable", "getItemAtIndex", "getItemIndex", "itemCount"]);

  var _useTypeSelect = useTypeSelect({
    getItemAtIndex: getItemAtIndex,
    highlightedIndex: highlightedIndex,
    itemCount: itemCount,
    itemToString: itemToString$1,
    setFocusVisible: setFocusVisible,
    setHighlightedIndex: setHighlightedIndex
  }),
      onTypeSelectKeyDownCapture = _useTypeSelect.onKeyDownCapture;

  var getSelectedItemLabel = function getSelectedItemLabel() {
    if (isMultiSelect && Array.isArray(selectedItem)) {
      if (selectedItem.length === 0) {
        return undefined;
      } else if (selectedItem.length === 1) {
        return itemToString$1(selectedItem[0]);
      } else {
        return "".concat(selectedItem.length, " items selected");
      }
    } else {
      return selectedItem == null ? undefined : itemToString$1(selectedItem);
    }
  };

  var syncListFocus = function syncListFocus(event) {
    if (!isOpen) {
      onListFocus(event);
    } else {
      onListBlur(event);
    }
  };

  var handleButtonClick = function handleButtonClick(event) {
    // Do not trigger menu open for 'Enter' and 'SPACE' key as they're handled in `handleButtonKeyDown`
    if (["Enter", " "].indexOf(event.key) === -1) {
      setIsOpen(function (value) {
        return !value;
      });
      syncListFocus(event);
    }

    if (onButtonClickProp) {
      onButtonClickProp(event);
    }
  }; // eslint-disable-next-line complexity


  var handleButtonKeyDown = function handleButtonKeyDown(event) {
    if ("Escape" === event.key) {
      event.preventDefault();

      if (isOpen) {
        setIsOpen(false);
        onListBlur(event);
      }
    } else if ("ArrowDown" === event.key) {
      event.preventDefault();

      if (event.altKey) {
        event.stopPropagation();
      }

      if (!isOpen) {
        setIsOpen(true);
        onListFocus(event);
      }
    } else if ("Tab" === event.key) {
      if (isOpen) {
        setIsOpen(false);
        onListBlur(event);
      }
    } else if (["Enter", " "].indexOf(event.key) !== -1) {
      event.preventDefault();

      if (!isMultiSelect || !isOpen) {
        setIsOpen(function (value) {
          return !value;
        });
        syncListFocus(event);
      }
    } // A lot of keyDown events are shared in the List already


    onListKeyDown(event);

    if (onButtonKeyDown) {
      onButtonKeyDown(event);
    }
  };

  var handleButtonKeyDownCapture = function handleButtonKeyDownCapture(event) {
    if (disabled) {
      return;
    }

    if (onTypeSelectKeyDownCapture) {
      onTypeSelectKeyDownCapture(event);
    }

    if (onButtonKeyDownCapture) {
      onButtonKeyDownCapture(event);
    }
  };

  var handleListMouseDown = function handleListMouseDown(event) {
    // Prevent blur from button
    event.preventDefault();
  };

  var handleListClick = function handleListClick(event) {
    if (onListClick) {
      onListClick(event);
    }

    if (!isMultiSelect) {
      setIsOpen(false);
    }
  };

  var handleButtonBlur = function handleButtonBlur(event) {
    setIsOpen(false);

    if (onListBlur) {
      onListBlur(event);
    }

    if (onBlurProp) {
      onBlurProp(event);
    }
  };

  var handleButtonFocus = function handleButtonFocus(event) {
    if (isOpen) {
      onListFocus(event);
    }

    if (onFocusProp) {
      onFocusProp(event);
    }
  };

  var dropdownButtonLabelId = "".concat(listId, "--label");

  var dropdownButtonProps = _objectSpread2(_objectSpread2({
    "aria-activedescendant": isOpen && ariaActivedescendant ? ariaActivedescendant : dropdownButtonLabelId,
    "aria-expanded": isOpen,
    "aria-multiselectable": ariaMultiselectable,
    "aria-owns": isOpen ? listId : undefined,
    ariaHideOptionRole: isOpen,
    role: "listbox",
    buttonRef: useForkRef(buttonRef, useForkRef(focusableRef, buttonRefProp)),
    // classes: {
    //   content: classes.content,
    //   buttonLabel: classes.buttonLabel,
    //   icon: classes.icon,
    //   formField: classes.formField,
    //   fullWidth: classes.fullWidth,
    // },
    density: density,
    disabled: disabled,
    fullWidth: isFullWidth,
    iconName: iconName,
    iconSize: iconSize,
    id: rest.id,
    isOpen: isOpen,
    label: getSelectedItemLabel(),
    labelId: dropdownButtonLabelId,
    // `fullWidth` is handled separately in `DropdownButton`
    style: {
      width: isFullWidth ? undefined : widthProp
    },
    onBlur: handleButtonBlur,
    onClick: disabled ? undefined : handleButtonClick,
    onFocus: handleButtonFocus,
    onKeyDown: disabled ? undefined : handleButtonKeyDown,
    onKeyDownCapture: disabled ? undefined : handleButtonKeyDownCapture,
    onMouseLeave: onMouseLeave,
    onMouseOver: onMouseOver
  }, restButtonProps), a11yProps);

  return {
    rootProps: _objectSpread2(_objectSpread2({}, rest), {}, {
      "aria-expanded": undefined,
      "aria-haspopup": undefined,
      "aria-labelledby": undefined,
      "data-jpmui-test": "dropdown",
      disabled: disabled,
      density: density,
      id: idProp,
      isOpen: isOpen,
      fullWidth: isFullWidth,
      role: undefined,
      ref: rootRef
    }),
    buttonProps: dropdownButtonProps,
    listContext: {
      state: state,
      helpers: helpers
    },
    listProps: _objectSpread2({
      "aria-multiselectable": ariaMultiselectable,
      "aria-labelledby": a11yProps["aria-labelledby"],
      id: listId,
      borderless: borderless,
      density: density,
      disableFocus: true,
      onBlur: onListBlur,
      onClick: handleListClick,
      onFocus: onListFocus,
      onKeyDown: onListKeyDown,
      onMouseDown: handleListMouseDown,
      getItemAtIndex: getItemAtIndex,
      getItemIndex: getItemIndex,
      itemCount: itemCount
    }, restListProps)
  };
}

var css_248z$j = ".Dropdown-touchDensity {\n  --dropdown-font-size: var(--uitk-font-size-touch);\n  --dropdown-spacing: var(--uitk-space-touch);\n}\n.Dropdown-lowDensity {\n  --dropdown-font-size: var(--uitk-font-size-low);\n  --dropdown-spacing: var(--uitk-space-low);\n}\n.Dropdown-mediumDensity {\n  --dropdown-font-size: var(--uitk-font-size-medium);\n  --dropdown-spacing: var(--uitk-space-medium);\n}\n.Dropdown-highDensity {\n  --dropdown-font-size: var(--uitk-font-size-high);\n  --dropdown-spacing: var(--uitk-space-high);\n}\n\n.Dropdown {\n  box-sizing: border-box;\n  display: inline-block;\n  font-size: var(--dropdown-font-size);\n  line-height: 0;\n  position: relative;\n}\n\n.Dropdown .DropdownButton-icon {\n  padding-left: var(--dropdown-spacing);\n}\n\n.Dropdown .DropdownButton-icon {\n  box-sizing: content-box;\n  margin-top: 2px;\n}\n\n.Dropdown-touchDensity .DropdownButton-icon {\n  margin-top: 3px;\n}\n\n.Dropdown .DropdownButton:active {\n  color: var(--uitk-action-secondary-default-color);\n  background-color: var(--uitk-action-secondary-default-background);\n}\n\n.Dropdown-disabled {\n}\n\n.Dropdown-fullwidth {\n}\n\n.Dropdown .Button-label {\n  font-weight: var(--uitk-font-weight-regular);\n}\n\n/* TODO should be on popper, needs to be in characteristics */\n.Dropdown-popper {\n  z-index: 100;\n}\n";
styleInject(css_248z$j);

/**
 * Renders a basic dropdown with selectable item
 */

var Dropdown = /*#__PURE__*/React.forwardRef(function Dropdown(props, ref) {
  var className = props.className,
      PopperProps = props.PopperProps,
      restProps = _objectWithoutProperties(props, ["className", "PopperProps"]);

  var _useDropdown = useDropdown(restProps),
      rootProps = _useDropdown.rootProps,
      _useDropdown$buttonPr = _useDropdown.buttonProps,
      buttonRef = _useDropdown$buttonPr.buttonRef,
      buttonProps = _objectWithoutProperties(_useDropdown$buttonPr, ["buttonRef"]),
      listContext = _useDropdown.listContext,
      listProps = _useDropdown.listProps;

  var listRef = React.useRef(null);

  var _useTheme = useTheme(),
      themeId = _useTheme.id;

  var density = rootProps.density,
      disabled = rootProps.disabled,
      fullWidth = rootProps.fullWidth,
      isOpen = rootProps.isOpen,
      rootRef = rootProps.ref,
      restRootProps = _objectWithoutProperties(rootProps, ["density", "disabled", "fullWidth", "isOpen", "ref"]);

  var _usePopperPositioning = usePopperPositioning(rootRef, listRef, isOpen),
      _usePopperPositioning2 = _slicedToArray(_usePopperPositioning, 2),
      popperPosition = _usePopperPositioning2[0],
      maxListHeight = _usePopperPositioning2[1];

  return /*#__PURE__*/React__default['default'].createElement("div", _extends({
    className: classnames__default['default']("Dropdown", "Dropdown-".concat(density, "Density"), {
      "Dropdown-disabled": disabled,
      "Dropdown-fullwidth": fullWidth
    }, className),
    ref: useForkRef(rootRef, ref)
  }, restRootProps), props.children ? props.children({
    DropdownButtonProps: _objectSpread2({
      buttonRef: buttonRef
    }, buttonProps),
    isOpen: isOpen,
    itemToString: listProps.itemToString,
    selectedItem: listContext.state.selectedItem
  }) : /*#__PURE__*/React__default['default'].createElement(DropdownButton, _extends({}, buttonProps, {
    ref: buttonRef
  })), rootRef.current && /*#__PURE__*/React__default['default'].createElement(Popper, _extends({
    anchorEl: rootRef.current,
    className: classnames__default['default']("Dropdown-popper", themeId),
    open: isOpen,
    placement: popperPosition,
    role: null
  }, PopperProps), /*#__PURE__*/React__default['default'].createElement(ListStateContext.Provider, {
    value: listContext
  }, /*#__PURE__*/React__default['default'].createElement(ListBase, _extends({
    "data-jpmui-test": "dropdown-list"
  }, listProps, {
    maxHeight: maxListHeight || listProps.maxHeight,
    ref: listRef
  })))));
});
Dropdown.defaultProps = {
  iconName: "down-arrow",
  width: 180
};
Dropdown.propTypes = {
  /**
   * Props to be applied on the default button component
   */
  // eslint-disable-next-line react/forbid-prop-types
  ButtonProps: PropTypes__default['default'].object,

  /**
   * The component used for item instead of the default.
   */
  ListItem: PropTypes__default['default'].func,

  /**
   * Properties applied to the `List` element.
   */
  // eslint-disable-next-line react/forbid-prop-types
  ListProps: PropTypes__default['default'].object,

  /**
   * @external - react-popper
   * Override react-popper props
   */
  // eslint-disable-next-line react/forbid-prop-types
  PopperProps: PropTypes__default['default'].object,

  /**
   * Object that houses ADA-related props.
   *
   * @property {bool} virtualized Set to `true` to boost browser performance
   * for long lists by rendering only the items currently scrolled into view
   * (plus overscan items). JSX: `adaExceptions={{virtualized:true}}`
   * For better ADA support, omit (or set to `false`).
   */
  adaExceptions: PropTypes__default['default'].shape({
    virtualized: PropTypes__default['default'].bool
  }),

  /**
   * If the component has no border.
   */
  borderless: PropTypes__default['default'].bool,

  /**
   * A ref to the button
   */
  buttonRef: refType,

  /**
   * Override the triggering component
   */
  children: PropTypes__default['default'].func,

  /**
   * The className(s) of the component
   */
  className: PropTypes__default['default'].string,

  /**
   * The density of a component affects the style of the layout.
   * A high density component uses minimal sizing and spacing to convey the intended UI design.
   * Conversely, a low density component, maximizes the use of space and size to convey the UI Design.
   */
  density: PropTypes__default['default'].oneOf(["touch", "low", "medium", "high"]),

  /**
   * Disable user interaction
   */
  disabled: PropTypes__default['default'].bool,

  /**
   * The number of items displayed in the visible area.
   *
   * Note that this determines the max height of the list if the list height is not set to 100%.
   *
   * @default 10
   */
  displayedItemCount: PropTypes__default['default'].number,

  /**
   * If `true`, the Dropdown will occupy the full width of it's container
   */
  fullWidth: PropTypes__default['default'].bool,

  /**
   * Sets the icon name, default is 'down-arrow'
   */
  iconName: PropTypes__default['default'].string,

  /**
   * Sets the size of the down arrow icon. If this is not specified, a default size based on density is used.
   */
  iconSize: PropTypes__default['default'].number,

  /**
   * Sets the id of the component.
   */
  id: PropTypes__default['default'].string,

  /**
   * This is the initial isOpen value.
   *
   * @default false
   */
  initialIsOpen: PropTypes__default['default'].bool,

  /**
   * Pass an item that should be selected by default.
   */
  // eslint-disable-next-line react/forbid-prop-types
  initialSelectedItem: PropTypes__default['default'].any,

  /**
   * Whether the menu should be considered open or closed. Some aspects of the
   * downshift component respond differently based on this value (for example,
   * if isOpen is true when the user hits "Enter" on the input field, then the
   * item at the highlightedIndex item is selected).
   */
  isOpen: PropTypes__default['default'].bool,

  /**
   * Used to determine the string value for the selected item.
   */
  itemToString: PropTypes__default['default'].func,

  /**
   * Used to provide a custom list renderer. This should only be used in
   * rare occasions, like for custom elements.
   */
  listRenderer: PropTypes__default['default'].func,

  /**
   * Customize width of the Dropdown List. This supersedes `width`.
   */
  listWidth: PropTypes__default['default'].oneOfType([PropTypes__default['default'].number, PropTypes__default['default'].string]),

  /**
   * @external - material-ui
   * Callback fired by the input component onBlur.
   *
   * @param {object} event The event source of the callback
   */
  onBlur: PropTypes__default['default'].func,

  /**
   * Called when user clicks on the dropdown button.
   *
   * @param {object} event The event source of the callback
   */
  onButtonClick: PropTypes__default['default'].func,

  /**
   * Called when the user selects an item and the selected item has changed.
   *
   * @param {object} event The event source of the callback
   * @param {any} selectedItem The item that was just selected
   */
  onChange: PropTypes__default['default'].func,

  /**
   * @external - material-ui
   * Callback fired by the input component onFocus.
   *
   * @param {object} event The event source of the callback
   */
  onFocus: PropTypes__default['default'].func,

  /**
   * Called when the user mouses off the button.
   */
  onMouseLeave: PropTypes__default['default'].func,

  /**
   * Called when the user mouses over the button.
   */
  onMouseOver: PropTypes__default['default'].func,

  /**
   * Called when the user selects an item, regardless of the previous selected
   * item.
   *
   * @param {object} event The event source of the callback
   * @param {any} selectedItem The item that was just selected
   */
  onSelect: PropTypes__default['default'].func,

  /**
   * The currently selected item.
   */
  // eslint-disable-next-line react/forbid-prop-types
  selectedItem: PropTypes__default['default'].any,

  /**
   * List of items when using a Dropdown.
   */
  source: PropTypes__default['default'].arrayOf(PropTypes__default['default'].any).isRequired,

  /**
   Customize width of Dropdown. Also controls Dropdown List if `listWidth` prop is not set.
   */
  width: PropTypes__default['default'].oneOfType([PropTypes__default['default'].number, PropTypes__default['default'].string])
};

/**
 * Renders a multi-select dropdown with selectable items
 */

var MultiSelectDropdown = /*#__PURE__*/React.forwardRef(function MultiSelectDropdown(props, ref) {
  var className = props.className,
      children = props.children,
      PopperProps = props.PopperProps;

  var _useDropdown = useDropdown(props, true),
      rootProps = _useDropdown.rootProps,
      buttonProps = _useDropdown.buttonProps,
      listContext = _useDropdown.listContext,
      listProps = _useDropdown.listProps;

  var density = rootProps.density,
      disabled = rootProps.disabled,
      fullWidth = rootProps.fullWidth,
      isOpen = rootProps.isOpen,
      rootRef = rootProps.ref,
      restRootProps = _objectWithoutProperties(rootProps, ["density", "disabled", "fullWidth", "isOpen", "ref"]);

  return /*#__PURE__*/React__default['default'].createElement("div", _extends({
    className: classnames__default['default']("Dropdown", "Dropdown-".concat(density, "Density"), {
      "Dropdown-disabled": disabled,
      "Dropdown-fullwidth": fullWidth
    }, className),
    ref: useForkRef(rootRef, ref)
  }, restRootProps), children ? children({
    DropdownButtonProps: buttonProps,
    isOpen: isOpen,
    itemToString: listProps.itemToString,
    selectedItem: listContext.state.selectedItem
  }) : /*#__PURE__*/React__default['default'].createElement(DropdownButton, buttonProps), rootRef.current && /*#__PURE__*/React__default['default'].createElement(Popper, _extends({
    anchorEl: rootRef.current,
    className: "Dropdown-popper",
    open: isOpen,
    placement: "bottom-start" // We don't want the default role of 'tooltip'
    ,
    role: null
  }, PopperProps), /*#__PURE__*/React__default['default'].createElement(ListStateContext.Provider, {
    value: listContext
  }, /*#__PURE__*/React__default['default'].createElement(ListBase, _extends({
    "data-jpmui-test": "dropdown-list"
  }, listProps)))));
});
MultiSelectDropdown.defaultProps = {
  width: "180px",
  iconName: "down-arrow"
};
MultiSelectDropdown.propTypes = {
  /**
   * Props to be applied on the default button component
   */
  // eslint-disable-next-line react/forbid-prop-types
  ButtonProps: PropTypes__default['default'].object,

  /**
   * The component used for item instead of the default.
   */
  ListItem: PropTypes__default['default'].func,

  /**
   * Properties applied to the `List` element.
   */
  // eslint-disable-next-line react/forbid-prop-types
  ListProps: PropTypes__default['default'].object,

  /**
   * @external - react-popper
   * Override react-popper props
   */
  // eslint-disable-next-line react/forbid-prop-types
  PopperProps: PropTypes__default['default'].object,

  /**
   * Object that houses ADA-related props.
   *
   * @property {bool} virtualized Set to `true` to boost browser performance
   * for long lists by rendering only the items currently scrolled into view
   * (plus overscan items). JSX: `adaExceptions={{virtualized:true}}`
   * For better ADA support, omit (or set to `false`).
   */
  adaExceptions: PropTypes__default['default'].shape({
    virtualized: PropTypes__default['default'].bool
  }),

  /**
   * If the component has no border.
   */
  borderless: PropTypes__default['default'].bool,

  /**
   * A ref to the button
   */
  buttonRef: refType,

  /**
   * Override the triggering component
   */
  children: PropTypes__default['default'].func,

  /**
   * The className(s) of the component
   */
  className: PropTypes__default['default'].string,

  /**
   * The density of a component affects the style of the layout.
   * A high density component uses minimal sizing and spacing to convey the intended UI design.
   * Conversely, a low density component, maximizes the use of space and size to convey the UI Design.
   */
  density: PropTypes__default['default'].oneOf(["touch", "low", "medium", "high"]),

  /**
   * Disable user interaction
   */
  disabled: PropTypes__default['default'].bool,

  /**
   * The number of items displayed in the visible area.
   *
   * Note that this determines the max height of the list if the list height is not set to 100%.
   *
   * @default 10
   */
  displayedItemCount: PropTypes__default['default'].number,

  /**
   * If `true`, the Dropdown will occupy the full width of it's container
   */
  fullWidth: PropTypes__default['default'].bool,

  /**
   * Sets the icon name, default is 'down-arrow'
   */
  iconName: PropTypes__default['default'].string,

  /**
   * Sets the size of the down arrow icon. If this is not specified, a default size based on density is used.
   */
  iconSize: PropTypes__default['default'].number,

  /**
   * Sets the id of the component.
   */
  id: PropTypes__default['default'].string,

  /**
   * This is the initial isOpen value.
   *
   * @default false
   */
  initialIsOpen: PropTypes__default['default'].bool,

  /**
   * Pass an item that should be selected by default.
   */
  // eslint-disable-next-line react/forbid-prop-types
  initialSelectedItem: PropTypes__default['default'].any,

  /**
   * Whether the menu should be considered open or closed. Some aspects of the
   * downshift component respond differently based on this value (for example,
   * if isOpen is true when the user hits "Enter" on the input field, then the
   * item at the highlightedIndex item is selected).
   */
  isOpen: PropTypes__default['default'].bool,

  /**
   * Used to determine the string value for the selected item.
   */
  itemToString: PropTypes__default['default'].func,

  /**
   * Customize width of the Dropdown List. This supersedes `width`.
   */
  listWidth: PropTypes__default['default'].oneOfType([PropTypes__default['default'].number, PropTypes__default['default'].string]),

  /**
   * @external - material-ui
   * Callback fired by the input component onBlur.
   *
   * @param {object} event The event source of the callback
   */
  onBlur: PropTypes__default['default'].func,

  /**
   * Called when user clicks on the dropdown button.
   *
   * @param {object} event The event source of the callback
   */
  onButtonClick: PropTypes__default['default'].func,

  /**
   * Called when the user selects an item and the selected item has changed.
   *
   * @param {object} event The event source of the callback
   * @param {any} selectedItem The item that was just selected
   */
  onChange: PropTypes__default['default'].func,

  /**
   * @external - material-ui
   * Callback fired by the input component onFocus.
   *
   * @param {object} event The event source of the callback
   */
  onFocus: PropTypes__default['default'].func,

  /**
   * Called when the user mouses off the button.
   */
  onMouseLeave: PropTypes__default['default'].func,

  /**
   * Called when the user mouses over the button.
   */
  onMouseOver: PropTypes__default['default'].func,

  /**
   * Called when the user selects an item, regardless of the previous selected
   * item.
   *
   * @param {object} event The event source of the callback
   * @param {any} selectedItem The item that was just selected
   */
  onSelect: PropTypes__default['default'].func,

  /**
   * The currently selected item.
   */
  // eslint-disable-next-line react/forbid-prop-types
  selectedItem: PropTypes__default['default'].any,

  /**
   * List of items when using a Dropdown.
   */
  source: PropTypes__default['default'].arrayOf(PropTypes__default['default'].any).isRequired,

  /**
   Customize width of Dropdown. Also controls Dropdown List if `listWidth` prop is not set.
   */
  width: PropTypes__default['default'].oneOfType([PropTypes__default['default'].number, PropTypes__default['default'].string])
};

var css_248z$k = ".uitk-light .Input {\n  --input-text: var(--uitk-grey900);\n  --input-selection-background: var(--uitk-blue30Fade);\n}\n\n.uitk-dark .Input {\n  --input-text: var(--white);\n  --input-selection-background: var(--uitk-blue700Fade);\n}\n\n.Input {\n  align-items: center;\n  box-sizing: border-box;\n  color: var(--input-text);\n  cursor: text;\n  display: inline-flex;\n  letter-spacing: 0;\n  position: relative;\n}\n\n/* Reset in the next class */\n.Input-input:focus {\n  outline: none;\n}\n\n.Input-focused {\n  outline-color: var(--uitk-focus-outline-color);\n  outline-style: var(--uitk-focus-outline-style);\n  outline-width: var(--uitk-focus-outline-width);\n  outline-offset: var(--uitk-focus-outline-offset);\n}\n\n.Input-input {\n  background: none;\n  border: 0;\n  box-sizing: content-box;\n  color: inherit;\n  display: block;\n  flex: 1;\n  font: inherit;\n  letter-spacing: inherit;\n  margin: 0;\n  min-width: 0;\n  overflow: hidden;\n\n  padding: 0;\n  height: 100%;\n}\n\n.Input-input::selection {\n  background-color: var(--input-selection-background);\n}\n\n.Input-touchDensity {\n  font-size: var(---uitk-font-size-regular-touch);\n  min-height: var(--uitk-size-regular-touch);\n  padding: 0 var(--uitk-space-touch);\n}\n.Input-lowDensity {\n  font-size: var(--uitk-font-size-regular-low);\n  min-height: var(--uitk-size-regular-low);\n  padding: 0 var(--uitk-space-low);\n}\n.Input-mediumDensity {\n  font-size: var(--uitk-font-size-regular-medium);\n  min-height: var(--uitk-size-regular-medium);\n  padding: 0 var(--uitk-space-medium);\n}\n.Input-highDensity {\n  font-size: var(--uitk-font-size-regular-high);\n  min-height: var(--uitk-size-regular-high);\n  padding: 0 var(--uitk-space-high);\n}\n";
styleInject(css_248z$k);

var Input = /*#__PURE__*/React.forwardRef(function (_ref, ref) {
  var classNameProp = _ref.className,
      defaultValue = _ref.defaultValue,
      densityProp = _ref.density,
      inputProps = _ref.inputProps,
      style = _ref.style,
      valueProp = _ref.value,
      onBlur = _ref.onBlur,
      onChange = _ref.onChange,
      onFocus = _ref.onFocus,
      onKeyDown = _ref.onKeyDown;
  var density = useDensity(densityProp);

  var _React$useState = React__default['default'].useState(false),
      _React$useState2 = _slicedToArray(_React$useState, 2),
      focused = _React$useState2[0],
      setFocused = _React$useState2[1];

  var _useControlled = useControlled({
    controlled: valueProp,
    "default": defaultValue,
    name: "Input",
    state: "value"
  }),
      _useControlled2 = _slicedToArray(_useControlled, 3),
      value = _useControlled2[0],
      setValue = _useControlled2[1],
      isControlled = _useControlled2[2];

  var handleChange = function handleChange(evt) {
    var value = evt.target.value;

    if (!isControlled) {
      setValue(value);
    }

    onChange && onChange(evt, value);
  };

  var handleFocus = function handleFocus(event) {
    if (onFocus) {
      onFocus(event);
    } // formcontrol logic required


    setFocused(true);
  };

  var handleBlur = function handleBlur(event) {
    if (onBlur) {
      onBlur(event);
    } // formcontrol logic required


    setFocused(false);
  };

  var className = classnames__default['default']("Input", classNameProp, "Input-".concat(density, "Density"), {
    "Input-focused": focused
  });
  var inputClassName = classnames__default['default']("Input-input", inputProps === null || inputProps === void 0 ? void 0 : inputProps.className);
  return /*#__PURE__*/React__default['default'].createElement("div", {
    className: className,
    style: style
  }, /*#__PURE__*/React__default['default'].createElement("input", _extends({}, inputProps, {
    className: inputClassName,
    ref: ref,
    type: "text",
    value: value,
    onBlur: handleBlur,
    onChange: handleChange,
    onKeyDown: onKeyDown,
    onFocus: handleFocus
  })));
});

var dimensionsForDensity = {
  high: {
    width: 73,
    height: 15
  },
  medium: {
    width: 91,
    height: 19
  },
  low: {
    width: 102,
    height: 22
  },
  touch: {
    width: 109,
    height: 23
  }
};
var JPMorganLogo = /*#__PURE__*/React.forwardRef(function JPMorganLogo(_ref, ref) {
  var _ref$className = _ref.className,
      className = _ref$className === void 0 ? 'jpm-logo' : _ref$className,
      density = _ref.density,
      styleProp = _ref.style,
      rest = _objectWithoutProperties(_ref, ["className", "density", "style"]);

  var style = _objectSpread2(_objectSpread2({}, styleProp), {}, {
    marginTop: density === 'high' ? 1 : undefined
  });

  return /*#__PURE__*/React__default['default'].createElement("svg", _extends({
    className: className,
    role: "img",
    viewBox: "0 0 70.2 15.9"
  }, dimensionsForDensity[density], rest, {
    "aria-labelledby": "jpm-logo-graphic",
    ref: ref,
    style: style
  }), /*#__PURE__*/React__default['default'].createElement("title", {
    id: "jpm-logo-graphic"
  }, "J.P. Morgan"), /*#__PURE__*/React__default['default'].createElement("path", {
    className: "pfm-logo-base",
    d: "M 7 1.3 H 2.9 v 0.3 h 1.3 v 6.8 c 0 2 -0.6 2.6 -1.8 2.6 c -0.8 0 -0.9 -0.6 -0.9 -0.9 c 0 -0.7 0 -1.2 -0.7 -1.2 C 0.1 9 0 9.7 0 9.9 c 0 0.9 0.4 1.7 2.3 1.7 c 2.2 0 3.4 -0.7 3.4 -3.2 V 1.7 l 1.3 0 V 1.3 Z"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    className: "pfm-logo-base",
    d: "M 7.6 10 C 7.4 10 7.2 10 7 10.2 c -0.2 0.2 -0.2 0.3 -0.2 0.6 c 0 0.2 0.1 0.4 0.2 0.6 c 0.2 0.2 0.3 0.2 0.6 0.2 c 0.2 0 0.4 -0.1 0.6 -0.2 c 0.2 -0.1 0.2 -0.3 0.2 -0.6 c 0 -0.2 -0.1 -0.4 -0.2 -0.6 C 8 10 7.8 10 7.6 10"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    className: "pfm-logo-base",
    d: "M 16.7 10 c -0.2 0 -0.4 0.1 -0.6 0.2 c -0.2 0.2 -0.2 0.3 -0.2 0.6 c 0 0.2 0.1 0.4 0.2 0.6 c 0.2 0.2 0.4 0.2 0.6 0.2 c 0.2 0 0.4 -0.1 0.6 -0.2 c 0.2 -0.1 0.2 -0.3 0.2 -0.6 c 0 -0.2 -0.1 -0.4 -0.2 -0.6 C 17.1 10 16.9 10 16.7 10"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    className: "pfm-logo-base",
    d: "M 13.8 1.3 l -4 0 l 0 0.3 H 11 v 7.8 c 0 0.6 0 0.8 -0.1 0.9 c -0.1 0.2 -0.2 0.4 -0.5 0.5 C 10.2 10.9 9.9 11 9.6 11 v 0.3 h 4.3 V 11 c -0.4 0 -0.6 -0.1 -0.8 -0.1 c -0.3 -0.1 -0.4 -0.3 -0.5 -0.5 c -0.1 -0.2 -0.1 -0.3 -0.1 -0.6 V 7.1 l 1.1 0 c 3.1 0 4 -1.2 4 -2.9 C 17.5 2.5 17 1.3 13.8 1.3 M 13.3 6.7 h -0.8 v -5 l 0.7 0 c 2.4 0 2.9 1 2.9 2.6 C 16.1 5.9 15.2 6.7 13.3 6.7"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    className: "pfm-logo-base",
    d: "M 30.3 10.4 c -0.1 -0.2 -0.1 -0.4 -0.1 -0.7 v -8 c 0 0 1.1 0 1 0 c 0 0 0 -0.3 0 -0.3 h -2.5 c 0 0.1 -3 7.6 -3 7.6 c 0 0 0 0 -0.1 0 c 0 0 -0.1 0 -0.1 0 c 0 0 -3.2 -7.5 -3.2 -7.6 h -2.8 v 0.3 h 1.2 v 7.7 c 0 0 0 0.7 0 0.7 c 0 0.2 -0.1 0.3 -0.2 0.5 c -0.1 0.1 -0.3 0.3 -0.5 0.3 c -0.1 0 -0.3 0.1 -0.6 0.1 v 0.3 h 2.8 V 11 c -0.2 0 -0.3 0 -0.5 -0.1 c -0.2 -0.1 -0.4 -0.2 -0.5 -0.3 c -0.1 -0.1 -0.2 -0.3 -0.2 -0.5 c 0 0 0 -0.7 0 -0.7 V 2.7 h 0.2 c 0 0 3.6 8.5 3.7 8.6 h 0.3 l 3.4 -8.5 h 0.1 v 6.9 c 0 0.3 0 0.5 -0.1 0.7 c -0.1 0.2 -0.2 0.4 -0.4 0.5 c -0.2 0.1 -0.4 0.1 -0.7 0.1 v 0.3 h 3.9 V 11 c -0.3 0 -0.6 -0.1 -0.7 -0.1 C 30.5 10.7 30.4 10.6 30.3 10.4"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    className: "pfm-logo-base",
    d: "M 35.6 4 c -2.1 0 -3.4 1.4 -3.4 3.8 c 0 3.5 2.8 3.8 3.4 3.8 c 1.2 0 3.4 -0.7 3.4 -3.8 C 38.9 5.3 37.5 4 35.6 4 M 35.5 11.1 c -1.6 0 -1.8 -0.8 -1.8 -3.3 c 0 -1.9 0.1 -3.4 1.8 -3.4 c 1.8 0 1.8 1.5 1.8 3.3 C 37.4 10.3 36.9 11.1 35.5 11.1"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    className: "pfm-logo-base",
    d: "M 44.4 4.1 c -1.2 0 -1.6 0.7 -2 1.5 c 0 0 -0.1 0 -0.1 0 c 0 0 -0.2 -1.1 -0.2 -1.4 c -0.5 0 -2.4 0 -2.4 0 v 0.4 H 41 c 0 0 0 1.1 0 1.5 v 3.4 c 0 0.5 -0.1 0.8 -0.2 1 c -0.1 0.2 -0.4 0.4 -0.9 0.4 h -0.2 v 0.4 h 4.1 v -0.4 h -0.2 c -0.5 0 -0.8 -0.1 -0.9 -0.3 c -0.1 -0.2 -0.2 -0.5 -0.2 -1.1 V 6.9 c 0 -0.9 0.6 -1.8 1.4 -1.8 c 0.8 0 0.8 1.3 1.7 0.7 C 46 5.5 45.9 4.1 44.4 4.1"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    className: "pfm-logo-base",
    d: "M 60.5 10.6 c -0.4 0 -0.6 -0.2 -0.6 -0.6 c 0 0 0 -0.9 0 -0.9 V 6 c 0 -0.6 -0.1 -1.1 -0.5 -1.5 C 59.1 4.2 58.3 4 57.3 4 c -1 0 -1.7 0.2 -2.2 0.5 c -0.5 0.4 -0.6 0.7 -0.6 1.1 c 0 0.2 0.1 0.4 0.2 0.5 c 0.1 0.1 0.3 0.2 0.4 0.2 c 0.4 0 0.6 -0.2 0.7 -0.7 c 0.1 -0.4 0.1 -0.6 0.3 -0.8 c 0.2 -0.2 0.5 -0.3 1 -0.3 c 0.5 0 0.9 0.1 1.1 0.4 c 0.2 0.3 0.3 0.6 0.3 1 v 1.2 c -1.3 0.1 -4.4 0.4 -4.2 2.7 c 0.1 0.9 0.9 1.7 1.9 1.7 c 1.2 0 1.9 -0.7 2.4 -1.2 c 0.1 0.5 0.5 1.1 1.4 1.1 c 0.9 0 1.5 -0.5 1.6 -1.6 h -0.2 C 61.1 10.3 60.8 10.6 60.5 10.6 M 58.4 9.8 C 58.4 9.8 58.4 9.9 58.4 9.8 L 58.4 9.8 c -0.7 0.7 -1.3 0.9 -1.7 0.9 c -1 0 -1.1 -0.8 -1.1 -1.2 c 0 -1.3 1.8 -2 2.8 -2 V 9.8 Z"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    className: "pfm-logo-base",
    d: "M 53 3.7 c -0.2 0.1 -0.3 0.3 -0.4 0.6 c -0.1 0.3 -0.2 0.5 -0.3 0.5 c -0.1 0 -0.3 0 -0.5 0 C 51.4 4.4 50.7 4 49.5 4 c -2 0 -2.8 1.4 -2.8 2.7 c 0 1.5 0.6 2.2 1.8 2.5 c 0.1 0 0.1 0.1 0 0.1 c -1.1 0.2 -2 0.5 -2 1.6 c 0 0.6 0.4 1 0.8 1.1 c 0.5 0.2 1.2 0.3 2.1 0.3 c 0.8 0 1.3 0 1.7 0.1 c 0.4 0 0.7 0.2 0.9 0.3 c 0.2 0.2 0.4 0.4 0.4 0.8 c 0 0.5 -0.3 0.9 -0.8 1.1 c -0.5 0.3 -1.1 0.4 -1.9 0.4 c -0.7 0 -1.3 -0.1 -1.8 -0.4 c -0.4 -0.2 -0.5 -0.7 -0.4 -1 c 0.1 -0.3 0 -0.7 -0.4 -0.8 c -0.2 0 -0.5 0.1 -0.6 0.3 c -0.1 0.2 -0.2 0.4 -0.2 0.6 c 0 0.8 0.7 1.2 1.2 1.4 c 0.8 0.2 1.3 0.3 2 0.3 c 0.9 0 1.7 -0.1 2.2 -0.4 c 0.5 -0.3 0.9 -0.6 1.1 -1 c 0.2 -0.4 0.3 -0.8 0.3 -1.2 c 0 -0.5 -0.1 -0.9 -0.3 -1.2 c -0.7 -1 -1.7 -0.8 -4 -1 c -1.1 0 -1.3 -0.2 -1.3 -0.5 c 0 -0.5 0.4 -0.7 2 -0.9 c 1.5 -0.2 3 -0.8 3 -2.7 c 0 -0.5 -0.1 -1 -0.3 -1.3 c 0.3 0.1 0.6 0.1 0.9 0 c 0.3 -0.1 0.5 -0.3 0.6 -0.5 c 0.1 -0.2 0.1 -0.4 0.1 -0.6 C 53.6 3.7 53.4 3.6 53 3.7 M 49.5 8.9 c -0.9 0 -1.4 -0.3 -1.4 -2.2 c 0 -1.3 0.5 -2.3 1.4 -2.3 c 1.1 0 1.5 0.9 1.5 2.3 C 51 8.6 50.4 8.9 49.5 8.9"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    className: "pfm-logo-base",
    d: "M 68.8 10.5 c -0.1 -0.2 -0.3 -0.5 -0.3 -1.1 l 0 -3.2 c 0 -0.5 -0.1 -0.9 -0.2 -1.2 c -0.2 -0.3 -0.4 -0.6 -0.7 -0.7 c -0.3 -0.2 -0.7 -0.2 -1.1 -0.2 c -1.4 0 -2 0.9 -2.3 1.4 l -0.1 0 l -0.3 -1.3 l -2.2 0 v 0.4 c 0.4 0 1.1 0 1.1 0 v 4.9 c 0 0.4 0 0.7 -0.1 0.8 c -0.1 0.2 -0.2 0.4 -0.4 0.5 c -0.1 0.1 -0.3 0.1 -0.6 0.1 v 0.4 h 3.5 v -0.5 c -0.4 0 -0.6 -0.1 -0.7 -0.3 c -0.1 -0.2 -0.2 -0.5 -0.2 -1 V 7.6 c 0 -0.8 0 -1.5 0.3 -2 c 0.3 -0.5 0.8 -0.8 1.4 -0.8 c 0.5 0 0.8 0.2 1 0.5 c 0.1 0.3 0.2 1.1 0.2 1.7 l 0 2.3 c 0 0.4 0 0.7 0 0.9 c 0 0.2 -0.1 0.4 -0.3 0.5 c -0.1 0.1 -0.3 0.1 -0.6 0.1 v 0.5 h 3.4 v -0.4 C 69.2 10.8 69 10.7 68.8 10.5"
  }));
});
JPMorganLogo.propTypes = {
  className: PropTypes__default['default'].string,
  density: PropTypes__default['default'].oneOf(['touch', 'low', 'medium', 'high']),
  style: PropTypes__default['default'].objectOf(PropTypes__default['default'].oneOfType([PropTypes__default['default'].string, PropTypes__default['default'].number]))
};

var dimensionsForDensity$1 = {
  high: {
    width: 63,
    height: 12
  },
  medium: {
    width: 84,
    height: 17.5
  },
  low: {
    width: 95,
    height: 18
  },
  touch: {
    width: 95,
    height: 18
  }
};
var ChaseLogo = /*#__PURE__*/React.forwardRef(function ChaseLogo(_ref, ref) {
  var _ref$className = _ref.className,
      className = _ref$className === void 0 ? 'chase-logo' : _ref$className,
      density = _ref.density,
      rest = _objectWithoutProperties(_ref, ["className", "density"]);

  return /*#__PURE__*/React__default['default'].createElement("svg", _extends({
    className: className,
    role: "img",
    viewBox: "0 0 62.626 11.639",
    x: "0px",
    y: "0px"
  }, dimensionsForDensity$1[density], rest, {
    "aria-labelledby": "chase-logo-graphic",
    ref: ref
  }), /*#__PURE__*/React__default['default'].createElement("title", {
    id: "chase-logo-graphic"
  }, "CHASE"), /*#__PURE__*/React__default['default'].createElement("g", null, /*#__PURE__*/React__default['default'].createElement("g", null, /*#__PURE__*/React__default['default'].createElement("path", {
    d: "M55.147,0c-0.227,0-0.41,0.184-0.41,0.411v2.881h7.609L58.882,0L55.147,0z"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    d: "M62.626,4.163c0-0.227-0.184-0.411-0.412-0.411h-2.879v7.61l3.289-3.467L62.626,4.163z"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    d: "M58.462,11.639c0.227,0,0.41-0.184,0.41-0.411v-2.88h-7.611l3.467,3.291L58.462,11.639z"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    d: "M50.983,7.476c0,0.227,0.184,0.412,0.41,0.412h2.881v-7.61l-3.291,3.466V7.476z"
  })), /*#__PURE__*/React__default['default'].createElement("g", null, /*#__PURE__*/React__default['default'].createElement("polygon", {
    points: "16.101,1.389 16.101,4.903 11.204,4.903 11.204,1.389 9.421,1.388 9.421,10.25 11.204,10.25 11.204,6.442 16.101,6.442 16.101,10.25 17.887,10.25 17.887,1.389 \t\t"
  }), /*#__PURE__*/React__default['default'].createElement("polygon", {
    points: "39.826,1.389 39.826,10.247 47.65,10.247 46.659,8.688 41.615,8.688 41.615,6.442 46.498,6.442 46.498,4.94 41.615,4.94 41.615,2.912 46.651,2.912 47.622,1.389 \t\t"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    d: "M2.792,1.387C0.936,1.387,0,2.515,0,4.156v3.308c0,1.899,1.207,2.786,2.783,2.786l5.595-0.001 l-1.037-1.62H3.128c-0.895,0-1.284-0.323-1.284-1.325V4.303c0-0.968,0.328-1.346,1.308-1.346h4.232l0.996-1.57H2.792z"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    d: "M32,1.385c-1.072,0-2.169,0.644-2.169,2.301v0.425c0,1.726,1.057,2.385,2.113,2.39h3.711 c0.386,0,0.699,0.064,0.699,0.715l0,0.753c-0.01,0.584-0.302,0.719-0.711,0.719H30.76l-1,1.559h5.996 c1.446,0,2.428-0.719,2.428-2.381v-0.61c0-1.607-0.912-2.366-2.326-2.366h-3.543c-0.393,0-0.666-0.107-0.666-0.689 c0-0.001,0-0.613,0-0.613c0-0.496,0.188-0.676,0.646-0.676l4.648-0.002l0.972-1.527L32,1.385z"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    d: "M23.949,3.229l1.615,3.683h-3.22L23.949,3.229z M23.069,1.39l-4.202,8.859h1.986l0.818-1.83h4.566 l0.815,1.83h1.994L24.835,1.39H23.069z"
  }))));
});
ChaseLogo.propTypes = {
  className: PropTypes__default['default'].string,
  density: PropTypes__default['default'].oneOf(['touch', 'low', 'medium', 'high'])
};

var dimensionsForDensity$2 = {
  high: {
    width: 29,
    height: 10
  },
  medium: {
    width: 34,
    height: 12
  },
  low: {
    width: 41,
    height: 14
  },
  touch: {
    width: 46,
    height: 16
  }
};
var JPMCompactLogo = /*#__PURE__*/React.forwardRef(function JPMCompactLogo(_ref, ref) {
  var density = _ref.density,
      rest = _objectWithoutProperties(_ref, ["density"]);

  return /*#__PURE__*/React__default['default'].createElement("svg", _extends({
    role: "img",
    viewBox: "0 0 890 326"
  }, dimensionsForDensity$2[density], rest, {
    "aria-labelledby": "jpm-compact-logo-graphic",
    ref: ref
  }), /*#__PURE__*/React__default['default'].createElement("title", {
    id: "jpm-compact-logo-graphic"
  }, "J.P. Morgan"), /*#__PURE__*/React__default['default'].createElement("path", {
    d: "M223.4,0.9 L93.1,0.9 L93.1,12 L134.6,12 L134.6,228.2 C134.6,293.2 116.6,311.5 76.4,311.5 C51.1,311.5 47,292.3 47,282.4 C47,258.8 45.7,244.3 24.2,244.3 C2.7,244.3 0,266.1 0,272.8 C0,302.6 13.2,325.3 72.4,325.3 C142.9,325.3 180.6,301.5 180.6,222.5 L180.6,11.9 L223.4,12 L223.4,0.9 Z",
    id: "Path"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    d: "M378.4,0.9 L250.9,0.9 L250.9,12 L288.4,12 L288.4,258.6 C288.4,278 287.2,283 285,288.6 C282.7,294.9 277.4,299.8 269.7,303 C263.9,305.5 255.2,306.7 243.5,307 L243.5,317.2 L380.8,317.2 L380.8,307.2 C369.2,306.9 360.3,305.6 354.5,303.5 C346.3,300.3 341,295.5 338.4,289 C336.1,283.5 334.9,278.6 334.9,268.8 L334.9,184.3 L368.9,184.2 C467.6,184.2 495.3,145.3 495.3,92.1 C495.3,38.5 478.3,0.9 378.4,0.9 M361,172.2 L334.9,172.2 L334.9,13.4 L358.5,13.1 C434.6,13.1 451.2,44.4 451.2,95.1 C451.3,146.1 421.4,172.2 361,172.2",
    id: "Shape"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    d: "M853.2,287.8 C851.4,282.1 850.5,275.2 850.5,266.3 L850.5,12 C850.5,12 884,11.8 883.6,11.7 C883.2,11.6 883.6,1.6 883.6,1.6 L802.6,1.6 C801.5,4.5 705.9,242.7 705.9,242.7 C705.5,243.6 704.7,244.1 703.7,244.1 C702.7,244.2 701.8,243.6 701.4,242.7 C701.4,242.7 599.6,4.6 598.4,1.6 L508.5,1.6 L508.5,11.8 L547.5,11.8 L547.5,256.7 L546.6,279 C546.1,284.5 544.3,289.7 541.3,294.3 C538.3,298.8 533.3,302.3 526.9,304.6 C522.6,306 516.3,306.9 508.5,307.1 L508.5,317.3 L597.7,317.3 L597.7,307.3 C590.1,307 586.8,306.2 582.4,304.8 C575.9,302.7 570.9,299.4 567.7,294.8 C564.6,290.1 562.8,284.7 562.3,279.1 C562.3,279.1 561.3,256.8 561.3,256.8 L561.3,45.2 L566.5,45.2 C566.5,45.2 681.8,314.4 683,317.3 L692.6,317.3 L801.8,48.2 L804.6,48.2 L804.6,266.3 C804.6,275.6 803.6,282.8 801.8,288.4 C799.7,294.9 795,299.9 788.3,303.2 C783.3,305.4 775.7,306.7 765.6,307.1 L765.6,317.3 L890,317.3 L890,307.1 C880.1,306.6 872.4,305.3 867.2,302.9 C859.9,299.4 855.2,294.3 853.2,287.8",
    id: "Path"
  }));
});
JPMCompactLogo.propTypes = {
  className: PropTypes__default['default'].string,
  density: PropTypes__default['default'].oneOf(['touch', 'low', 'medium', 'high'])
};

var dimensionsForDensity$3 = {
  high: {
    width: 13,
    height: 12
  },
  medium: {
    width: 17,
    height: 18
  },
  low: {
    width: 19,
    height: 18
  },
  touch: {
    width: 21,
    height: 20
  }
};
var ChaseCompactLogo = /*#__PURE__*/React.forwardRef(function ChaseCompactLogo(_ref, ref) {
  var _ref$className = _ref.className,
      className = _ref$className === void 0 ? 'chase-logo' : _ref$className,
      density = _ref.density,
      rest = _objectWithoutProperties(_ref, ["className", "density"]);

  return /*#__PURE__*/React__default['default'].createElement("svg", _extends({
    className: className,
    role: "img",
    viewBox: "0 0 1020 1025",
    x: "0px",
    y: "0px"
  }, dimensionsForDensity$3[density], rest, {
    "aria-labelledby": "chase-compact-logo-graphic",
    ref: ref
  }), /*#__PURE__*/React__default['default'].createElement("title", {
    id: "chase-compact-logo-graphic"
  }, "CHASE"), /*#__PURE__*/React__default['default'].createElement("g", null, /*#__PURE__*/React__default['default'].createElement("path", {
    d: "M384,71c-17.3,0-31.4,14-31.4,31.4v220h581.1L669.1,71L384,71z"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    d: "M955,388.9c0-17.3-14-31.4-31.4-31.4H703.7v581.1l251.2-264.7L955,388.9z"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    d: "M637,959.7c17.3,0,31.3-14,31.3-31.4V708.4H87.2l264.6,251.3L637,959.7z"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    d: "M66,641.9c0,17.3,14.1,31.4,31.4,31.4h220V92.2L66,356.8L66,641.9z"
  })));
});
ChaseCompactLogo.propTypes = {
  className: PropTypes__default['default'].string,
  density: PropTypes__default['default'].oneOf(['touch', 'low', 'medium', 'high'])
};

var css_248z$l = ".uitk-light .Logo {\n  --logo-color: var(--uitk-grey300);\n  --logo-pipe-color: var(--uitk-grey60);\n}\n\n.uitk-dark .Logo {\n  --logo-color: var(--uitk-grey70);\n  --logo-pipe-color: var(--uitk-grey400);\n}\n\n.Logo {\n  display: inline-flex;\n  position: relative;\n  align-items: center;\n  justify-content: center;\n}\n\n.Logo-wrapper {\n  display: inline-flex;\n}\n\n.Logo-logo {\n  fill: var(--logo-color);\n  margin: auto;\n  stroke: none !important;\n  text-align: center;\n}\n\n.Logo-appTitle {\n  align-self: center;\n  color: var(--logo-color);\n  position: relative;\n}\n\n.Logo-touchDensity {\n  font-size: var(typography-size-touch);\n}\n.Logo-lowDensity {\n  font-size: var(typography-size-low);\n}\n.Logo-mediumDensity {\n  font-size: var(typography-size-medium);\n}\n.Logo-highDensity {\n  font-size: var(typography-size-high);\n}\n\n.Logo-titlePipe {\n  height: 100%;\n  border-right: 1px solid var(--logo-pipe-color);\n}\n\n.Logo-touchDensity .Logo-titlePipe {\n  height: 18px;\n  margin: 0 calc(var(--uitk-space-touch) * 2);\n}\n.Logo-lowDensity .Logo-titlePipe {\n  height: 16px;\n  margin: 0 calc(var(--uitk-space-low) * 2);\n}\n.Logo-mediumDensity .Logo-titlePipe {\n  height: 14px;\n  margin: 0 calc(var(--uitk-space-medium) * 2);\n}\n.Logo-highDensity .Logo-titlePipe {\n  height: 12px;\n  margin: 0 calc(var(--uitk-space-high) * 2);\n}\n";
styleInject(css_248z$l);

function isCompactVariant(variant) {
  return variant.indexOf("compact") !== -1;
}

var FirmLogo = /*#__PURE__*/React.forwardRef(function FirmLogo(_ref, ref) {
  var variant = _ref.variant,
      rest = _objectWithoutProperties(_ref, ["variant"]);

  switch (variant) {
    case "jpm":
    case "J.P. Morgan":
      return /*#__PURE__*/React__default['default'].createElement(JPMorganLogo, _extends({}, rest, {
        ref: ref
      }));

    case "jpm-compact":
      return /*#__PURE__*/React__default['default'].createElement(JPMCompactLogo, _extends({}, rest, {
        ref: ref
      }));

    case "chase":
    case "CHASE":
      return /*#__PURE__*/React__default['default'].createElement(ChaseLogo, _extends({}, rest, {
        ref: ref
      }));

    case "chase-compact":
      return /*#__PURE__*/React__default['default'].createElement(ChaseCompactLogo, _extends({}, rest, {
        ref: ref
      }));

    default:
      return /*#__PURE__*/React__default['default'].createElement(JPMorganLogo, _extends({}, rest, {
        ref: ref
      }));
  }
});
FirmLogo.propTypes = {
  variant: PropTypes__default['default'].string
};
var RenderedLogo = /*#__PURE__*/React.forwardRef(function RenderedLogo(_ref2, ref) {
  var alt = _ref2.alt,
      defaultClassName = _ref2.defaultClassName,
      densityClassName = _ref2.densityClassName,
      density = _ref2.density,
      width = _ref2.width,
      height = _ref2.height,
      src = _ref2.src,
      variant = _ref2.variant,
      rest = _objectWithoutProperties(_ref2, ["alt", "defaultClassName", "densityClassName", "density", "width", "height", "src", "variant"]);

  var mergedStyle = _objectSpread2(_objectSpread2({}, rest.style), {}, {
    width: width,
    height: height
  });

  var logoClassNames = classnames__default['default'](defaultClassName, rest.className, densityClassName);
  var LogoElement = src ? "img" : FirmLogo;
  var elementProps = src ? {
    alt: alt || "Logo"
  } : {
    variant: variant
  };
  return /*#__PURE__*/React__default['default'].createElement(LogoElement, _extends({}, rest, {
    className: logoClassNames,
    density: density,
    src: src,
    style: mergedStyle
  }, elementProps, {
    ref: ref
  }));
});
RenderedLogo.propTypes = {
  alt: PropTypes__default['default'].string,
  defaultClassName: PropTypes__default['default'].string,
  density: PropTypes__default['default'].oneOf(["touch", "low", "medium", "high"]),
  densityClassName: PropTypes__default['default'].string,
  height: PropTypes__default['default'].number,
  src: PropTypes__default['default'].string,
  variant: PropTypes__default['default'].string,
  width: PropTypes__default['default'].number
};
var Title = /*#__PURE__*/React.forwardRef(function Title(_ref3, ref) {
  var label = _ref3.label,
      defaultClassName = _ref3.defaultClassName,
      className = _ref3.className,
      separatorClassname = _ref3.separatorClassname,
      rest = _objectWithoutProperties(_ref3, ["label", "defaultClassName", "className", "separatorClassname"]);

  var titleClassNames = classnames__default['default'](defaultClassName, className);
  return label ? /*#__PURE__*/React__default['default'].createElement(React__default['default'].Fragment, null, /*#__PURE__*/React__default['default'].createElement("span", {
    className: separatorClassname
  }), /*#__PURE__*/React__default['default'].createElement("span", _extends({
    className: titleClassNames
  }, rest, {
    ref: ref
  }), /*#__PURE__*/React__default['default'].createElement("span", null, label))) : null;
});
Title.propTypes = {
  className: PropTypes__default['default'].string,
  defaultClassName: PropTypes__default['default'].string,
  label: PropTypes__default['default'].string,
  separatorClassname: PropTypes__default['default'].string
};
var Logo = /*#__PURE__*/React.forwardRef(function Logo(props, ref) {
  var contextDensity = useDensity();

  var appTitle = props.appTitle,
      className = props.className,
      _props$density = props.density,
      density = _props$density === void 0 ? contextDensity : _props$density,
      height = props.height,
      src = props.src,
      _props$variant = props.variant,
      variant = _props$variant === void 0 ? "jpm" : _props$variant,
      width = props.width,
      ImageProps = props.ImageProps,
      TitleProps = props.TitleProps,
      rest = _objectWithoutProperties(props, ["appTitle", "className", "density", "height", "src", "variant", "width", "ImageProps", "TitleProps"]);

  var densityClassName = "Logo-".concat(density, "Density");
  return /*#__PURE__*/React__default['default'].createElement("span", _extends({
    className: classnames__default['default']("Logo", className, densityClassName),
    ref: ref,
    style: {
      height: height
    }
  }, rest), /*#__PURE__*/React__default['default'].createElement("span", {
    className: "Logo-wrapper",
    style: {
      height: height
    }
  }, /*#__PURE__*/React__default['default'].createElement(RenderedLogo, _extends({
    defaultClassName: "Logo-logo",
    density: density,
    height: height,
    src: src,
    variant: variant,
    width: width
  }, ImageProps))), /*#__PURE__*/React__default['default'].createElement(Title, _extends({
    defaultClassName: "Logo-appTitle",
    height: height,
    label: appTitle,
    separatorClassname: classnames__default['default']("Logo-titlePipe", {
      "Logo-compact": isCompactVariant(variant)
    })
  }, TitleProps)));
});
Logo.propTypes = {
  /**
   * props passed to the Logo
   */
  ImageProps: PropTypes__default['default'].objectOf(PropTypes__default['default'].any),

  /**
   * props passed to the Application Title if used.
   * If using a custom image then ImageProps.alt should be set to include a screen reader alternative text
   */
  TitleProps: PropTypes__default['default'].objectOf(PropTypes__default['default'].any),

  /**
   * used to provide application title
   */
  appTitle: PropTypes__default['default'].string,

  /**
   * The className(s) of the component
   */
  className: PropTypes__default['default'].string,

  /**
   * @external - material-ui
   * Override or extend the styles applied to the component.
   */
  classes: PropTypes__default['default'].objectOf(PropTypes__default['default'].string),

  /**
   * The density of a component affects the style of the layout.
   * A high density component uses minimal sizing and spacing to convey the intended UI design.
   * Conversely, a low density component, maximizes the use of space and size to convey the UI Design.
   */
  density: PropTypes__default['default'].oneOf(["touch", "low", "medium", "high"]),

  /**
   * prop to set height on logo element
   */
  height: PropTypes__default['default'].number,

  /**
   * set custom image for logo
   */
  src: PropTypes__default['default'].string,

  /**
   * set the firm svg. Use `jpm`, `jpm-compact`, `chase` or `chase-compact`. Defaults to `jpm`.
   */
  variant: function (validator) {
    var hasWarnedForJpm = false;
    var hasWarnedForChase = false;
    return function (props, propName) {
      var value = props[propName];

      if (value === "J.P. Morgan") {
        warning__default['default'](hasWarnedForJpm, "The variant `J.P. Morgan` is deprecated. Please use `jpm` instead.");
        hasWarnedForJpm = true;
      }

      if (value === "CHASE") {
        warning__default['default'](hasWarnedForChase, "The variant `CHASE` is deprecated. Please use `chase` instead.");
        hasWarnedForChase = true;
      }

      for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
        args[_key - 2] = arguments[_key];
      }

      return validator.apply(void 0, [props, propName].concat(args));
    };
  }(PropTypes__default['default'].oneOf(["J.P. Morgan", "CHASE", "jpm", "jpm-compact", "chase", "chase-compact"])),

  /**
   * prop to set width on logo element
   */
  width: PropTypes__default['default'].number
};

var _icons$1;
var State$1 = {
  error: "error",
  success: "success",
  warning: "warning"
};
var icons$1 = (_icons$1 = {}, _defineProperty(_icons$1, State$1.error, "error"), _defineProperty(_icons$1, State$1.success, "tick"), _defineProperty(_icons$1, State$1.warning, "warning"), _icons$1);
function getIconForState(state) {
  var StateIcon = function StateIcon(props) {
    return icons$1[state] ? /*#__PURE__*/React__default['default'].createElement(Icon, _extends({
      name: icons$1[state]
    }, props)) : null;
  };

  return state ? StateIcon : null;
}

var css_248z$m = ".uitk-light .Tooltip {\n  --tooltip-background: var(--white);\n  --tooltip-color: var(--uitk-grey900);\n}\n\n.uitk-dark {\n  --tooltip-background: var(--uitk-grey800);\n  --tooltip-color: var(--white);\n}\n\n.Tooltip-touchDensity {\n  --icon-top: 6px;\n  --tooltip-font-size: var(--uitk-font-size-regular-touch);\n  --tooltip-padding: var(--uitk-space-touch);\n}\n\n.Tooltip-lowDensity {\n  --icon-top: 4px;\n  --tooltip-font-size: var(--uitk-font-size-regular-low);\n  --tooltip-padding: var(--uitk-space-low);\n}\n\n.Tooltip-mediumDensity {\n  --icon-top: 1px;\n  --tooltip-font-size: var(--uitk-font-size-regular-medium);\n  --tooltip-padding: var(--uitk-space-medium);\n}\n\n.Tooltip-highDensity {\n  --icon-top: 1px;\n  --tooltip-font-size: var(--uitk-font-size-regular-high);\n  --tooltip-padding: var(--uitk-space-high);\n}\n\n.Tooltip {\n  background: var(--tooltip-background);\n  border: 1px solid var(--tooltip-status-color);\n  box-shadow: var(--uitk-shadow-black-4);\n  color: var(--tooltip-color);\n  font-size: var(--tooltip-font-size);\n  line-height: var(--uitk-line-height);\n  min-height: calc(var(--uitk-font-size) * var(--uitk-line-height));\n  padding: var(--tooltip-padding);\n  position: relative;\n  max-width: 230px;\n  text-align: left;\n}\n\n.Tooltip-content {\n  display: flex;\n  position: relative;\n}\n\n.Tooltip-body {\n  overflow: hidden;\n}\n\n.Tooltip-icon {\n  color: var(--tooltip-status-color);\n  margin-right: 6px;\n  top: var(--icon-top);\n  vertical-align: top;\n}\n\n.Tooltip-arrow {\n  border: solid 5px transparent;\n  box-sizing: border-box;\n  position: absolute;\n}\n\n.Tooltip-arrow:after {\n  border: 5px solid transparent;\n  content: '';\n  position: absolute;\n}\n\n.Tooltip-info {\n  --tooltip-status-color: var(--uitk-status-info-color);\n  box-shadow: var(--uitk-shadow-blue-4);\n}\n.Tooltip-error {\n  --tooltip-status-color: var(--uitk-status-error-color);\n}\n.Tooltip-warning {\n  --tooltip-status-color: var(--uitk-status-warning-color);\n}\n.Tooltip-success {\n  --tooltip-status-color: var(--uitk-status-success-color);\n}\n\n.Tooltip-top {\n  margin-bottom: 8px;\n}\n\n.Tooltip-right {\n  margin-left: 8px;\n}\n.Tooltip-bottom {\n  margin-top: 8px;\n}\n.Tooltip-left {\n  margin-right: 8px;\n}\n\n.Tooltip-top .Tooltip-arrow {\n  border-top-color: var(--tooltip-status-color);\n  bottom: -11px;\n  left: calc(50% - 5px);\n}\n\n.Tooltip-top .Tooltip-arrow:after {\n  border-bottom-width: 5px;\n  border-top-color: var(--white);\n  bottom: -4px;\n  left: calc(50% - 5px);\n}\n\n.Tooltip-right .Tooltip-arrow {\n  border-right-color: var(--tooltip-status-color);\n  left: -11px;\n  top: calc(50% - 5px);\n}\n\n.Tooltip-right .Tooltip-arrow:after {\n  top: calc(50% - 5px);\n  left: -4px;\n  border-left-width: 5px;\n  border-right-color: #ffffff;\n}\n\n.Tooltip-bottom .Tooltip-arrow {\n  border-bottom-color: var(--tooltip-status-color);\n  left: calc(50% - 5px);\n  top: -11px;\n}\n\n.Tooltip-bottom .Tooltip-arrow:after {\n  border-bottom-color: var(--white);\n  border-top-width: 5px;\n  left: calc(50% - 5px);\n  top: -4px;\n}\n\n.Tooltip-left .Tooltip-arrow {\n  border-left-color: var(--tooltip-status-color);\n  right: -11px;\n  top: calc(50% - 5px);\n}\n.Tooltip-left .Tooltip-arrow:after {\n  border-right-width: 5px;\n  border-left-color: #ffffff;\n  right: -4px;\n  top: calc(50% - 5px);\n}\n";
styleInject(css_248z$m);

var defaultIconProps = {
  size: 12,
  className: 'Tooltip-icon'
}; // TODO: Fix types

var Tooltip = /*#__PURE__*/React.forwardRef(function Tooltip(_ref, ref) {
  var accessibleText = _ref.accessibleText,
      children = _ref.children,
      densityProp = _ref.density,
      hideArrow = _ref.hideArrow,
      hideIcon = _ref.hideIcon,
      open = _ref.open,
      _ref$placement = _ref.placement,
      placement = _ref$placement === void 0 ? 'right' : _ref$placement,
      render = _ref.render,
      _ref$size = _ref.size,
      size = _ref$size === void 0 ? 'medium' : _ref$size,
      _ref$state = _ref.state,
      state = _ref$state === void 0 ? 'info' : _ref$state,
      title = _ref.title,
      rest = _objectWithoutProperties(_ref, ["accessibleText", "children", "className", "density", "hideArrow", "hideIcon", "open", "placement", "render", "size", "state", "title"]);

  var density = useDensity(densityProp);

  var _React$useState = React__default['default'].useState(null),
      _React$useState2 = _slicedToArray(_React$useState, 2),
      childNode = _React$useState2[0],
      setChildNode = _React$useState2[1];

  var getIcon = React.useCallback(function (iconProps) {
    if (hideIcon) {
      return null;
    }

    var StateIcon = getIconForState(state);
    return StateIcon ? /*#__PURE__*/React__default['default'].createElement(StateIcon, _extends({}, iconProps, defaultIconProps)) : null;
  }, [state, hideIcon]);
  var getTitleProps = React.useCallback(function () {
    var _ref2 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
        titleClassName = _ref2.className,
        titleRest = _objectWithoutProperties(_ref2, ["className"]);

    return _objectSpread2({
      className: classnames__default['default'](titleClassName)
    }, titleRest);
  }, []);
  var className = classnames__default['default']('Tooltip', "Tooltip-".concat(state), "Tooltip-".concat(placement), "Tooltip-".concat(size), "Tooltip-".concat(density, "Density"));

  var childrenProps = _objectSpread2(_objectSpread2({}, children === null || children === void 0 ? void 0 : children.props), {}, {
    ref: setChildNode
  });

  return /*#__PURE__*/React__default['default'].createElement(React__default['default'].Fragment, null, /*#__PURE__*/React__default['default'].cloneElement(children, childrenProps), /*#__PURE__*/React__default['default'].createElement(Popper, {
    anchorEl: childNode,
    className: "uitk-light",
    open: open,
    placement: placement,
    role: "tooltip"
  }, /*#__PURE__*/React__default['default'].createElement("div", _extends({
    className: className // TODO: Check whether placement is needed for div. Changed from `placement` to `data-placement`.
    ,
    "data-placement": placement,
    ref: ref
  }, rest), /*#__PURE__*/React__default['default'].createElement("div", {
    className: classnames__default['default']('Tooltip-content', {// [classes.stateIconContainer]: state,
    })
  }, render ? render({
    Icon: function Icon(passedProps) {
      return getIcon(passedProps);
    },
    getIconProps: function getIconProps() {
      return defaultIconProps;
    },
    getTitleProps: getTitleProps
  }) : /*#__PURE__*/React__default['default'].createElement(React__default['default'].Fragment, null, getIcon({}), /*#__PURE__*/React__default['default'].createElement("span", {
    className: "Tooltip-body"
  }, title), /*#__PURE__*/React__default['default'].createElement("span", null, accessibleText))), !hideArrow && /*#__PURE__*/React__default['default'].createElement("div", {
    className: "Tooltip-arrow",
    "x-arrow": ""
  }))));
});

var DeleteButton = function DeleteButton(props) {
  var disabled = props.disabled,
      active = props.active,
      restProps = _objectWithoutProperties(props, ["disabled", "active"]);

  return /*#__PURE__*/React__default['default'].createElement(Button, _extends({
    "aria-label": "delete pill",
    className: classnames__default['default']('Pill-deleteButton', {
      'Pill-deleteButton-disabled': disabled,
      'Pill-deleteButton-active': active
    }),
    disabled: disabled,
    onMouseEnter: function onMouseEnter(event) {
      return event.stopPropagation();
    },
    tabIndex: -1,
    variant: "secondary"
  }, restProps), /*#__PURE__*/React__default['default'].createElement(Icon, {
    className: "Pill-deleteIcon",
    name: "close-small"
  }));
};

var css_248z$n = ".uitk-light .Pill {\n  --pill-background: var(--uitk-grey40);\n  --pill-color: var(--uitk-grey900);\n  --pill-active-background: var(--uitk-grey200);\n  --pill-active-color: var(--white);\n  --pill-icon-color: var(--uitk-grey300);\n}\n\n.uitk-dark .Pill {\n  --pill-background: var(--uitk-grey80);\n  --pill-color: var(--white);\n  --pill-active-background: var(--uitk-grey80);\n  --pill-active-color: var(--uitk-grey900);\n  --pill-icon-color: var(--uitk-grey60);\n}\n\n.Pill-touchDensity {\n  --font-size: var(--uitk-font-size-50);\n  --checkbox-size: calc(var(--uitk-size-icon-small) + 6px);\n  --delete-left: 4px;\n  --padding: calc(var(--uitk-space-touch) * 0.75);\n  --uitk-space: calc(var(--uitk-space-touch) * 0.5);\n}\n.Pill-lowDensity {\n  --font-size: var(--uitk-font-size-40);\n  --checkbox-size: calc(var(--uitk-size-icon-small) + 4px);\n  --delete-left: 3px;\n  --padding: calc(var(--uitk-space-low) * 0.75);\n  --uitk-space: calc(var(--uitk-space-low) * 0.5);\n}\n.Pill-mediumDensity {\n  --font-size: var(--uitk-font-size-40);\n  --checkbox-size: calc(var(--uitk-size-icon-small) + 2px);\n  --delete-left: 2px;\n  --padding: calc(var(--uitk-space-medium) * 0.75);\n  --uitk-space: calc(var(--uitk-space-medium) * 0.5);\n}\n.Pill-highDensity {\n  --font-size: var(--uitk-font-size-30);\n  --checkbox-size: var(--uitk-size-icon-small);\n  --delete-left: 1px;\n  --padding: calc(var(--uitk-space-high) * 0.75);\n  --uitk-space: calc(var(--uitk-space-high) * 0.5);\n}\n\n.Pill {\n  align-items: center;\n  background: var(--pill-background);\n  color: var(--pill-color);\n  display: inline-flex;\n  font-size: var(--font-size);\n  /* TODO: Check whether we should define font family here or rely on theme */\n  font-family: var(--uitk-font-family);\n  height: calc(var(--checkbox-size) + 2px);\n  letter-spacing: 0;\n  line-height: var(--uitk-line-height);\n  max-width: 160px;\n  min-width: 40px;\n  position: relative;\n  outline: 0;\n}\n\n.Pill-label {\n  flex-grow: 1;\n  line-height: calc(var(--checkbox-size) + 2px);\n  padding: 0 var(--padding);\n  overflow: hidden;\n  pointer-events: none;\n  text-align: center;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.Pill-clickable {\n  cursor: pointer;\n  user-select: none;\n}\n\n.Pill-deletable .Pill-label {\n  padding-right: 0;\n}\n\n.Pill:not(.Pill-deletable):not(.Pill-selectable):active {\n  background: var(--pill-active-background);\n  color: var(--pill-active-color);\n}\n\n.Pill-checkbox {\n  height: var(--checkbox-size);\n  margin-left: 1px;\n  padding-right: 0;\n  width: var(--checkbox-size);\n}\n\n.Pill-deleteButton {\n  height: calc(var(--checkbox-size) + 2px);\n  margin-left: var(--uitk-space);\n  padding-left: 0;\n  padding-right: var(--uitk-space);\n  width: calc(var(--checkbox-size) + 2px);\n}\n\n.Pill-icon {\n  color: var(--icon-color);\n  margin-left: var(--padding);\n  margin-right: var(--uitk-space);\n}\n\n.Pill-deleteIcon {\n  left: var(--delete-left);\n  position: relative;\n}\n";
styleInject(css_248z$n);

var useEllipsisIsActive = function useEllipsisIsActive() {
  var labelRef = React.useRef(null);

  var _useState = React.useState(false),
      _useState2 = _slicedToArray(_useState, 2),
      showEllipsis = _useState2[0],
      setShowEllipsis = _useState2[1];

  React.useLayoutEffect(function () {
    var _labelRef$current;

    if (labelRef.current && (_labelRef$current = labelRef.current) !== null && _labelRef$current !== void 0 && _labelRef$current.parentElement) {
      setShowEllipsis(labelRef.current.parentElement.offsetWidth < labelRef.current.parentElement.scrollWidth);
    }
  }, []);
  return [labelRef, showEllipsis];
};

var PillBase = /*#__PURE__*/React.forwardRef(function PillBase(props, ref) {
  var label = props.label,
      classNameProp = props.className,
      clickableProp = props.clickable,
      disabled = props.disabled,
      deletableProp = props.deletable,
      deleteIcon = props.deleteIcon,
      icon = props.icon,
      onDelete = props.onDelete,
      onClick = props.onClick,
      rest = _objectWithoutProperties(props, ["label", "className", "clickable", "disabled", "deletable", "deleteIcon", "icon", "onDelete", "onClick", "onKeyDown", "onKeyUp"]);

  var _useEllipsisIsActive = useEllipsisIsActive(),
      _useEllipsisIsActive2 = _slicedToArray(_useEllipsisIsActive, 2),
      labelRef = _useEllipsisIsActive2[0],
      ellipsis = _useEllipsisIsActive2[1];

  var clickable = !disabled && clickableProp;
  var deletable = !disabled && deletableProp;
  var pillIcon = icon && typeof icon === 'string' ? /*#__PURE__*/React__default['default'].createElement(Icon, {
    className: "Pill-icon",
    name: icon
  }) : icon;
  var className = classnames__default['default']('Pill', classNameProp, {
    'Pill-clickable': clickable,
    'Pill-deletable': deletable,
    'Pill-disabled': disabled
  });
  var pill = /*#__PURE__*/React__default['default'].createElement("div", _extends({
    className: className,
    onClick: onClick,
    role: "button",
    tabIndex: 0
  }, rest, {
    ref: ref
  }), pillIcon || null, /*#__PURE__*/React__default['default'].createElement("div", {
    className: "Pill-label",
    ref: labelRef
  }, label), deletable ? deleteIcon || /*#__PURE__*/React__default['default'].createElement(DeleteButton, {
    disabled: disabled,
    onClick: onDelete
  }) : null);
  return ellipsis && !disabled ?
  /*#__PURE__*/
  //  {...TooltipProps}
  React__default['default'].createElement(Tooltip, {
    enterDelay: 1500,
    placement: "top",
    title: label
  }, pill) : pill;
});

var css_248z$o = ".uitk-light .Pill-checkbox {\n  --stroke: var(--uitk-grey100);\n  --tick: var(--uitk-grey300);\n}\n\n.uitk-dark .Pill-checkbox {\n  --stroke: var(--uitk-grey80);\n  --tick: var(--uitk-grey60);\n}\n\n.Pill-checkbox-icon {\n  fill: none;\n  stroke: var(--stroke);\n  stroke-width: 1px;\n}\n\n.Pill-checkbox-icon-checked {\n  fill: none;\n  stroke: var(--stroke);\n  stroke-width: 2px;\n}\n\n.Pill-checkbox-icon-checked-tick {\n  fill: var(--tick);\n  stroke-width: 0;\n}\n";
styleInject(css_248z$o);

var PillCheckbox = function PillCheckbox(props) {
  var checked = props.checked;
  var className = 'Pill-checkbox';
  return /*#__PURE__*/React__default['default'].createElement("span", {
    className: className
  }, checked ? /*#__PURE__*/React__default['default'].createElement(CheckboxCheckedIcon, {
    className: "".concat(className, "-icon-checked")
  }) : /*#__PURE__*/React__default['default'].createElement(CheckboxIcon, {
    className: "".concat(className, "-icon")
  }));
};

var noop = function noop() {
  return undefined;
};

var SelectablePill = /*#__PURE__*/React.forwardRef(function SelectablePill(props, ref) {
  var _props$defaultChecked = props.defaultChecked,
      defaultChecked = _props$defaultChecked === void 0 ? false : _props$defaultChecked,
      checkedProp = props.checked,
      className = props.className,
      _props$onChange = props.onChange,
      onChange = _props$onChange === void 0 ? noop : _props$onChange,
      rest = _objectWithoutProperties(props, ["defaultChecked", "checked", "className", "onChange"]);

  var _useState = React.useState(defaultChecked),
      _useState2 = _slicedToArray(_useState, 2),
      checked = _useState2[0],
      setChecked = _useState2[1];

  var controlled = checkedProp !== undefined;
  var handleClick = React.useCallback(function (event) {
    if (!controlled) {
      onChange(event, !checked);
      setChecked(!checked);
    } //  else {
    //   onChange(event,checkedProp);
    // }

  }, [checked, controlled, onChange]);
  var isChecked = controlled ? checkedProp : checked;
  return /*#__PURE__*/React__default['default'].createElement(PillBase, _extends({}, rest, {
    "aria-checked": isChecked,
    className: classnames__default['default']('Pill-selectable', className),
    icon: /*#__PURE__*/React__default['default'].createElement(PillCheckbox, {
      checked: isChecked
    }),
    ref: ref,
    role: "checkbox",
    onClick: handleClick
  }));
});

var deleteKeys = ['Enter', 'Delete', 'Backspace'];
var ClosablePill = /*#__PURE__*/React.forwardRef(function ClosablePill(_ref, ref) {
  var onDelete = _ref.onDelete,
      label = _ref.label,
      disabled = _ref.disabled,
      className = _ref.className,
      deleteIcon = _ref.deleteIcon,
      rest = _objectWithoutProperties(_ref, ["onDelete", "label", "disabled", "onClick", "className", "deleteIcon"]);

  var _useState = React.useState(false),
      _useState2 = _slicedToArray(_useState, 2),
      active = _useState2[0],
      setActive = _useState2[1];

  var handleClick = React.useCallback(function (event) {
    if (deleteKeys.includes(event.key)) {
      onDelete === null || onDelete === void 0 ? void 0 : onDelete(event);
    }
  }, [onDelete]);
  var handleKeyDown = React.useCallback(function (event) {
    if (deleteKeys.includes(event.key)) {
      setActive(true);
    }
  }, []);

  var handleKeyUp = function handleKeyUp(event) {
    setActive(false);

    if (!disabled && event.key === 'Delete') {
      onDelete === null || onDelete === void 0 ? void 0 : onDelete(event);
    }
  };

  return /*#__PURE__*/React__default['default'].createElement(PillBase, _extends({
    "aria-label": "".concat(label, " pill, select to remove"),
    className: classnames__default['default'](className, {
      '.Pill-active': active
    }),
    deleteIcon: deleteIcon || /*#__PURE__*/React__default['default'].createElement(DeleteButton, {
      active: active,
      className: ".Pill-deleteButton",
      disabled: disabled
    }),
    disabled: disabled,
    label: label,
    onClick: handleClick,
    onDelete: onDelete,
    onKeyDown: handleKeyDown,
    onKeyUp: handleKeyUp,
    ref: ref
  }, rest));
});

var css_248z$p = "";
styleInject(css_248z$p);

var getVariant = function getVariant(deletable, variantProp) {
  if (variantProp) {
    return variantProp;
  } else {
    return deletable !== undefined ? 'closable' : 'basic';
  }
};

var Pill = /*#__PURE__*/React.forwardRef(function Pill(props, ref) {
  var variantProp = props.variant,
      rest = _objectWithoutProperties(props, ["variant"]);

  var variant = getVariant(props.deletable, variantProp);

  if (variant === 'selectable') {
    return /*#__PURE__*/React__default['default'].createElement(SelectablePill, _extends({}, rest, {
      ref: ref
    }));
  } else if (variant === 'closable') {
    return /*#__PURE__*/React__default['default'].createElement(ClosablePill, _extends({}, rest, {
      ref: ref
    }));
  } else {
    return /*#__PURE__*/React__default['default'].createElement(PillBase, _extends({}, rest, {
      ref: ref
    }));
  }
});

var SpinnerSmall = function SpinnerSmall() {
  return /*#__PURE__*/React__default['default'].createElement("svg", {
    className: "SvgSpinner-spinner",
    viewBox: "0 0 12 12"
  }, /*#__PURE__*/React__default['default'].createElement("defs", null, /*#__PURE__*/React__default['default'].createElement("linearGradient", {
    id: "spinner-small-1",
    x1: "50%",
    x2: "100%",
    y1: "0%",
    y2: "50%"
  }, /*#__PURE__*/React__default['default'].createElement("stop", {
    className: "SvgSpinner-gradientStop1",
    offset: "0%"
  }), /*#__PURE__*/React__default['default'].createElement("stop", {
    className: "SvgSpinner-gradientStop2",
    offset: "100%",
    stopOpacity: "0"
  })), /*#__PURE__*/React__default['default'].createElement("linearGradient", {
    id: "spinner-small-2",
    x1: "100%",
    x2: "0%",
    y1: "100%",
    y2: "100%"
  }, /*#__PURE__*/React__default['default'].createElement("stop", {
    className: "SvgSpinner-gradientStop3",
    offset: "0%"
  }), /*#__PURE__*/React__default['default'].createElement("stop", {
    className: "SvgSpinner-gradientStop4",
    offset: "100%"
  }))), /*#__PURE__*/React__default['default'].createElement("g", {
    fill: "none",
    fillRule: "evenodd",
    strokeWidth: "1"
  }, /*#__PURE__*/React__default['default'].createElement("path", {
    d: "M2,6 L2,6 L0,6 C0,9.313 2.687,12 6,12 L6,10 C3.794,10 2,8.206 2,6",
    fill: "url(#spinner-small-1)"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    d: "M2,6 C2,3.794 3.794,2 6,2 C8.206,2 10,3.794 10,6 L12,6 C12,2.686 9.314,0 6,0 C2.687,0 0,2.686 0,6 L2,6 Z",
    fill: "url(#spinner-small-2)"
  })));
};

var SpinnerMedium = function SpinnerMedium() {
  return /*#__PURE__*/React__default['default'].createElement("svg", {
    className: "SvgSpinner-spinner",
    viewBox: "0 0 24 24"
  }, /*#__PURE__*/React__default['default'].createElement("defs", null, /*#__PURE__*/React__default['default'].createElement("linearGradient", {
    id: "spinner-medium-1",
    x1: "100%",
    x2: "0%",
    y1: "75.6597923%",
    y2: "75.6597923%"
  }, /*#__PURE__*/React__default['default'].createElement("stop", {
    className: "SvgSpinner-gradientStop1",
    offset: "0%"
  }), /*#__PURE__*/React__default['default'].createElement("stop", {
    className: "SvgSpinner-gradientStop2",
    offset: "100%"
  })), /*#__PURE__*/React__default['default'].createElement("linearGradient", {
    id: "spinner-medium-2",
    x1: "25.4178365%",
    x2: "100%",
    y1: "8.36237837%",
    y2: "74.0069615%"
  }, /*#__PURE__*/React__default['default'].createElement("stop", {
    className: "SvgSpinner-gradientStop3",
    offset: "0%"
  }), /*#__PURE__*/React__default['default'].createElement("stop", {
    className: "SvgSpinner-gradientStop4",
    offset: "100%",
    stopOpacity: "0"
  }))), /*#__PURE__*/React__default['default'].createElement("g", {
    fill: "none",
    fillRule: "evenodd",
    strokeWidth: "1"
  }, /*#__PURE__*/React__default['default'].createElement("path", {
    d: "M12,0 C5.373,0 0,5.373 0,12 L2,12 C2,6.486 6.486,2 12,2 C17.514,2 22,6.486 22,12 L24,12 C24,5.373 18.627,0 12,0",
    fill: "url(#spinner-medium-1)"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    d: "M0,12.0005 C0,18.6275 5.373,24.0005 12,24.0005 L12,22.0005 C6.486,22.0005 2,17.5145 2,12.0005 L0,12.0005 Z",
    fill: "url(#spinner-medium-2)"
  })));
};

var SpinnerLarge = function SpinnerLarge() {
  return /*#__PURE__*/React__default['default'].createElement("svg", {
    className: "SvgSpinner-spinner",
    viewBox: "0 0 48 48"
  }, /*#__PURE__*/React__default['default'].createElement("defs", null, /*#__PURE__*/React__default['default'].createElement("linearGradient", {
    id: "spinner-large-1",
    x1: "13%",
    x2: "100%",
    y1: "0%",
    y2: "87%"
  }, /*#__PURE__*/React__default['default'].createElement("stop", {
    className: "SvgSpinner-gradientStop1",
    offset: "0%"
  }), /*#__PURE__*/React__default['default'].createElement("stop", {
    className: "SvgSpinner-gradientStop2",
    offset: "100%",
    stopOpacity: "0"
  })), /*#__PURE__*/React__default['default'].createElement("linearGradient", {
    id: "spinner-large-2",
    x1: "100%",
    x2: "0%",
    y1: "78%",
    y2: "78%"
  }, /*#__PURE__*/React__default['default'].createElement("stop", {
    className: "SvgSpinner-gradientStop3",
    offset: "0%"
  }), /*#__PURE__*/React__default['default'].createElement("stop", {
    className: "SvgSpinner-gradientStop4",
    offset: "100%"
  }))), /*#__PURE__*/React__default['default'].createElement("g", {
    fill: "none",
    fillRule: "evenodd",
    strokeWidth: "1"
  }, /*#__PURE__*/React__default['default'].createElement("path", {
    d: "M2,24 L0,24 C0,37.255 10.745,48 24,48 L24,46 C11.869,46 2,36.131 2,24",
    fill: "url(#spinner-large-1)"
  }), /*#__PURE__*/React__default['default'].createElement("path", {
    d: "M24,0 C10.745,0 0,10.745 0,24 L2,24 C2,11.869 11.869,2 24,2 C36.131,2 46,11.869 46,24 L48,24 C48,10.745 37.255,0 24,0",
    fill: "url(#spinner-large-2)"
  })));
};

var getSvgSpinner = function getSvgSpinner(size) {
  switch (size) {
    case 'small':
      return SpinnerSmall;

    case 'large':
      return SpinnerLarge;

    default:
      return SpinnerMedium;
  }
};

var css_248z$q = ".SvgSpinner-gradientStop1 {\n  stop-color: var(--blue300);\n}\n.SvgSpinner-gradientStop2 {\n  stop-color: var(--blue300);\n}\n.SvgSpinner-gradientStop3 {\n  stop-color: var(--teal300);\n}\n.SvgSpinner-gradientStop4 {\n  stop-color: var(--teal300);\n}\n\n/* Not yet sure about procedure for implementing themes */\n\n/* .uitk-dark .SvgSpinner-gradientStop1 {\n  stop-color: var(--blue500);\n}\n.uitk-dark .SvgSpinner-gradientStop2 {\n  stop-color: var(--teal500);\n}\n.uitk-dark .SvgSpinner-gradientStop3 {\n  stop-color: var(--teal500);\n}\n.uitk-dark .SvgSpinner-gradientStop4 {\n  stop-color: var(--teal500);\n} */\n\n.SvgSpinner {\n  position: relative;\n}\n\n.SvgSpinner-small {\n  height: var(--size-icon-small);\n  width: var(--size-icon-small);\n}\n\n.SvgSpinner-medium {\n  height: var(--size-icon-medium);\n  width: var(--size-icon-medium);\n}\n\n.SvgSpinner-large {\n  height: var(--size-icon-large);\n  width: var(--size-icon-large);\n}\n\n.SvgSpinner-spinner {\n  animation: spinner 0.9s linear infinite;\n  width: 100%;\n  height: 100%;\n  position: absolute;\n  left: 0;\n  top: 0;\n}\n\n@keyframes spinner {\n  0% {\n    transform: rotate(0);\n  }\n  100% {\n    transform: rotate(360deg);\n  }\n}\n";
styleInject(css_248z$q);

/**
 * Spinner component, provides an indeterminate loading indicator
 *
 * @example
 * <Spinner size="small | medium | large" />
 */

var Spinner = /*#__PURE__*/React.forwardRef(function Spinner(_ref, ref) {
  var ariaLabel = _ref.ariaLabel,
      role = _ref.role,
      className = _ref.className,
      size = _ref.size,
      rest = _objectWithoutProperties(_ref, ["ariaLabel", "role", "className", "size"]);

  var SvgSpinner = getSvgSpinner(size);
  return /*#__PURE__*/React__default['default'].createElement("div", _extends({
    "aria-label": ariaLabel,
    size: size,
    className: classnames__default['default']("SvgSpinner-".concat(size), className, 'SvgSpinner'),
    ref: ref,
    role: role
  }, rest), /*#__PURE__*/React__default['default'].createElement(SvgSpinner, null));
});
Spinner.propTypes = {
  /**
   * The prop for aria label of the component
   */
  ariaLabel: PropTypes__default['default'].string,

  /**
   * The className(s) of the component
   */
  className: PropTypes__default['default'].string,

  /**
   * The prop for the role attribute of the component
   */
  role: PropTypes__default['default'].string,

  /**
   * Determines the size of the spinner. Must be one of: 'small', 'medium', 'large'.
   */
  size: PropTypes__default['default'].oneOf(['small', 'medium', 'large'])
};
Spinner.defaultProps = {
  // theme: 'uitk-light',
  ariaLabel: 'loading',
  size: 'medium',
  role: 'status'
};

// where do we put these so they can be shared ? Will CHekcbox and Switch end up in deparate packages ?
// If not, then its easy

var CheckedIcon = function CheckedIcon(_ref) {
  var className = _ref.className;
  return /*#__PURE__*/React__default['default'].createElement("svg", {
    "aria-hidden": "true",
    className: className,
    focusable: "false",
    shapeRendering: "crispEdges",
    viewBox: "0 0 14 14"
  }, /*#__PURE__*/React__default['default'].createElement("g", {
    fillRule: "evenodd"
  }, /*#__PURE__*/React__default['default'].createElement("rect", {
    className: "".concat(className, "-bg"),
    height: "14",
    width: "14",
    x: "0",
    y: "0"
  }), /*#__PURE__*/React__default['default'].createElement("polygon", {
    className: "".concat(className, "-tick"),
    fillRule: "nonzero",
    points: "12 4.22226066 10.6259221 3 5.58277771 8.37894955 3.3179086 6.13993399 2 7.40754746 5.63993779 11"
  })));
};

var css_248z$r = ".uitkSwitch-touchDensity {\n  --switch-width: 44px;\n  --switch-height: 24px;\n  --switch-thumb-margin: 3px 0 0 3px;\n  --switch-thumb-size: 18px;\n  --switch-thumb-translate: 20px;\n}\n.uitkSwitch-lowDensity {\n  --switch-width: 38px;\n  --switch-height: 20px;\n  --switch-thumb-margin: 2px 0 0 2px;\n  --switch-thumb-size: 16px;\n  --switch-thumb-translate: 18px;\n}\n.uitkSwitch-mediumDensity {\n  --switch-width: 34px;\n  --switch-height: 18px;\n  --switch-thumb-margin: 2px 0 0 2px;\n  --switch-thumb-size: 14px;\n  --switch-thumb-translate: 16px;\n}\n.uitkSwitch-highDensity {\n  --switch-width: 30px;\n  --switch-height: 16px;\n  --switch-thumb-margin: 2px 0 0 2px;\n  --switch-thumb-size: 12px;\n  --switch-thumb-translate: 14px;\n}\n\n.uitkSwitch-label {\n  position: relative;\n  margin-left: 0;\n  margin-right: 0;\n  vertical-align: middle;\n\n  font-weight: var(--font-weight);\n\n  /* MUI */\n  cursor: pointer;\n  display: inline-flex;\n  align-items: center;\n}\n\n.uitkSwitch-label .ControlLabel-text {\n  line-height: var(--uitk-line-height);\n  text-align: right;\n\n  /* uitk-light */\n  color: #61656e;\n}\n\n.uitkSwitch {\n  width: var(--switch-width);\n  height: var(--switch-height);\n\n  /* all densities */\n  padding: 0;\n  overflow: visible;\n  box-sizing: content-box;\n  margin-left: 0;\n\n  /* MUI */\n  display: inline-flex;\n  z-index: 0;\n  position: relative;\n  flex-shrink: 0;\n  vertical-align: middle;\n}\n\n.uitkSwitch-track {\n  opacity: 1;\n  position: absolute;\n  box-sizing: border-box;\n  margin-top: 0;\n  margin-left: 0;\n  border-radius: 0;\n  /* uitk-light */\n  background: #84878e;\n  width: var(--switch-width);\n  height: var(--switch-height);\n  /* MUI */\n  z-index: -1;\n  transition: opacity 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,\n    background-color 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;\n}\n\n.uitkSwitch-base {\n  width: var(--switch-thumb-size);\n  height: var(--switch-thumb-size);\n  margin: var(--switch-thumb-margin);\n  /* end density */\n  border: 0;\n  padding: 0;\n  background: transparent;\n  border-radius: 0;\n  justify-content: flex-start;\n  /* MUI */\n  top: 0;\n  left: 0;\n  color: #fafafa;\n  z-index: 1;\n  position: absolute;\n  transition: left 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,\n    transform 150ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;\n\n  /* MUI IconButton-root*/\n  flex: 0 0 auto;\n  overflow: visible;\n  font-size: 1.2857142857142856rem;\n  text-align: center;\n  /* MUI Buttonase root*/\n  cursor: pointer;\n  display: inline-flex;\n  outline: 0;\n  vertical-align: middle;\n  text-decoration: none;\n}\n\n.uitkSwitch-icon-label {\n  transform: translateX(0px);\n  transition: transform 0.15s;\n\n  /* MUI */\n  width: 100%;\n  display: flex;\n  align-items: inherit;\n  justify-content: inherit;\n}\n\n.uitkSwitch-input {\n  left: -100%;\n  width: 300%;\n\n  top: 0;\n  cursor: inherit;\n  height: 100%;\n  margin: 0;\n  opacity: 0;\n  padding: 0;\n  z-index: 1;\n  position: absolute;\n}\n\n.uitkSwitch-thumb {\n  width: var(--switch-thumb-size);\n  height: var(--switch-thumb-size);\n\n  /* theme uitk-light */\n  background: #ffffff;\n\n  outline: 1px solid transparent;\n  box-shadow: none;\n  border-radius: 0;\n}\n\n.uitkSwitch-base.uitkSwitch-checked {\n  transform: none;\n}\n\n.uitkSwitch-base.uitkSwitch-checked .uitkSwitch-icon-label {\n  transform: translateX(var(--switch-thumb-translate));\n}\n\n.uitkSwitch-base.uitkSwitch-checked + .uitkSwitch-track {\n  opacity: 1;\n  background-color: #2670a9;\n  border: 1px solid #2670a9;\n}\n\n.uitkSwitch-checked .uitkSwitch-icon {\n  width: var(--switch-thumb-size);\n  height: var(--switch-thumb-size);\n\n  /* common to thumb */\n  outline: 1px solid transparent;\n  background: #ffffff;\n  box-shadow: none;\n  border-radius: 0;\n}\n\n.uitkSwitch-icon-bg {\n  fill: white;\n}\n.uitkSwitch-icon-tick {\n  fill: #2670a9;\n}\n\n.uitkSwitch-focusVisible:before {\n  content: '';\n  position: absolute;\n  outline-color: #2670a9;\n  outline-style: dotted;\n  outline-width: 2px;\n  outline-offset: 0;\n\n  width: var(--switch-width);\n  height: var(--switch-height);\n  /* medium density */\n  top: -2px;\n  left: -2px;\n}\n\n.uitkSwitch-focusVisible:not(.uitkSwitch-disabled) + .uitkSwitch-track {\n  background-color: #2d81bd;\n}\n\n.uitkSwitch-disabled {\n  pointer-events: none;\n}\n\n.uitkSwitch-disabled + .uitkSwitch-track {\n  background: #84878e;\n  cursor: not-allowed;\n  opacity: 0.4;\n}\n";
styleInject(css_248z$r);

var Switch = /*#__PURE__*/React.forwardRef(function Switch(props, ref) {
  useA11yProps();

  var checkedProp = props.checked,
      defaultChecked = props.defaultChecked,
      densityProp = props.density,
      disabled = props.disabled,
      label = props.label,
      LabelProps = props.LabelProps,
      onBlur = props.onBlur,
      onChange = props.onChange,
      onFocus = props.onFocus,
      rest = _objectWithoutProperties(props, ["checked", "className", "classes", "color", "defaultChecked", "density", "disabled", "inField", "label", "LabelProps", "onBlur", "onChange", "onFocus"]); //   const checkedIcon = <CheckedIcon className={classes.icon} />;


  var inputRef = React.useRef(false);
  var density = useDensity(densityProp);

  var _useControlled = useControlled({
    controlled: checkedProp,
    "default": Boolean(defaultChecked),
    name: 'Switch',
    state: 'checked'
  }),
      _useControlled2 = _slicedToArray(_useControlled, 2),
      checked = _useControlled2[0],
      setChecked = _useControlled2[1];

  var _useState = React.useState(false),
      _useState2 = _slicedToArray(_useState, 2),
      focusVisible = _useState2[0],
      setFocusVisible = _useState2[1];

  var handleChange = function handleChange(evt) {
    var value = evt.target.checked;
    setChecked(value);
    onChange && onChange(evt, value);
  };

  var handleFocus = React.useCallback(function (event) {
    // Fix for https://github.com/facebook/react/issues/7769
    if (!inputRef.current) {
      inputRef.current = event.currentTarget;
    } // TODO :focus-visible not yet supported on Safari, so we'll need to use the
    // useIsFocusVisible polyfill


    if (inputRef.current.matches(':focus-visible')) {
      setFocusVisible(true);
    }

    onFocus && onFocus(event);
  }, [onFocus]);
  var handleBlur = React.useCallback(function (event) {
    setFocusVisible(false);
    onBlur && onBlur(event);
  }, [onBlur]);
  var densityClassName = "uitkSwitch-".concat(density, "Density");
  return /*#__PURE__*/React__default['default'].createElement(ControlLabel, _extends({}, rest, {
    labelPlacement: "left"
  }, LabelProps, {
    className: "uitkSwitch-label",
    disabled: disabled,
    label: label
  }), /*#__PURE__*/React__default['default'].createElement("span", {
    className: classnames__default['default']('uitkSwitch', densityClassName)
  }, /*#__PURE__*/React__default['default'].createElement("span", {
    className: classnames__default['default']('uitkSwitch-base', {
      'uitkSwitch-checked': checked,
      'uitkSwitch-disabled': disabled,
      'uitkSwitch-focusVisible': focusVisible
    }),
    "aria-disabled": "false"
  }, /*#__PURE__*/React__default['default'].createElement("span", {
    className: "uitkSwitch-icon-label"
  }, /*#__PURE__*/React__default['default'].createElement("input", {
    className: "uitkSwitch-input",
    defaultChecked: defaultChecked,
    disabled: disabled,
    onBlur: handleBlur,
    onChange: handleChange,
    onFocus: handleFocus,
    ref: inputRef,
    type: "checkbox"
  }), checked ? /*#__PURE__*/React__default['default'].createElement(CheckedIcon, {
    className: "uitkSwitch-icon"
  }) : /*#__PURE__*/React__default['default'].createElement("span", {
    className: "uitkSwitch-thumb"
  }))), /*#__PURE__*/React__default['default'].createElement("span", {
    className: "uitkSwitch-track"
  })));
});

var direction = {
  ArrowLeft: -1,
  ArrowUp: -1,
  ArrowRight: 1,
  ArrowDown: 1,
  Home: 0,
  End: 0
};
function useTabstrip(_ref, ref) {
  var children = _ref.children,
      defaultValue = _ref.defaultValue,
      _ref$keyBoardActivati = _ref.keyBoardActivation,
      keyBoardActivation = _ref$keyBoardActivati === void 0 ? 'manual' : _ref$keyBoardActivati,
      onChange = _ref.onChange,
      onDeleteTab = _ref.onDeleteTab,
      orientation = _ref.orientation,
      valueProp = _ref.value;
  var tabs = useChildRefs(children);
  var manualActivation = keyBoardActivation === 'manual';
  var vertical = orientation === 'vertical';

  var _useControlled = useControlled({
    value: valueProp,
    "default": defaultValue,
    name: 'Tabstrip',
    state: 'value'
  }),
      _useControlled2 = _slicedToArray(_useControlled, 2),
      value = _useControlled2[0],
      setValue = _useControlled2[1];

  function focusTab(tabIndex) {
    var tab = tabs[tabIndex].current; // The timeout is very important in one scenario: where tab has overflowed
    // and is being selected from overflow menu. We must not focus it until the
    // overflow mechanism + render has restored it to the main display.

    setTimeout(function () {
      tab.focus();
    }, 70);
  }

  function activateTab(e, tabIndex) {
    setValue(tabIndex);
    onChange && onChange(e, tabIndex);
    focusTab(tabIndex);
  }

  function switchTabOnKeyPress(e, tabIndex) {
    var key = e.key;

    if (direction[key] !== undefined) {
      e.preventDefault();
      var newTabIndex;
      var tab = tabs[tabIndex + direction[key]];

      if (tab && !tab.current.dataset.overflowed) {
        newTabIndex = tabIndex + direction[key];
      } else if (key === 'ArrowLeft' || key === 'ArrowUp') {
        newTabIndex = tabs.length - 1;
        var _tab = tabs[newTabIndex].current;

        while (_tab.dataset.overflowed && newTabIndex !== tabIndex) {
          newTabIndex -= 1;
          _tab = tabs[newTabIndex].current;
        }
      } else if (key === 'ArrowRight' || key === 'ArrowDown') {
        newTabIndex = 0;
      }

      if (manualActivation) {
        focusTab(newTabIndex);
      } else {
        activateTab(e, newTabIndex);
      }
    }
  }

  var handleClick = function handleClick(e, tabIndex) {
    if (tabIndex !== value) {
      setValue(tabIndex);
      onChange && onChange(e, tabIndex);
      focusTab(tabIndex);
    }
  };

  var handleKeyDown = function handleKeyDown(e, tabIndex) {
    var key = e.key;

    switch (key) {
      case 'End':
        switchTabOnKeyPress(e, tabs.length - 1);
        break;

      case 'Home':
        switchTabOnKeyPress(e, 0);
        break;

      case 'ArrowLeft':
      case 'ArrowRight':
        if (!vertical) {
          switchTabOnKeyPress(e, tabIndex);
        }

        break;

      case 'ArrowUp':
      case 'ArrowDown':
        if (vertical) {
          switchTabOnKeyPress(e, tabIndex);
        }

        break;
    }
  };

  var handleKeyUp = function handleKeyUp(e, tabIndex) {
    var key = e.key;

    switch (key) {
      case 'Enter':
      case 'Space':
        if (tabIndex !== value) {
          onChange && onChange(e, tabIndex);
        }

        break;
    }
  };

  var handleDeleteTab = function handleDeleteTab(e, tabIndex) {
    onDeleteTab(e, tabIndex);

    if (tabIndex - 1 < 0) {
      focusTab(0);
    } else {
      focusTab(tabIndex - 1);
    }
  };

  return {
    activateTab: activateTab,
    tabProps: {
      onClick: handleClick,
      onDelete: handleDeleteTab,
      onKeyDown: handleKeyDown,
      onKeyUp: handleKeyUp
    },
    tabRefs: tabs,
    value: value
  };
}

function useActivationIndicator(rootRef, tabRef, orientation) {
  var _useState = React.useState(null),
      _useState2 = _slicedToArray(_useState, 2),
      forceRender = _useState2[1]; //   const vertical = orientation === "vertical";


  var createIndicatorStyle = React.useCallback(function () {
    if (tabRef.current) {
      var tabRect = tabRef.current.getBoundingClientRect(); // TODO we could cache this one at least ...

      var rootRect = rootRef.current.getBoundingClientRect();

      if (orientation === 'horizontal') {
        var left = tabRect.left - rootRect.left;
        return {
          left: left,
          width: tabRect.width
        };
      } else {
        var top = tabRect.top - rootRect.top;
        return {
          top: top,
          height: tabRect.height
        };
      }
    }
  }, [orientation, rootRef, tabRef]); // Force a re-render after the initial render only. We cannot determine where to
  // position the activation indicator content has been rendered.
  // All subsequent updates will be triggered by changes to TabRef. We don't want
  // to trigger these after render as this will always incure two renders for the
  // ActivationIndicator. AFter the first, we can compute position during the render
  // phase.

  React.useLayoutEffect(function () {
    forceRender({});
  }, [forceRender]); // Have tried memoising this. Problem is, it's difficult to get the timing right
  // when overflow may be present and a selected tab may be currently overflowed
  // This is more expensive than necessary, but simple and safe...

  return createIndicatorStyle();
}

var css_248z$s = ".uitk-light .uitkActivationIndicator {\n  --uitk-activation-indicator-bg: var(--uitk-grey60);\n  --uitk-activation-indicator-thumb-bg: var(--uitk-orange700);\n}\n\n.uitk-dark .uitkActivationIndicator {\n  --uitk-activation-indicator-bg: var(--uitk-grey400);\n  --uitk-activation-indicator-thumb-bg: var(--uitk-orange500);\n}\n\n.uitkActivationIndicator-no-background {\n  --uitk-activation-indicator-bg: transparent !important;\n}\n\n.uitkActivationIndicator {\n  background-color: var(--uitk-activation-indicator-bg);\n  bottom: 0;\n  box-sizing: border-box;\n  position: absolute;\n  height: 1px;\n  width: 100%;\n}\n\n.uitkActivationIndicator-thumb {\n  position: absolute;\n  height: 2px;\n  background-color: var(--uitk-activation-indicator-thumb-bg);\n  transition: left 0.2s ease;\n  bottom: 0;\n}\n\n.uitkActivationIndicator-vertical {\n  right: 0;\n  height: 100%;\n  width: 1px;\n}\n\n.uitkActivationIndicator-vertical .uitkActivationIndicator-thumb {\n  bottom: auto;\n  right: 0;\n  transition: top 0.2s ease;\n  width: 2px;\n}\n";
styleInject(css_248z$s);

var ActivationIndicator = function ActivationIndicator(_ref) {
  var _ref$hideBackground = _ref.hideBackground,
      hideBackground = _ref$hideBackground === void 0 ? false : _ref$hideBackground,
      _ref$hideThumb = _ref.hideThumb,
      hideThumb = _ref$hideThumb === void 0 ? false : _ref$hideThumb,
      _ref$orientation = _ref.orientation,
      orientation = _ref$orientation === void 0 ? 'horizontal' : _ref$orientation,
      tabRef = _ref.tabRef;
  var rootRef = React.useRef(null);
  var rootClass = 'uitkActivationIndicator';
  var style = useActivationIndicator(rootRef, tabRef, orientation);
  return /*#__PURE__*/React__default['default'].createElement("div", {
    className: classnames__default['default'](rootClass, "".concat(rootClass, "-").concat(orientation), _defineProperty({}, "".concat(rootClass, "-no-background"), hideBackground)),
    ref: rootRef
  }, hideThumb === false ? /*#__PURE__*/React__default['default'].createElement("div", {
    className: "".concat(rootClass, "-thumb"),
    style: style
  }) : null);
};

var css_248z$t = ".uitkTabstrip {\n  align-items: flex-start;\n  box-sizing: border-box;\n  height: var(--uitk-size-stackable, 36px);\n  position: relative;\n  overflow: hidden;\n  display: flex;\n  min-width: 28px;\n}\n\n.uitkTabstrip-addButton,\n.uitkTabstrip-overflowMenu {\n  margin-left: var(--uitk-space);\n}\n\n.uitkTabstrip-inner {\n  width: 100%;\n  align-items: center;\n  display: flex;\n  flex-basis: auto;\n  flex-grow: 0;\n  flex-shrink: 1;\n  flex-wrap: wrap;\n  justify-content: flex-start;\n}\n\n.uitkTabstrip-vertical {\n  align-self: flex-start;\n  display: inline-flex;\n}\n\n.uitkTabstrip-vertical .uitkTabstrip-inner {\n  flex-direction: column;\n  height: auto;\n}\n\n.uitkTabstrip-centered .uitkTabstrip-inner {\n  justify-content: center;\n}\n";
styleInject(css_248z$t);

var AddTabButton = function AddTabButton(_ref) {
  var className = _ref.className,
      title = _ref.title,
      props = _objectWithoutProperties(_ref, ["className", "title"]);

  return /*#__PURE__*/React__default['default'].createElement(Button, _extends({
    className: classnames__default['default']('tab-add', className)
  }, props, {
    variant: "secondary",
    tabIndex: 0
  }), /*#__PURE__*/React__default['default'].createElement(Icon, {
    name: "add",
    accessibleText: title
  }));
};

var Tabstrip = function Tabstrip(props) {
  var root = React.useRef(null);

  var _props$centered = props.centered,
      centered = _props$centered === void 0 ? false : _props$centered,
      children = props.children,
      enableAddTab = props.enableAddTab,
      onAddTab = props.onAddTab,
      _props$noBorder = props.noBorder,
      noBorder = _props$noBorder === void 0 ? false : _props$noBorder,
      _props$orientation = props.orientation,
      orientation = _props$orientation === void 0 ? 'horizontal' : _props$orientation,
      _props$overflowMenu = props.overflowMenu,
      overflowMenu = _props$overflowMenu === void 0 ? true : _props$overflowMenu,
      _props$showActivation = props.showActivationIndicator,
      showActivationIndicator = _props$showActivation === void 0 ? true : _props$showActivation,
      style = props.style,
      title = props.title,
      rootProps = _objectWithoutProperties(props, ["centered", "children", "className", "defaultValue", "enableAddTab", "keyBoardActivation", "onAddTab", "onDeleteTab", "noBorder", "orientation", "overflowMenu", "showActivationIndicator", "style", "title"]);

  var childCount = React.useRef(React__default['default'].Children.count(children));
  var classRoot = 'uitkTabstrip';

  var _useOverflowObserver = useOverflowObserver(orientation, 'Tabstrip'),
      _useOverflowObserver2 = _slicedToArray(_useOverflowObserver, 4),
      innerContainerRef = _useOverflowObserver2[0],
      overflowedItems = _useOverflowObserver2[1],
      resetOverflow = _useOverflowObserver2[3];

  var _useTabstrip = useTabstrip(props),
      activateTab = _useTabstrip.activateTab,
      tabProps = _useTabstrip.tabProps,
      tabRefs = _useTabstrip.tabRefs,
      value = _useTabstrip.value;

  var selectedIndex = React.useRef(value !== null && value !== void 0 ? value : 0);

  var handleOverflowChange = function handleOverflowChange(e, tab) {
    activateTab(e, tab.index);
  };

  var handleLabelEdited = function handleLabelEdited(evt, index, label) {
    // TODO need to redraw activation indicatr
    console.log("Label Edited [".concat(index, "] = ").concat(label));
  };

  var handleTabMouseDown = function handleTabMouseDown(e, index) {
    if (rootProps.onMouseDown) {
      e.stopPropagation();
      rootProps.onMouseDown(e, index);
    }
  }; // shouldn't we use ref for this ?


  React.useLayoutEffect(function () {
    // We don't care about changes to overflowedItems here, the overflowObserver
    // always does the right thing. We only care about changes to selected tab
    if (selectedIndex.current !== value && overflowMenu) {
      // We might want to do this only if the selected tab is overflowed ?
      resetOverflow();
      selectedIndex.current = value;
    }
  }, [overflowMenu, resetOverflow, value]);
  React.useLayoutEffect(function () {
    if (React__default['default'].Children.count(children) !== childCount.current) {
      childCount.current = React__default['default'].Children.count(children);
      resetOverflow();
    }
  }, [children, resetOverflow]);

  var renderContent = function renderContent() {
    var tabs = [];
    React__default['default'].Children.toArray(children).forEach(function (child, index) {
      var selected = index === value;
      var onLabelEdited = child.props.editable ? handleLabelEdited : undefined;
      var overflowed = overflowedItems.findIndex(function (item) {
        return item.index === index;
      }) !== -1;
      tabs.push( /*#__PURE__*/React__default['default'].cloneElement(child, _objectSpread2(_objectSpread2({
        index: index
      }, tabProps), {}, {
        'data-index': index,
        'data-priority': selected ? 1 : 3,
        'data-overflowed': overflowed ? true : undefined,
        onLabelEdited: onLabelEdited,
        onMouseDown: handleTabMouseDown,
        orientation: orientation,
        ref: tabRefs[index],
        selected: selected
      })));
    });

    if (overflowMenu) {
      tabs.push( /*#__PURE__*/React__default['default'].createElement(OverflowMenu, {
        className: "".concat(classRoot, "-overflowMenu"),
        "data-priority": 0,
        "data-index": tabs.length,
        "data-overflow-indicator": true,
        key: "overflow",
        onChange: handleOverflowChange,
        source: overflowedItems
      }));
    }

    if (enableAddTab) {
      tabs.push( /*#__PURE__*/React__default['default'].createElement(AddTabButton, {
        "data-priority": 2,
        "data-index": tabs.length,
        key: "Tabstrip-addButton",
        onClick: onAddTab,
        title: title
      }));
    }

    return tabs;
  };

  var selectedTabOverflowed = overflowedItems.some(function (item) {
    return item.index === value;
  });
  var className = classnames__default['default'](classRoot, "".concat(classRoot, "-").concat(orientation), _defineProperty({}, "".concat(classRoot, "-centered"), centered));
  return /*#__PURE__*/React__default['default'].createElement("div", _extends({}, rootProps, {
    className: className,
    ref: root,
    role: "tablist",
    style: style
  }), /*#__PURE__*/React__default['default'].createElement("div", {
    className: "".concat(classRoot, "-inner"),
    ref: innerContainerRef,
    style: {
      lineHeight: '36px'
    }
  }, renderContent()), showActivationIndicator ? /*#__PURE__*/React__default['default'].createElement(ActivationIndicator, {
    hideThumb: selectedTabOverflowed,
    hideBackground: noBorder,
    orientation: orientation,
    tabRef: tabRefs[value !== null && value !== void 0 ? value : 0]
  }) : null);
};

Tabstrip.displayName = 'Tabstrip';

var css_248z$u = ".EditableLabel {\n  color: inherit;\n  font-size: inherit;\n  z-index: 1;\n}\n\n.EditableLabel-editing {\n  bottom: 0;\n  font-weight: var(--uitk-font-weight-regular);\n  left: var(--tab-spacing, 0);\n  padding: 0;\n  position: absolute;\n  outline-style: none;\n  right: var(--tab-spacing, 0);\n  top: 0;\n}\n\n.EditableLabel-input {\n  outline: none;\n}\n";
styleInject(css_248z$u);

var EditableLabel = function EditableLabel(_ref) {
  var classNameProp = _ref.className,
      densityProp = _ref.density,
      onEnterEditMode = _ref.onEnterEditMode,
      onExitEditMode = _ref.onExitEditMode,
      valueProp = _ref.value;
  var inputRef = React.useRef(null);

  var _useState = React.useState(false),
      _useState2 = _slicedToArray(_useState, 2),
      editing = _useState2[0],
      setEditing = _useState2[1];

  var isEditing = React.useRef(false);

  var _useState3 = React.useState(valueProp),
      _useState4 = _slicedToArray(_useState3, 2),
      value = _useState4[0],
      setValue = _useState4[1];

  var density = useDensity(densityProp);
  React.useLayoutEffect(function () {
    if (editing) {
      inputRef.current.select();
      inputRef.current.focus();
    }
  }, [editing, inputRef]);
  var className = classnames__default['default']("EditableLabel", classNameProp, "EditableLabel-".concat(density, "Density"));

  var enterEditMode = function enterEditMode(evt) {
    if (!isEditing.current) {
      setEditing(isEditing.current = true);
      onEnterEditMode && onEnterEditMode(evt);
    }
  };

  var exitEditMode = function exitEditMode(evt) {
    if (isEditing.current) {
      setEditing(isEditing.current = false);
      onExitEditMode && onExitEditMode(evt, value);
    }
  };

  var handleChange = function handleChange(evt) {
    setValue(evt.target.value);
  };

  var handleDoubleClick = function handleDoubleClick(evt) {
    enterEditMode(evt);
  };

  var handleBlur = function handleBlur(evt) {
    exitEditMode(evt);
  };

  var handleKeyDown = function handleKeyDown(evt) {
    if (evt.key === "Enter") {
      exitEditMode(evt);
    } else if (evt.key === "ArrowRight" || evt.key === "ArrowLeft") {
      evt.stopPropagation();
    } else if (evt.key === "Escape") {
      // TODO restore original value
      exitEditMode(evt);
    }
  };

  return editing ? /*#__PURE__*/React__default['default'].createElement(Input, {
    className: classnames__default['default'](className, "EditableLabel-editing"),
    inputProps: {
      className: "EditableLabel-input"
    },
    value: value,
    onBlur: handleBlur,
    onChange: handleChange,
    onKeyDown: handleKeyDown,
    ref: inputRef,
    style: {
      padding: 0
    }
  }) : /*#__PURE__*/React__default['default'].createElement("span", {
    className: className,
    onDoubleClick: handleDoubleClick
  }, value);
};

var css_248z$v = ".uitk-light .uitkTab {\n  --tab-color: var(--uitk-grey400);\n  --tab-selected-color: var(--uitk-grey900);\n  --tab-hover-background: var(--uitk-grey20);\n}\n\n.uitk-dark .uitkTab {\n  --tab-color: var(--uitk-grey40);\n  --tab-selected-color: var(--white);\n  --tab-hover-background: var(--uitk-grey600);\n}\n\n.uitkTab {\n  --tab-bar-color: var(--uitk-grey90);\n  --tab-spacing: var(--uitk-space);\n\n  align-items: center;\n  align-self: stretch;\n  background-color: transparent;\n  border: none;\n  border-radius: 0;\n  color: var(--tab-color);\n  cursor: pointer;\n  display: inline-flex;\n  font-family: uitk-sans;\n  font-weight: var(--uitk-font-weight-regular);\n  font-size: var(--uitk-font-size-regular, 12px);\n  /* 2px padding bottom ? */\n  height: var(--uitk-size-stackable);\n  padding: 0 var(--tab-spacing);\n  position: relative;\n}\n\n.uitkTab:not(.uitkTab-vertical) {\n  margin: 0 var(--tab-spacing) 0 0;\n}\n\n.uitkTab-closeable {\n  padding-right: 0;\n}\n\n.uitkTab-closeButton {\n  margin-left: var(--uitk-space);\n}\n\n/* override a Storybook style */\nbutton.uitkTab + button.uitkTab {\n  margin-left: 0;\n}\n\n.uitkTab:not(.uitkTab-selected):hover {\n  z-index: 1;\n}\n\n.uitkTab:hover:not(.uitkTab-closeHover) {\n  background-color: var(--tab-hover-background);\n}\n\n.uitkTab:not(.uitkTab-selected):hover:after,\n.uitkTab:not(.uitkTab-selected):focus-visible:after {\n  background: var(--tab-bar-color);\n  bottom: 0;\n  content: '';\n  opacity: 1;\n  position: absolute;\n  right: 0;\n}\n\n.uitkTab:not(.uitkTab-selected):not(.uitkTab-vertical):hover:after,\n.uitkTab:not(.uitkTab-selected):not(.uitkTab-vertical):focus-visible:after {\n  left: 0;\n  height: 2px;\n}\n\n.uitkTab-vertical:not(.uitkTab-selected):hover:after,\n.uitkTab-vertical:not(.uitkTab-selected):focus-visible:after {\n  top: 0;\n  width: 2px;\n}\n\n.uitkTab-selected {\n  color: var(--tab-selected-color);\n  font-family: uitk-sans;\n  font-weight: var(--uitk-font-weight-bold);\n}\n\n.uitkTab:focus {\n  outline: none;\n}\n\n.uitkTab:focus-visible {\n  outline: none;\n  background-color: var(--uitk-grey20);\n}\n\n.uitkTab-editing:before,\n.uitkTab:focus-visible:before {\n  content: '';\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 2px;\n  border: dotted cornflowerblue 2px;\n}\n\n.uitkTab-vertical.uitkTab-editing:before,\n.uitkTab-vertical:focus-visible:before {\n  right: 2px;\n  bottom: 0;\n}\n\n.uitkTab .uitkTab-closeButton {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.uitkTab .uitkTab-closeButton:hover {\n  background-color: var(--uitk-grey40);\n}\n\n.uitkTab .uitkTab-text {\n  position: static;\n  text-align: center;\n  /* ensure content sita above focus ring */\n  z-index: 1;\n}\n\n.uitkTab-vertical .uitkTab-text {\n  text-align: left;\n}\n\n.uitkTab-closeable .uitkTab-text {\n  margin-right: 8px;\n}\n\n.uitkTab .uitkTab-text:before {\n  height: 0;\n  content: attr(data-text);\n  display: block;\n  visibility: hidden;\n  font-weight: 700;\n}\n";
styleInject(css_248z$v);

var CloseTabButton = function CloseTabButton(_ref) {
  var _ref$small = _ref.small,
      small = _ref$small === void 0 ? false : _ref$small,
      tabIndex = _ref.tabIndex,
      title = _ref.title,
      rest = _objectWithoutProperties(_ref, ["small", "tabIndex", "title"]);

  return /*#__PURE__*/React__default['default'].createElement(Button, _extends({
    className: "uitkTab-closeButton",
    component: "div",
    tabIndex: tabIndex,
    title: title,
    variant: "secondary"
  }, rest), /*#__PURE__*/React__default['default'].createElement(Icon, {
    accessibleText: "Close Tab (Delete or Backspace)",
    name: small ? 'close-small' : 'close'
  }));
};

var Tab = /*#__PURE__*/React.forwardRef(function Tab(_ref2, ref) {
  var _cx;

  var ariaControls = _ref2.ariaControls,
      deletable = _ref2.deletable,
      editable = _ref2.editable,
      selected = _ref2.selected,
      index = _ref2.index,
      labelProp = _ref2.label,
      onClick = _ref2.onClick,
      onDelete = _ref2.onDelete,
      onKeyDown = _ref2.onKeyDown,
      onKeyUp = _ref2.onKeyUp,
      onLabelEdited = _ref2.onLabelEdited,
      onMouseDown = _ref2.onMouseDown,
      orientation = _ref2.orientation,
      props = _objectWithoutProperties(_ref2, ["ariaControls", "deletable", "draggable", "editable", "selected", "index", "label", "onClick", "onDelete", "onKeyDown", "onKeyUp", "onLabelEdited", "onMouseDown", "orientation"]);

  var root = React.useRef(null);
  var setRef = useForkRef(ref, root);

  var _useState = React.useState(false),
      _useState2 = _slicedToArray(_useState, 2),
      closeHover = _useState2[0],
      setCloseHover = _useState2[1];

  var _useState3 = React.useState(false),
      _useState4 = _slicedToArray(_useState3, 2),
      editMode = _useState4[0],
      setEditMode = _useState4[1];

  var _useState5 = React.useState(labelProp),
      _useState6 = _slicedToArray(_useState5, 2),
      label = _useState6[0],
      setLabel = _useState6[1];

  var classRoot = 'uitkTab';
  var density = useDensity();

  var handleClick = function handleClick(e) {
    e.preventDefault();
    onClick(e, index);
  };

  var handleKeyDown = function handleKeyDown(e) {
    onKeyDown(e, index);
  };

  var handleKeyUp = function handleKeyUp(e) {
    switch (e.key) {
      case 'Delete':
        if (deletable) {
          e.stopPropagation();
          onDelete(e, index);
        }

        break;

      default:
        onKeyUp(e, index);
    }
  };

  var handleCloseButtonClick = function handleCloseButtonClick(e) {
    e.stopPropagation();
    onDelete(e, index);
  };

  var handleCloseButtonEnter = function handleCloseButtonEnter() {
    setCloseHover(true);
  };

  var handleCloseButtonLeave = function handleCloseButtonLeave() {
    setCloseHover(false);
  };

  var handleMouseDown = function handleMouseDown(e) {
    onMouseDown && onMouseDown(e, index);
  };

  var handleEnterEditMode = function handleEnterEditMode(evt) {
    return setEditMode(true);
  };

  var handleExitEditMode = function handleExitEditMode(evt, editedLabel) {
    setEditMode(false);
    setLabel(editedLabel);

    if (evt.key === 'Enter') {
      root.current.focus();
    }

    onLabelEdited && onLabelEdited(evt, index, editedLabel);
  };

  var getLabel = function getLabel() {
    if (editable) {
      return /*#__PURE__*/React__default['default'].createElement(EditableLabel, {
        value: label,
        onEnterEditMode: handleEnterEditMode,
        onExitEditMode: handleExitEditMode
      });
    } else {
      return label;
    }
  }; // TODO is it ok for the close button to be a span ?
  // button cannot be nested within button. toolkit
  // uses side-by-side buttons


  return /*#__PURE__*/React__default['default'].createElement("button", _extends({}, props, {
    "aria-controls": ariaControls,
    "aria-selected": selected,
    className: classnames__default['default'](classRoot, (_cx = {}, _defineProperty(_cx, "".concat(classRoot, "-selected"), selected), _defineProperty(_cx, "".concat(classRoot, "-closeable"), deletable), _defineProperty(_cx, "".concat(classRoot, "-closeHover"), closeHover), _defineProperty(_cx, "".concat(classRoot, "-editing"), editMode), _defineProperty(_cx, "".concat(classRoot, "-vertical"), orientation === 'vertical'), _cx)),
    onClick: handleClick,
    onKeyDown: handleKeyDown,
    onKeyUp: handleKeyUp,
    onMouseDown: handleMouseDown,
    ref: setRef,
    role: "tab",
    tabIndex: selected ? undefined : -1
  }), /*#__PURE__*/React__default['default'].createElement("span", {
    className: "".concat(classRoot, "-text"),
    "data-text": label,
    role: "button"
  }, getLabel()), deletable ? /*#__PURE__*/React__default['default'].createElement(CloseTabButton, {
    onClick: handleCloseButtonClick,
    onMouseEnter: handleCloseButtonEnter,
    onMouseLeave: handleCloseButtonLeave,
    small: density === 'medium' || density === 'high'
  }) : null);
});

var TooltipContext = /*#__PURE__*/React.createContext();
/**
 * TODO: Probably move this to Tooltip packages so it can be reused?
 *
 * Provide defaults for Tooltip config so that we can maintain the consistency
 * if no customized override is provided
 */

var useTooltipContext = function useTooltipContext() {
  var context = React.useContext(TooltipContext) || {};
  React.useDebugValue("".concat(context && context.Tooltip !== undefined ? 'Customized' : 'Default UIToolkit', " Tooltip."));
  return {
    Tooltip: context.Tooltip || Tooltip,
    enterDelay: context.tooltipEnterDelay || 1500,
    leaveDelay: context.tooltipLeaveDelay || 0,
    placement: context.tooltipPlacement || 'top'
  };
};

var safeParseFloat = function safeParseFloat(target) {
  return parseFloat(target || 0);
};

var getWidth = function getWidth(node) {
  if (node == null) {
    return 0;
  }

  var style = window.getComputedStyle(node);
  var margin = safeParseFloat(style.marginLeft) + safeParseFloat(style.marginRight);
  var dimension;

  if (style.display === 'none') {
    var nodeDisplay = node.style.display;
    node.style.display = 'inline-block';
    dimension = node.getBoundingClientRect();
    node.style.display = nodeDisplay;
  } else {
    dimension = node.getBoundingClientRect();
  }

  return dimension.width + margin;
};
/**
 * This records the width of a component when it's rendered
 */

var useWidth = function useWidth(density) {
  var _useState = React.useState(null),
      _useState2 = _slicedToArray(_useState, 2),
      node = _useState2[0],
      setNode = _useState2[1];

  var _useState3 = React.useState(null),
      _useState4 = _slicedToArray(_useState3, 2),
      width = _useState4[0],
      setWidth = _useState4[1]; // use callback ref as some element may not get rendered initially


  var ref = React.useCallback(function (newNode) {
    if (newNode !== null) {
      setNode(newNode);
    }
  }, []);
  React.useLayoutEffect(function () {
    if (node !== null) {
      setWidth(getWidth(node));
    }
  }, [node, density]);
  return [ref, width];
};

var InputPill = /*#__PURE__*/React.memo(function InputPill(props) {
  var pillsRef = props.pillsRef,
      density = props.density,
      index = props.index,
      hidden = props.hidden,
      lastVisible = props.lastVisible,
      highlighted = props.highlighted,
      active = props.active,
      disabled = props.disabled,
      onDelete = props.onDelete,
      maxWidth = props.maxWidth,
      restProps = _objectWithoutProperties(props, ["pillsRef", "density", "index", "hidden", "lastVisible", "highlighted", "active", "disabled", "onDelete", "maxWidth"]);

  var ref = React.useRef(null);

  var _useState = React.useState(false),
      _useState2 = _slicedToArray(_useState, 2),
      hovered = _useState2[0],
      setHovered = _useState2[1];

  var _useState3 = React.useState(false),
      _useState4 = _slicedToArray(_useState3, 2),
      setTooltipOpen = _useState4[1];

  var _useTooltipContext = useTooltipContext(),
      enterDelay = _useTooltipContext.enterDelay,
      leaveDelay = _useTooltipContext.leaveDelay;

  var isRemovable = Boolean(onDelete); // useLayoutEffect to match the calcFirstHiddenIndex in TokenizedInputBase
  // We need to collect widths before the calculation

  React.useLayoutEffect(function () {
    if (!isRemovable && pillsRef.current) {
      pillsRef.current[index] = getWidth(ref.current);
    }
  }, [pillsRef, index, density, isRemovable, lastVisible]);
  React.useLayoutEffect(function () {
    return function () {
      pillsRef.current[index] = undefined;
    };
  }, [pillsRef, index, density]);
  React.useEffect(function () {
    if (hidden) {
      setTooltipOpen(false);
    }
  }, [hidden]);
  React.useEffect(function () {
    var shouldOpen = hovered || highlighted;
    var timeout = setTimeout(function () {
      return setTooltipOpen(shouldOpen);
    }, shouldOpen ? enterDelay : leaveDelay);
    return function () {
      clearTimeout(timeout);
    };
  }, [hovered, highlighted, enterDelay, leaveDelay]);

  var handleDelete = function handleDelete() {
    onDelete(index);
  };

  var handleMouseOver = function handleMouseOver() {
    setHovered(true);
  };

  var handleMouseLeave = function handleMouseLeave() {
    setHovered(false);
  };

  return (
    /*#__PURE__*/
    // We want Pill to be default `clickable` to match design?
    React__default['default'].createElement(Pill // Tooltip={Tooltip}
    // TooltipProps={{ placement, open: tooltipOpen }}
    , _extends({
      className: classnames__default['default']('InputPill', {
        'InputPill-pillActive': active || highlighted,
        'InputPill-pillLastVisible': lastVisible,
        'InputPill-hidden': hidden
      }),
      density: density,
      disabled: disabled,
      onDelete: isRemovable ? handleDelete : null,
      onMouseLeave: handleMouseLeave,
      onMouseOver: handleMouseOver,
      ref: ref,
      role: "option",
      style: React.useMemo(function () {
        return {
          maxWidth: maxWidth
        };
      }, [maxWidth]),
      tabIndex: null,
      variant: isRemovable ? 'closable' : 'basic'
    }, restProps))
  );
});

/**
 * This hidden component is used to wrap a copy of an input value
 * so that we can use it to determine the input width dynamically
 */

var InputRuler = /*#__PURE__*/React.forwardRef(function InputRuler(props, ref) {
  var value = props.value;
  return (
    /*#__PURE__*/
    // TODO: Convert style to css
    React__default['default'].createElement("span", {
      style: {
        position: 'absolute',
        left: 0,
        whiteSpace: 'nowrap',
        visibility: 'hidden',
        overflow: 'hidden',
        maxWidth: '100%'
      },
      ref: ref
    }, value)
  );
});

var isPlainObject$1 = function isPlainObject(obj) {
  return Object.prototype.toString.call(obj) === '[object Object]';
};

var defaultItemToString = function defaultItemToString(item) {
  if (!isPlainObject$1(item)) {
    return String(item);
  }

  if (Object.prototype.hasOwnProperty.call(item, 'label')) {
    return String(item.label);
  }

  if (process.env.NODE_ENV !== 'production') {
    warning__default['default'](false, ["itemToString: you've likely forgotten to set the label prop on the item object.", 'You can also provide your own `itemToString` implementation.'].join('\n'));
  }

  return '';
};

function calcFirstHiddenIndex() {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      _ref$containerWidth = _ref.containerWidth,
      containerWidth = _ref$containerWidth === void 0 ? 0 : _ref$containerWidth,
      _ref$pillWidths = _ref.pillWidths,
      pillWidths = _ref$pillWidths === void 0 ? [] : _ref$pillWidths;

  var totalWidth = 0;
  var firstHiddenIndex = null;

  for (var i = 0; i < pillWidths.length; i++) {
    totalWidth += pillWidths[i];

    if (totalWidth > containerWidth) {
      firstHiddenIndex = i;
      break;
    }
  }

  return firstHiddenIndex;
}

/**
 * This monitors the size of a component and calls `onSizeChange` callback
 * every time when size changes.
 */

var useResizeObserver$2 = function useResizeObserver(onSizeChange) {
  var ref = React.useRef();
  React.useEffect(function () {
    var observer = new ResizeObserver(onSizeChange);
    observer.observe(ref.current);
    return function () {
      observer.disconnect();
    };
  }, [onSizeChange]);
  React.useLayoutEffect(function () {
    onSizeChange([{
      target: ref.current,
      contentRect: ref.current.getBoundingClientRect()
    }]);
  }, [onSizeChange]);
  return ref;
};

var INITIAL_INPUT_WIDTH = 5;

var getItemsAriaLabel = function getItemsAriaLabel(itemCount) {
  return itemCount === 0 ? 'no item selected' : "".concat(itemCount, " ").concat(itemCount > 1 ? 'items' : 'item');
};

var hasHelpers = function hasHelpers(helpers) {
  if (process.env.NODE_ENV !== 'production') {
    warning__default['default'](helpers != null, 'TokenizedInputBase is used without helpers. You should pass in "helpers" from "useTokenizedInput".');
  }

  return helpers != null;
};

var TokenizedInputBase = /*#__PURE__*/React.forwardRef(function TokenizedInputBase(props, ref) {
  var _props$InputProps = props.InputProps,
      InputProps = _props$InputProps === void 0 ? {} : _props$InputProps,
      _props$ExpandButtonPr = props.ExpandButtonProps,
      ExpandButtonProps = _props$ExpandButtonPr === void 0 ? {} : _props$ExpandButtonPr,
      className = props.className,
      _props$activeIndices = props.activeIndices,
      activeIndices = _props$activeIndices === void 0 ? [] : _props$activeIndices,
      _props$selectedItems = props.selectedItems,
      selectedItems = _props$selectedItems === void 0 ? [] : _props$selectedItems,
      highlightedIndex = props.highlightedIndex,
      value = props.value,
      focused = props.focused,
      expanded = props.expanded,
      disabled = props.disabled,
      onFocus = props.onFocus,
      onBlur = props.onBlur,
      onKeyUp = props.onKeyUp,
      onKeyDown = props.onKeyDown,
      onRemoveItem = props.onRemoveItem,
      onInputChange = props.onInputChange,
      onInputFocus = props.onInputFocus,
      onInputBlur = props.onInputBlur,
      onInputSelect = props.onInputSelect,
      onClear = props.onClear,
      onClick = props.onClick,
      helpers = props.helpers,
      inputRef = props.inputRef,
      _props$itemToString = props.itemToString,
      itemToString = _props$itemToString === void 0 ? defaultItemToString : _props$itemToString,
      idProp = props.id,
      densityProp = props.density,
      expandButtonRefProp = props.expandButtonRef,
      ariaLabel = props['aria-label'],
      ariaLabelledBy = props['aria-labelledby'],
      restProps = _objectWithoutProperties(props, ["InputProps", "ExpandButtonProps", "className", "activeIndices", "selectedItems", "highlightedIndex", "value", "focused", "expanded", "disabled", "onFocus", "onBlur", "onKeyUp", "onKeyDown", "onRemoveItem", "onInputChange", "onInputFocus", "onInputBlur", "onInputSelect", "onClear", "onClick", "helpers", "inputRef", "itemToString", "id", "density", "expandButtonRef", "aria-label", "aria-labelledby"]);

  var density = useDensity(densityProp);
  var id = useId(idProp);
  var inputId = "".concat(id, "-input");
  var expandButtonId = "".concat(id, "-expand-button");
  var clearButtonId = "".concat(id, "-clear-button"); // TODO: Use proper machanism to get variable values from theme in React. Something like below
  // getComputedStyle(document.documentElement)
  // .getPropertyValue('--my-variable-name'); // #999999

  var pillGroupPadding = 16;
  var lastVisiblePillMargin = 4;
  var pillsRef = React.useRef({});
  var inputRulerRef = React.useRef(null);
  var keydownExpandButton = React.useRef(false);

  var _useWidth = useWidth(density),
      _useWidth2 = _slicedToArray(_useWidth, 2),
      expandButtonRef = _useWidth2[0],
      expandButtonWidth = _useWidth2[1];

  var _useWidth3 = useWidth(density),
      _useWidth4 = _slicedToArray(_useWidth3, 2),
      clearButtonRef = _useWidth4[0],
      clearButtonWidth = _useWidth4[1];

  var _useState = React.useState(INITIAL_INPUT_WIDTH),
      _useState2 = _slicedToArray(_useState, 2),
      inputWidth = _useState2[0],
      setInputWidth = _useState2[1];

  var _useState3 = React.useState(null),
      _useState4 = _slicedToArray(_useState3, 2),
      pillGroupWidth = _useState4[0],
      setPillGroupWidth = _useState4[1];

  var _useState5 = React.useState(null),
      _useState6 = _slicedToArray(_useState5, 2),
      firstHiddenIndex = _useState6[0],
      setFirstHiddenIndex = _useState6[1];

  var showExpandButton = !expanded && firstHiddenIndex != null;
  var widthOffset = pillGroupPadding + INITIAL_INPUT_WIDTH + (expanded ? clearButtonWidth : expandButtonWidth);
  var pillMaxWidth = expanded ? pillGroupWidth - INITIAL_INPUT_WIDTH - lastVisiblePillMargin : 100;
  var containerRef = useResizeObserver$2(React.useCallback(function (_ref) {
    var _ref2 = _slicedToArray(_ref, 1),
        contentRect = _ref2[0].contentRect;

    setPillGroupWidth(contentRect.width - widthOffset);
  }, [widthOffset]));
  React.useLayoutEffect(function () {
    return function () {
      // When density changes, set hidden index to null so that pills are in their
      // readonly state before they are measured.
      setFirstHiddenIndex(null);
    };
  }, [density]); // useLayoutEffect because of potential layout change
  // We want to do that before paint to avoid layout jumps

  React.useLayoutEffect(function () {
    if (expanded) {
      setFirstHiddenIndex(null);
    } else if (pillGroupWidth != null) {
      setFirstHiddenIndex(calcFirstHiddenIndex({
        containerWidth: pillGroupWidth,
        pillWidths: Object.values(pillsRef.current).filter(Boolean)
      }));
    }
  }, // Additional dependency on selectedItems is for the controlled version
  [expanded, pillGroupWidth, selectedItems]);
  React.useLayoutEffect(function () {
    if (expanded && inputRulerRef.current) {
      var newInputWidth = inputRulerRef.current.scrollWidth;
      setInputWidth(Math.min(newInputWidth, pillGroupWidth));
    }
  }, [expanded, pillGroupWidth, value]);

  var handleExpandButtonKeyDown = function handleExpandButtonKeyDown(event) {
    var singleChar = event.key.length === 1;
    var triggerExpand = ['CONTROL', 'META', 'ENTER', 'BACKSPACE', 'ARROWDOWN', 'ARROWLEFT', 'ARROWRIGHT'].indexOf(event.key.toUpperCase()) !== -1;

    if ((singleChar || triggerExpand) && hasHelpers(helpers)) {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        event.stopPropagation();
      }

      helpers.updateExpanded(true);
      keydownExpandButton.current = true;
    }
  };

  var handleInputKeyUp = function handleInputKeyUp(event) {
    // Call keydown again if the initail event has been used to expand the input
    if (keydownExpandButton.current && 'Enter' !== event.key) {
      keydownExpandButton.current = false;

      if (onKeyDown) {
        onKeyDown(event);
      }
    }

    if (onKeyUp) {
      onKeyUp(event);
    }
  };

  var handleExpand = function handleExpand(event) {
    event.stopPropagation();

    if (hasHelpers(helpers)) {
      helpers.updateExpanded(true);
    }
  };

  var handleClearButtonFocus = function handleClearButtonFocus(event) {
    event.stopPropagation();

    if (hasHelpers(helpers)) {
      helpers.setFocused(false);
      helpers.cancelBlur();
    }
  };

  var selectedItemIds = selectedItems.map(function (_, index) {
    return "".concat(id, "-pill-").concat(index);
  });
  var inputAriaLabelledBy = disabled ? [ariaLabelledBy, inputId].concat(_toConsumableArray(selectedItemIds)) : [ariaLabelledBy, inputId];
  var mergedInputProps = deepmerge__default['default']({
    //  TODO: Convert to css nested override approach
    classes: {
      field: 'TokenizedInput-inputField',
      multiline: 'TokenizedInput-inputMultiline',
      root: classnames__default['default']('TokenizedInput-inputRoot', {
        'TokenizedInput-hidden': showExpandButton
      }),
      input: 'TokenizedInput-input'
    },
    inputProps: {
      style: {
        width: inputWidth,
        minWidth: inputWidth
      },
      'aria-label': [ariaLabel, getItemsAriaLabel(selectedItems.length)].filter(Boolean).join(' '),
      'aria-labelledby': inputAriaLabelledBy.filter(Boolean).join(' '),
      'aria-activedescendant': highlightedIndex >= 0 ? "".concat(id, "-pill-").concat(highlightedIndex) : null
    }
  }, InputProps);

  var expandButtonAccessibleText = ExpandButtonProps.accessibleText,
      restExpandButtonProps = _objectWithoutProperties(ExpandButtonProps, ["accessibleText"]);

  return /*#__PURE__*/React__default['default'].createElement("div", _extends({}, restProps, {
    className: classnames__default['default']('TokenizedInput', {
      'TokenizedInput-focused': focused,
      'TokenizedInput-expanded': expanded,
      'TokenizedInput-disabled': disabled
    }, "TokenizedInput-".concat(density, "Density"), className),
    id: id,
    onClick: onClick,
    ref: useForkRef(ref, containerRef)
  }), /*#__PURE__*/React__default['default'].createElement("span", {
    "aria-owns": selectedItemIds.join(' '),
    className: 'TokenizedInput-hidden',
    role: "listbox"
  }), /*#__PURE__*/React__default['default'].createElement("div", {
    className: 'TokenizedInput-pillGroup'
  }, selectedItems.map(function (item, index) {
    var label = itemToString(item);
    return /*#__PURE__*/React__default['default'].createElement(InputPill, {
      active: activeIndices.indexOf(index) !== -1 // TODO: Covert to css
      // classes={classes}
      ,
      density: density,
      disabled: disabled,
      hidden: showExpandButton && index >= firstHiddenIndex,
      highlighted: index === highlightedIndex,
      id: "".concat(id, "-pill-").concat(index),
      index: index,
      key: "".concat(index, "-").concat(label),
      label: label,
      lastVisible: !showExpandButton && index === selectedItems.length - 1,
      maxWidth: pillMaxWidth,
      onDelete: expanded ? onRemoveItem : null,
      pillsRef: pillsRef
    });
  }), /*#__PURE__*/React__default['default'].createElement(Button, _extends({
    "aria-labelledby": [ariaLabelledBy, inputId, expandButtonId].filter(Boolean).join(' '),
    className: classnames__default['default']('TokenizedInput-expandButton', {
      'TokenizedInput-hidden': !showExpandButton
    }),
    density: density,
    disabled: disabled,
    id: expandButtonId,
    onBlur: onBlur,
    onClick: handleExpand,
    onFocus: onFocus,
    onKeyDown: handleExpandButtonKeyDown,
    ref: useForkRef(expandButtonRef, expandButtonRefProp),
    variant: "secondary"
  }, restExpandButtonProps), /*#__PURE__*/React__default['default'].createElement(Icon, {
    accessibleText: expandButtonAccessibleText === undefined ? 'expand edit' : expandButtonAccessibleText,
    name: "overflow-menu"
  })), /*#__PURE__*/React__default['default'].createElement(Input, _extends({}, mergedInputProps, {
    className: "TokenizedInput-input",
    density: density,
    disabled: disabled,
    id: inputId,
    multiline: true,
    onBlur: onInputBlur,
    onChange: onInputChange,
    onFocus: onInputFocus,
    onKeyDown: onKeyDown,
    onKeyUp: handleInputKeyUp,
    onSelect: onInputSelect,
    renderSuffix: function renderSuffix() {
      return /*#__PURE__*/React__default['default'].createElement(InputRuler, {
        ref: inputRulerRef,
        value: value
      });
    },
    value: value,
    ref: inputRef
  }))), /*#__PURE__*/React__default['default'].createElement(Button, {
    className: classnames__default['default']('TokenizedInput-clearButton', {
      'TokenizedInput-hidden': !expanded || selectedItems.length === 0
    }),
    density: density,
    disabled: disabled,
    id: clearButtonId,
    onBlur: onBlur,
    onClick: onClear,
    onFocus: handleClearButtonFocus,
    ref: clearButtonRef,
    variant: "secondary"
  }, /*#__PURE__*/React__default['default'].createElement(Icon, {
    accessibleText: "clear input",
    name: "close"
  })));
});

var getCursorPosition = function getCursorPosition(inputRef) {
  if (inputRef.current) {
    var _inputRef$current = inputRef.current,
        selectionStart = _inputRef$current.selectionStart,
        selectionEnd = _inputRef$current.selectionEnd; // if there is no selection range

    if (selectionStart != null && selectionStart === selectionEnd) {
      return selectionStart;
    }
  }

  return -1;
};

var BLUR_TIMEOUT = 200;

var isValidItem = function isValidItem(data) {
  return typeof data === 'string' && Boolean(data.length) || typeof data !== 'string' && data != null;
};

var useTokenizedInput = function useTokenizedInput(props) {
  validateProps$2(props);

  var _useFormFieldProps = useFormFieldProps(),
      popoutMode = _useFormFieldProps.popoutMode,
      setIsPoppedOut = _useFormFieldProps.setIsPoppedOut,
      setManagedPopout = _useFormFieldProps.setManagedPopout,
      setIntendedHeight = _useFormFieldProps.setIntendedHeight;

  var density = props.density;

  var _useA11yProps = useA11yProps(),
      ariaLabelledBy = _useA11yProps['aria-labelledby'],
      a11yDisabled = _useA11yProps.disabled;

  var _props$delimiter = props.delimiter,
      delimiter = _props$delimiter === void 0 ? ',' : _props$delimiter,
      _props$initialSelecte = props.initialSelectedItems,
      initialSelectedItems = _props$initialSelecte === void 0 ? [] : _props$initialSelecte,
      _props$itemToString = props.itemToString,
      itemToString = _props$itemToString === void 0 ? defaultItemToString : _props$itemToString,
      _props$stringToItem = props.stringToItem,
      stringToItem = _props$stringToItem === void 0 ? function (_, value) {
    return value.trim();
  } : _props$stringToItem,
      _props$disabled = props.disabled,
      disabled = _props$disabled === void 0 ? a11yDisabled : _props$disabled,
      disableAddOnBlur = props.disableAddOnBlur,
      onFocus = props.onFocus,
      onBlur = props.onBlur,
      onClick = props.onClick,
      onExpand = props.onExpand,
      onCollapse = props.onCollapse,
      onKeyDown = props.onKeyDown,
      onInputSelect = props.onInputSelect,
      onInputChange = props.onInputChange,
      onInputFocus = props.onInputFocus,
      onInputBlur = props.onInputBlur,
      onClear = props.onClear,
      idProp = props.id,
      valueProp = props.value,
      expandedProp = props.expanded,
      selectedItemsProp = props.selectedItems,
      onChangeProp = props.onChange,
      ariaLabel = props['aria-label'],
      restProps = _objectWithoutProperties(props, ["delimiter", "initialSelectedItems", "itemToString", "stringToItem", "disabled", "disableAddOnBlur", "onFocus", "onBlur", "onClick", "onExpand", "onCollapse", "onKeyUp", "onKeyDown", "onInputSelect", "onInputChange", "onInputFocus", "onInputBlur", "onClear", "id", "value", "expanded", "selectedItems", "onChange", "aria-label"]);

  var id = useId(idProp);

  var _useControlled = useControlled({
    controlled: valueProp,
    "default": '',
    name: 'TokenizedInput',
    state: 'value'
  }),
      _useControlled2 = _slicedToArray(_useControlled, 3),
      value = _useControlled2[0],
      setValue = _useControlled2[1],
      isInputControlled = _useControlled2[2];

  var _useControlled3 = useControlled({
    controlled: selectedItemsProp,
    "default": initialSelectedItems,
    name: 'TokenizedInput',
    state: 'selectedItems'
  }),
      _useControlled4 = _slicedToArray(_useControlled3, 3),
      selectedItems = _useControlled4[0],
      setSelectedItems = _useControlled4[1],
      isSelectionControlled = _useControlled4[2];

  var _useControlled5 = useControlled({
    controlled: expandedProp,
    "default": false,
    name: 'TokenizedInput',
    state: 'expanded'
  }),
      _useControlled6 = _slicedToArray(_useControlled5, 3),
      expanded = _useControlled6[0],
      setExpanded = _useControlled6[1],
      isExpandedControlled = _useControlled6[2];

  var _useState = React.useState([]),
      _useState2 = _slicedToArray(_useState, 2),
      activeIndices = _useState2[0],
      setActiveIndices = _useState2[1];

  var _useState3 = React.useState(undefined),
      _useState4 = _slicedToArray(_useState3, 2),
      highlightedIndex = _useState4[0],
      setHighlightedIndex = _useState4[1];

  var _useState5 = React.useState(false),
      _useState6 = _slicedToArray(_useState5, 2),
      focused = _useState6[0],
      setFocusedState = _useState6[1];

  var inputRef = React.useRef(null);
  var blurTimeout = React.useRef(null);
  var preventBlurOnCopy = React.useRef(false);
  var hasActiveItems = Boolean(activeIndices.length);
  var delimiters = [].concat(delimiter);
  var primaryDelimiter = delimiters[0];
  var delimiterRegex = new RegExp(delimiters.map(escapeRegExp).join('|'), 'gi');
  var onChange = useEventCallback(function (args) {
    if (onChangeProp) {
      onChangeProp(args);
    }
  });
  var cancelBlur = React.useCallback(function () {
    clearTimeout(blurTimeout.current);
    blurTimeout.current = null;
  }, []);
  var focusInput = React.useCallback(function () {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, [popoutMode, setIsPoppedOut]);
  React.useEffect(function () {
    return function () {
      cancelBlur();
    };
  }, [cancelBlur]);
  React.useEffect(function () {
    if (expanded) {
      focusInput();
    }
  }, [expanded, focusInput]);
  React.useEffect(function () {
  }, [density, popoutMode, setIntendedHeight, setManagedPopout]);

  var updateInputValue = function updateInputValue(newValue) {
    if (!isInputControlled) {
      setValue(newValue);
    }
  };

  var updateSelectedItems = React.useCallback(function (action) {
    if (!isSelectionControlled) {
      setSelectedItems(function (prevSelectedItems) {
        var newItems = typeof action === 'function' ? action(prevSelectedItems) : action;

        if (newItems !== prevSelectedItems) {
          onChange(newItems);
        }

        return newItems;
      });
    } else {
      onChange(typeof action === 'function' ? action(selectedItems) : action);
    }
  }, [isSelectionControlled, setSelectedItems, onChange, selectedItems]);

  var updateExpanded = function updateExpanded(newExpanded) {
    if (!isExpandedControlled) {
      setExpanded(newExpanded);
    }

    if (newExpanded) {
      onExpand && onExpand();
    } else {
      onCollapse && onCollapse();
    }
  };

  var setFocused = function setFocused(newState) {
    setFocusedState(newState);
  };

  var resetInput = function resetInput() {
    updateInputValue('');
    setHighlightedIndex(undefined);
    setActiveIndices([]);
  };

  var removeItems = React.useCallback(function (itemIndices) {
    updateSelectedItems(function (prevSelectedItems) {
      return prevSelectedItems.length === 0 ? prevSelectedItems : prevSelectedItems.filter(function (_, index) {
        return itemIndices.indexOf(index) === -1;
      });
    });
  }, [updateSelectedItems]);

  var handleInputFocus = function handleInputFocus(event) {
    event.stopPropagation(); // The input will lose focus when building the text to copy in a temporary
    // DOM node. This is particularly visible in a slower browser, i.e. IE 11.
    // This is to prevent a blur in that scenario.

    if (preventBlurOnCopy.current) {
      preventBlurOnCopy.current = false;
      setActiveIndices(Array.from({
        length: selectedItems.length
      }, function (_, index) {
        return index;
      }));
      return;
    }

    setFocused(true);

    if (onInputFocus) {
      onInputFocus(event);
    }

    if (blurTimeout.current !== null) {
      cancelBlur();
    } else {
      updateExpanded(true);

      if (onFocus) {
        onFocus(event);
      }
    }
  };

  var handleInputBlur = function handleInputBlur(event) {
    event.stopPropagation();
    setFocused(false);
    setHighlightedIndex(undefined);
    setActiveIndices([]);

    if (onInputBlur) {
      onInputBlur(event);
    }

    handleBlur(event);
  };

  var handleBlur = function handleBlur(event) {
    if (preventBlurOnCopy.current) {
      return focusInput();
    }

    event.persist();
    blurTimeout.current = setTimeout(function () {
      blurTimeout.current = null;
      updateExpanded(false);

      if (!disableAddOnBlur) {
        handleAddItems(value, true);
      }

      if (onBlur) {
        onBlur(event);
      }
    }, BLUR_TIMEOUT);
  };

  var handleClick = function handleClick(event) {
    updateExpanded(true);
    setActiveIndices([]);
    focusInput();

    if (onClick) {
      onClick(event);
    }
  };

  var handleInputChange = function handleInputChange(event) {
    setHighlightedIndex(undefined);

    if (onInputChange) {
      onInputChange(event);
    }

    var newValue = event.target.value;

    if (delimiterRegex.test(newValue)) {
      // Process value with delimiters
      handleAddItems(newValue);
    } else {
      // Just update input value if there is no delimiter
      updateInputValue(newValue);
    }
  };

  var handleAddItems = function handleAddItems(newValue, appendOnly) {
    if (newValue.length === 0) {
      return;
    }

    resetInput();
    var newItems = newValue.split(delimiterRegex).reduce(function (values, part) {
      var newItem = stringToItem(hasActiveItems ? values : selectedItems.concat(values), part);
      return isValidItem(newItem) ? values.concat(newItem) : values;
    }, []);

    if (newItems.length) {
      updateSelectedItems(function (prevSelectedItems) {
        return hasActiveItems && !appendOnly ? newItems : prevSelectedItems.concat(newItems);
      });
    }
  };

  var handleRemoveItem = React.useCallback(function (itemIndex) {
    focusInput();
    removeItems([itemIndex]);
  }, [focusInput, removeItems]);

  var handleClear = function handleClear(event) {
    updateSelectedItems([]);
    resetInput();
    focusInput();

    if (onClear) {
      onClear(event);
    }
  };

  var cursorAtInputStart = function cursorAtInputStart() {
    return getCursorPosition(inputRef) === 0 && Boolean(selectedItems.length);
  };

  var highlightAtPillGroupEnd = function highlightAtPillGroupEnd() {
    return highlightedIndex === selectedItems.length - 1;
  };

  var pillGroupKeyDownHandlers = {
    ArrowLeft: function ArrowLeft(event) {
      event.preventDefault();
      setHighlightedIndex(function (prevHighlightedIndex) {
        return prevHighlightedIndex == null ? selectedItems.length - 1 : Math.max(0, prevHighlightedIndex - 1);
      });
    },
    ArrowRight: function ArrowRight(event) {
      if (highlightAtPillGroupEnd()) {
        return setHighlightedIndex(undefined);
      }

      event.preventDefault();
      setHighlightedIndex(function (prevHighlightedIndex) {
        return prevHighlightedIndex == null ? prevHighlightedIndex : Math.min(selectedItems.length - 1, prevHighlightedIndex + 1);
      });
    },
    Backspace: function Backspace(event) {
      event.preventDefault();
      handleRemoveItem(highlightedIndex);
      setHighlightedIndex(function (prevHighlightedIndex) {
        return prevHighlightedIndex == null ? prevHighlightedIndex : Math.max(0, prevHighlightedIndex - 1);
      });
    },
    Home: function Home(event) {
      event.preventDefault();
      setHighlightedIndex(0);
    },
    End: function End(event) {
      event.preventDefault();
      setHighlightedIndex(selectedItems.length - 1);
    },
    Enter: function Enter(event) {
      event.preventDefault();
      handleRemoveItem(highlightedIndex);
    },
    Delete: function Delete(event) {
      event.preventDefault();
      handleRemoveItem(highlightedIndex);
    },
    ' ': function _(event) {
      event.preventDefault();
      handleRemoveItem(highlightedIndex);
    }
  };
  var inputKeyDownHandlers = {
    ArrowLeft: function ArrowLeft(event) {
      if (cursorAtInputStart()) {
        event.preventDefault();
        setHighlightedIndex(selectedItems.length - 1);
      }
    },
    Backspace: function Backspace() {
      if (hasActiveItems) {
        removeItems(activeIndices);
      } else if (cursorAtInputStart()) {
        setHighlightedIndex(selectedItems.length - 1);
      }
    },
    Delete: function Delete() {
      if (hasActiveItems) {
        removeItems(activeIndices);
      }
    },
    Enter: function Enter(event) {
      event.preventDefault();

      if (hasActiveItems) {
        removeItems(activeIndices);
      } else {
        handleAddItems(value);
      }
    }
  }; // eslint-disable-next-line complexity

  var handleCtrlModifierKeyDown = function handleCtrlModifierKeyDown(event) {
    var win = ownerWindow(event.target);
    var supportClipboard = win.navigator && win.navigator.clipboard;

    switch (event.key.toUpperCase()) {
      case 'A':
        // Select all
        setHighlightedIndex(undefined);
        setActiveIndices(Array.from({
          length: selectedItems.length
        }, function (_, index) {
          return index;
        }));
        break;

      case 'C':
        // Copy
        copy__default['default'](activeIndices.map(function (index) {
          return itemToString(selectedItems[index]);
        }).concat(value != null ? String(value).trim() : '').filter(Boolean).join(primaryDelimiter)).then(function (result) {
          preventBlurOnCopy.current = !supportClipboard;
          return result;
        })["catch"](function (error) {
          warning__default['default'](false, error);
        });
        break;

      case 'V':
        // Paste - do nothing and let handleChange deal with it
        break;

      case 'ARROWLEFT':
        // eslint-disable-next-line new-cap
        pillGroupKeyDownHandlers.ArrowLeft(event);
        break;

      case 'ARROWRIGHT':
        // eslint-disable-next-line new-cap
        pillGroupKeyDownHandlers.ArrowRight(event);
        break;

      case 'BACKSPACE':
        if (cursorAtInputStart()) {
          handleRemoveItem(selectedItems.length - 1);
        }

        break;

      case 'CONTROL':
      case 'META':
        // Do nothing
        break;

      default:
        // Otherwise, reset active items
        setActiveIndices([]);
    }
  };

  var handleCommonKeyDown = function handleCommonKeyDown(event) {
    var eventKey = event.key.toUpperCase();

    if (eventKey === 'ESCAPE') {
      event.preventDefault();
      resetInput();
    } else if (eventKey === 'TAB' && !disableAddOnBlur) {
      // Pressing Tab adds a new value
      handleAddItems(value);
    }
  };

  var handleKeyDown = function handleKeyDown(event) {
    if (event.ctrlKey || event.metaKey || ['CONTROL', 'META'].indexOf(event.key.toUpperCase()) !== -1) {
      handleCtrlModifierKeyDown(event);
    } else {
      var handler;

      if (highlightedIndex == null) {
        handler = inputKeyDownHandlers[event.key];
        setActiveIndices([]);
      } else {
        handler = pillGroupKeyDownHandlers[event.key];
      }

      if (handler != null) {
        handler(event);
      } else {
        handleCommonKeyDown(event);
      }
    }

    if (onKeyDown) {
      onKeyDown(event);
    }
  };

  var state = {
    value: value,
    selectedItems: selectedItems,
    activeIndices: activeIndices,
    highlightedIndex: highlightedIndex,
    expanded: expanded,
    focused: focused
  };
  var eventHandlers = {
    // onFocus is a focus on the expand button
    // It can also be triggered by a focus on the input
    onFocus: onFocus,
    // onBlur is a blur from the expand button when it's collapsed
    // It can also be triggered by the clear button
    onBlur: expanded ? handleBlur : onBlur,
    onClick: handleClick,
    onInputSelect: onInputSelect,
    onInputChange: handleInputChange,
    onInputFocus: handleInputFocus,
    onInputBlur: handleInputBlur,
    onKeyDown: handleKeyDown,
    onRemoveItem: handleRemoveItem,
    onClear: handleClear
  };
  return {
    inputRef: inputRef,
    state: state,
    helpers: {
      cancelBlur: cancelBlur,
      setValue: setValue,
      setSelectedItems: setSelectedItems,
      setHighlightedIndex: setHighlightedIndex,
      setFocused: setFocused,
      updateExpanded: updateExpanded
    },
    inputProps: _objectSpread2(_objectSpread2(_objectSpread2({
      id: id,
      itemToString: itemToString,
      disabled: disabled,
      'aria-labelledby': ariaLabelledBy,
      'aria-label': ariaLabel
    }, state), restProps), disabled ? {} : eventHandlers)
  };
};

var validateProps$2 = function validateProps(props) {
  if (process.env.NODE_ENV !== 'production') {
    var delimiter = props.delimiter;
    /* eslint-disable react-hooks/rules-of-hooks */

    React.useEffect(function () {
      warning__default['default'](delimiter == null || isValidDelimiter(delimiter) || Array.isArray(delimiter) && delimiter.every(isValidDelimiter), 'TokenizedInput delimiter should be a single character or an array of single characters');
    }, [delimiter]);
    /* eslint-enable react-hooks/rules-of-hooks */
  }
};

var isValidDelimiter = function isValidDelimiter(value) {
  return typeof value === 'string' && value.length === 1;
};

var css_248z$w = ".TokenizedInput-touchDensity {\n  --tokenized-input-spacing: var(--uitk-space-touch);\n  --tokenized-input-height: var(--uitk-size-regular-touch);\n  --tokenized-input-gutter-size: var(--uitk-size-base);\n  --tokenized-input-pill-group-y-padding: calc(var(--uitk-space-touch) / 2 + 2);\n  --tokenized-input-last-pill-margin: calc(var(--uitk-space-touch) / 2);\n}\n\n.TokenizedInput-lowDensity {\n  --tokenized-input-spacing: var(--uitk-space-low);\n  --tokenized-input-height: var(--uitk-size-regular-low);\n  --tokenized-input-gutter-size: var(--uitk-size-base);\n  --tokenized-input-pill-group-y-padding: calc(var(--uitk-space-low) / 2 + 1);\n  --tokenized-input-last-pill-margin: calc(var(--uitk-space-low) / 2);\n}\n\n.TokenizedInput-mediumDensity {\n  --tokenized-input-spacing: var(--uitk-space-medium);\n  --tokenized-input-height: var(--uitk-size-regular-medium);\n  --tokenized-input-gutter-size: var(--uitk-size-base);\n  --tokenized-input-pill-group-y-padding: calc(var(--uitk-space-medium) / 2);\n  --tokenized-input-last-pill-margin: var(--uitk-space-medium);\n}\n\n.TokenizedInput-highDensity {\n  --tokenized-input-spacing: var(--uitk-space-high);\n  --tokenized-input-height: var(--uitk-size-regular-high);\n  --tokenized-input-gutter-size: calc(var(--uitk-size-base) - 1);\n  --tokenized-input-pill-group-y-padding: calc(var(--uitk-space-high) / 2 + 1);\n  --tokenized-input-last-pill-margin: var(--uitk-space-high);\n}\n\n.TokenizedInput {\n  display: inline-flex;\n  justify-content: space-between;\n  /* same min-width as the Input component */\n  min-width: 8em;\n  width: 100%;\n\n  /* TODO: Check whether we should define font family here or rely on theme */\n  font-family: var(--uitk-font-family);\n}\n\n.TokenizedInput-disabled {\n  /* TODO: When shared disabled styles are ready */\n  cursor: not-allowed;\n  opacity: 0.7;\n}\n\n.TokenizedInput:hover:not(.TokenizedInput-disabled) {\n  cursor: 'pointer';\n}\n\n.TokenizedInput-focused {\n  /* TODO: Use shared focused style when ready */\n  outline-color: #2670a9;\n  outline-style: dotted;\n  outline-width: 2px;\n  outline-offset: 0;\n}\n\n.TokenizedInput-expanded {\n  height: auto;\n}\n\n.TokenizedInput-hidden {\n  display: none;\n}\n\n/* Used to be .inputRoot */\n.TokenizedInput-input {\n  flex-grow: 1;\n  padding: 0;\n  outline: none;\n  width: auto;\n  height: auto;\n  min-width: 0;\n  min-height: 0;\n}\n\n.TokenizedInput-clearButton {\n  flex: none;\n  align-self: flex-end;\n}\n\n.TokenizedInput-expandButton {\n  padding: 0 calc(var(--tokenized-input-spacing) / 4);\n}\n\n.TokenizedInput-pillGroup {\n  min-height: var(--tokenized-input-height);\n  padding: var(--tokenized-input-pill-group-y-padding)\n    var(--tokenized-input-spacing);\n\n  display: flex;\n  flex: 1;\n  flex-wrap: wrap;\n  align-content: flex-start;\n  box-sizing: border-box;\n}\n\n.TokenizedInput-expanded,\n.TokenizedInput-expanded .TokenizedInput-pillGroup {\n  height: auto;\n}\n\n/* TODO: Adjust specificity of .InputPill depending on styling solution. This is an example of internal sub-component naming convension. */\n.TokenizedInput .InputPill,\n.TokenizedInput-expandButton,\n.TokenizedInput-input,\n.TokenizedInput-inputField.TokenizedInput-inputMultiline .TokenizedInput-input {\n  margin: calc(var(--tokenized-input-gutter-size) / 2) 0;\n  height: calc(\n    var(--tokenized-input-height) - var(--tokenized-input-spacing) * 1.5\n  );\n}\n\n.TokenizedInput .InputPill {\n  min-width: 0;\n  margin-right: var(--tokenized-input-gutter-size);\n}\n\n.TokenizedInput .InputPill > * {\n  min-width: 0;\n}\n\n.TokenizedInput .InputPill.InputPill-hidden {\n  display: none;\n}\n\n.TokenizedInput .InputPill-pillLastVisible {\n  margin-right: var(--tokenized-input-last-pill-margin);\n}\n\n.TokenizedInput .InputPill-pillActive {\n  background: var(--uitk-select-active-background);\n}\n\n.TokenizedInput .InputPill-pillActive .Pill-deleteIcon {\n  color: var(--uitk-action-cta-hover-icon);\n}\n\n.TokenizedInput .InputPill-pillActive .Pill-deleteButton {\n  color: var(--uitk-action-cta-hover-icon);\n  background: var(--uitk-action-cta-hover-background);\n}\n";
styleInject(css_248z$w);

var TokenizedInput = /*#__PURE__*/React.forwardRef(function TokenizedInput(props, ref) {
  var Tooltip = props.Tooltip,
      tooltipEnterDelay = props.tooltipEnterDelay,
      tooltipLeaveDelay = props.tooltipLeaveDelay,
      tooltipPlacement = props.tooltipPlacement,
      inputRefProp = props.inputRef,
      restProps = _objectWithoutProperties(props, ["Tooltip", "tooltipEnterDelay", "tooltipLeaveDelay", "tooltipPlacement", "inputRef"]);

  var _useTokenizedInput = useTokenizedInput(restProps),
      inputRef = _useTokenizedInput.inputRef,
      helpers = _useTokenizedInput.helpers,
      inputProps = _useTokenizedInput.inputProps;

  var value = React.useMemo(function () {
    return {
      Tooltip: Tooltip,
      enterDelay: tooltipEnterDelay,
      leaveDelay: tooltipLeaveDelay,
      placement: tooltipPlacement
    };
  }, [Tooltip, tooltipEnterDelay, tooltipLeaveDelay, tooltipPlacement]);
  return /*#__PURE__*/React__default['default'].createElement(TooltipContext.Provider, {
    value: value
  }, /*#__PURE__*/React__default['default'].createElement(TokenizedInputBase, _extends({
    helpers: helpers,
    inputRef: useForkRef(inputRef, inputRefProp),
    ref: ref
  }, inputProps)));
});

var css_248z$x = ".ToolbarField {\n  align-items: center;\n  box-sizing: border-box;\n  height: var(--uitk-toolbarfield-height);\n  display: flex;\n  justify-content: center;\n  margin: var(--uitk-toolbarfield-spacing);\n  width: var(--uitk-toolbarfield-width);\n}\n\n.ToolbarField + .Tooltray:before {\n  background: var(--uitk-toolbar-separator-color, var(--uitk-grey60));\n  height: 100%;\n  content: '';\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 1px;\n}\n";
styleInject(css_248z$x);

var ToolbarField = function ToolbarField(_ref) {
  var children = _ref.children,
      props = _objectWithoutProperties(_ref, ["children"]);

  return /*#__PURE__*/React__default['default'].createElement("div", _extends({}, props, {
    className: "ToolbarField"
  }), children);
};

var css_248z$y = ".Tooltray {\n  /* display: flex;\n    flex-wrap: nowrap; */\n  flex-shrink: 0;\n  flex-grow: 0;\n  position: relative;\n}\n\n/* is this the same as toolbar */\n.Tooltray .Responsive-inner {\n  align-items: flex-start;\n  display: flex;\n  flex: 1;\n  flex-wrap: nowrap; /* if collaps = dynamic */\n  min-height: var(--uitk-toolbar-height);\n  justify-content: inherit;\n  width: 100%;\n}\n\n.Tooltray[data-collapsible='dynamic'] {\n  /* flex-shrink: 1; */\n  min-width: 36x;\n}\n\n.Tooltray[data-collapsible='dynamic'] .Responsive-inner {\n  flex-wrap: wrap;\n}\n\n.Tooltray:not(:last-child):after {\n  background: var(--uitk-toolbar-separator-color, var(--uitk-grey60));\n  height: 100%;\n  content: '';\n  position: absolute;\n  top: 0;\n  right: 0;\n  width: 1px;\n}\n";
styleInject(css_248z$y);

var renderTools = function renderTools(items) {
  var tools = [];
  var index = tools.length - 1;
  return tools.concat(items.map(function (tool) {
    index += 1;

    if ( /*#__PURE__*/React__default['default'].isValidElement(tool)) {
      if (tool.type === Tooltray) {
        var _tool$props$dataPrio;

        return /*#__PURE__*/React__default['default'].cloneElement(tool, {
          className: classnames__default['default']('Toolbar-item', tool.props.className),
          'data-index': index,
          'data-priority': (_tool$props$dataPrio = tool.props['data-priority']) !== null && _tool$props$dataPrio !== void 0 ? _tool$props$dataPrio : 2
        });
      } else {
        if (Object.keys(tool.props).some(isResponsiveAttribute)) {
          var _extractResponsivePro = extractResponsiveProps(tool.props),
              _extractResponsivePro2 = _slicedToArray(_extractResponsivePro, 2),
              toolbarProps = _extractResponsivePro2[0],
              props = _extractResponsivePro2[1];

          return /*#__PURE__*/React__default['default'].createElement(ToolbarField, _extends({}, toolbarProps, {
            "data-index": index,
            "data-priority": 2,
            key: index
          }), /*#__PURE__*/React__default['default'].cloneElement(tool, props));
        } else {
          return /*#__PURE__*/React__default['default'].createElement(ToolbarField, {
            "data-index": index,
            "data-priority": 2,
            key: index
          }, tool);
        }
      }
    }
  }));
};

var Tooltray = function Tooltray(_ref) {
  var children = _ref.children,
      classNameProp = _ref.className,
      collapseProp = _ref.collapse,
      collapsedProp = _ref.collapsed,
      _ref$dataCollapsible = _ref['data-collapsible'],
      collapse = _ref$dataCollapsible === void 0 ? collapseProp : _ref$dataCollapsible,
      _ref$dataCollapsed = _ref['data-collapsed'],
      collapsed = _ref$dataCollapsed === void 0 ? collapsedProp : _ref$dataCollapsed,
      _ref$orientation = _ref.orientation,
      orientation = _ref$orientation === void 0 ? 'horizontal' : _ref$orientation,
      rest = _objectWithoutProperties(_ref, ["align", "children", "className", "collapse", "collapsed", "data-collapsible", "data-collapsed", "orientation"]);

  var className = classnames__default['default']('Tooltray', classNameProp);

  var _useOverflowObserver = useOverflowObserver(orientation, 'Tooltray'),
      _useOverflowObserver2 = _slicedToArray(_useOverflowObserver, 2),
      innerContainerRef = _useOverflowObserver2[0],
      overflowedItems = _useOverflowObserver2[1];

  var childIsFunction = typeof children === 'function';
  var collapsible = childIsFunction ? 'instant' : collapse;
  var tooltrayProps = {
    className: className,
    'data-collapsed': collapsed,
    'data-collapsible': collapsible
  };
  var tooltrayItems = React__default['default'].Children.toArray(childIsFunction ? children({
    collapsed: collapsed
  }) : children);
  return /*#__PURE__*/React__default['default'].createElement("div", _extends({}, rest, tooltrayProps), /*#__PURE__*/React__default['default'].createElement("div", {
    className: "Responsive-inner",
    ref: innerContainerRef
  }, renderTools(tooltrayItems), overflowedItems.length > 0 ? /*#__PURE__*/React__default['default'].createElement(ToolbarField, {
    "data-overflow-indicator": true,
    "data-pad-left": true,
    "data-priority": 1
  }, /*#__PURE__*/React__default['default'].createElement(OverflowMenu, {
    className: "Toolbar-overflowMenu",
    "data-pad-left": true,
    "data-priority": 1,
    "data-index": tooltrayItems.length - 1,
    key: "overflow",
    source: overflowedItems
  })) : null));
};

var css_248z$z = ".uitk-light .Toolbar {\n  --uitk-toolbar-color: var(--uitk-grey400);\n  --uitk-toolbar-separator-color: var(--uitk-grey60);\n}\n\n.uitk-dark .Toolbar {\n  --uitk-toolbar-color: var(--uitk-grey40);\n  --uitk-toolbar-separator-color: var(--uitk-grey400);\n}\n\n.Toolbar,\n.Tooltray {\n  --uitk-toolbar-spacing: var(--uitk-space);\n\n  --three-qtr-spacing: calc(var(--uitk-toolbar-spacing) * 0.75);\n  --label-margin-right: var(--uitk-toolbar-spacing);\n  align-items: flex-start;\n  box-sizing: border-box;\n  color: var(--uitk-toolbar-color);\n  font-size: var(--uitk-font-size-regular);\n  justify-content: flex-start;\n  overflow: hidden;\n  position: relative;\n  font-family: var(--uitk-font-family);\n  min-width: 28px;\n}\n\n.Toolbar-vertical {\n  --uitk-toolbarfield-height: auto;\n  --uitk-toolbarfield-spacing: calc(var(--uitk-toolbar-spacing) * 0.5) 0;\n  --uitk-toolbarfield-width: var(--uitk-toolbar-depth);\n  height: 100%;\n  width: var(--uitk-toolbar-depth);\n}\n\n.Toolbar-horizontal {\n  --uitk-toolbarfield-height: var(--uitk-toolbar-depth);\n  --uitk-toolbarfield-spacing: 0 calc(var(--uitk-toolbar-spacing) * 0.5);\n  --uitk-toolbarfield-width: auto;\n  height: var(--uitk-toolbar-depth, 36px);\n  padding: 0 var(--uitk-toolbar-spacing);\n}\n\n.Toolbar-vertical .Tooltray {\n  width: var(--uitk-toolbar-depth);\n}\n\n.Toolbar-horizontal .Tooltray {\n  height: var(--uitk-toolbar-depth, 36px);\n}\n\n.Toolbar-vertical {\n  padding: var(--uitk-toolbar-spacing) 0;\n}\n\n.Toolbar.sm {\n  background-color: pink;\n}\n\n.Toolbar.md {\n  background-color: yellow;\n}\n\n.Toolbar .Responsive-inner {\n  align-items: flex-start;\n  flex: 1;\n  flex-wrap: wrap; /* switch to wrap when collapse exhausted */\n  justify-content: inherit;\n}\n\n.Responsive-inner {\n  margin: 0 !important;\n  padding: 0 !important;\n}\n\n.Toolbar-horizontal .Responsive-inner {\n  display: flex;\n  flex-direction: row;\n  min-height: var(--uitk-toolbar-height);\n}\n.Toolbar-vertical .Responsive-inner {\n  display: inline-flex;\n  flex-direction: column;\n  max-height: 100%;\n}\n\n/* .Toolbar .Tool {\n  border: solid 1px lightgrey;\n  box-sizing: border-box;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  margin: 6px 3px;\n} */\n\n.Responsive-inner > .Icon {\n  border: solid 1px lightgrey;\n  box-sizing: border-box;\n  height: 22px;\n  padding: 1px;\n  width: 22px;\n}\n\n.Responsive-inner > [data-pad-left] {\n  margin-left: auto !important;\n}\n.Responsive-inner > [data-pad-right] {\n  margin-right: auto !important;\n}\n\n.Responsive-inner > .Icon {\n  margin: 5px 3px;\n}\n\n[data-overflowed] > .Responsive-inner {\n  flex-wrap: wrap !important;\n}\n\n.Toolbar > * {\n  display: inline-block;\n}\n\n.Toolbar .Tooltray > .Icon {\n  margin: 5px 0;\n  padding: 1px 3px;\n  width: 26px;\n}\n\n.Toolbar > .Responsive-inner[data-collapsing='true'] {\n  flex-wrap: nowrap !important;\n}\n\n[data-collapsible='dynamic'] {\n  flex-shrink: 0;\n  /* background-color: rgba(255, 0, 0, 0.15); */\n}\n\n[data-collapsible='dynamic'][data-collapsing='true'] {\n  flex-shrink: 1;\n  min-width: calc(var(--uitk-size-regular) + var(--uitk-space));\n  /* background-color: rgba(255, 255, 0.3); */\n}\n\n[data-collapsible='dynamic'][data-collapsed='true'] {\n  flex-shrink: 0;\n  flex-grow: 0;\n  /* do we need to allow for standard spacing ? */\n  flex-basis: calc(var(--uitk-size-regular) + var(--uitk-space));\n  /* background-color: rgba(255, 125, 0.1); */\n}\n\n.Toolbar .Tooltray .Icon:not(:first-child) {\n  border-left: none;\n}\n\n/* .Tooltray:not(:last-child) > :last-child {\n  margin-right: var(--uitk-toolbar-spacing);\n  padding-right: var(--uitk-toolbar-spacing);\n} */\n\n.OverflowContainer {\n  background-color: white;\n}\n\n.Popup .Toolbar {\n  min-width: 80px;\n  height: auto;\n}\n\n.Popup .Toolbar .Tooltray {\n  white-space: nowrap;\n}\n\n.Toolbar .tool-text {\n  width: 80px;\n  border-radius: 0;\n  border: solid 1px darkgrey;\n  border: none;\n}\n";
styleInject(css_248z$z);

var renderTools$1 = function renderTools(items) {
  var collapsedItems = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
  var tools = [];
  var index = tools.length - 1;
  var rightAlign = false;
  return tools.concat(items.map(function (tool) {
    index += 1; // index is a fragile way to link these, we need some kind of id and map

    var collapsed = collapsedItems.findIndex(function (item) {
      return item.index === index;
    }) === -1 ? undefined : true;
    var dataPadLeft = undefined;

    if ( /*#__PURE__*/React__default['default'].isValidElement(tool)) {
      var _tool$props$dataPrio;

      if (tool.props.align === 'right' && !rightAlign) {
        rightAlign = true;
        dataPadLeft = true;
      }

      var toolbarItemProps = {
        className: classnames__default['default']('Toolbar-item', tool.props.className),
        'data-index': index,
        'data-priority': (_tool$props$dataPrio = tool.props['data-priority']) !== null && _tool$props$dataPrio !== void 0 ? _tool$props$dataPrio : 2,
        'data-pad-left': dataPadLeft,
        'data-collapsed': collapsed
      };

      if (tool.type === Tooltray || tool.type === Tabstrip) {
        return /*#__PURE__*/React__default['default'].cloneElement(tool, _objectSpread2({}, toolbarItemProps));
      } else if (tool.type === ToolbarField) {
        return /*#__PURE__*/React__default['default'].cloneElement(tool, toolbarItemProps);
      } else {
        var _ref = Object.keys(tool.props).some(isResponsiveAttribute) ? extractResponsiveProps(tool.props) : [{}, tool.props],
            _ref2 = _slicedToArray(_ref, 2),
            toolbarProps = _ref2[0],
            props = _ref2[1];

        return /*#__PURE__*/React__default['default'].createElement(ToolbarField, _extends({}, toolbarProps, toolbarItemProps, {
          key: index
        }), props === tool.props ? tool : /*#__PURE__*/React__default['default'].cloneElement(tool, props));
      }
    }
  }));
};

var Toolbar = function Toolbar(_ref3) {
  var children = _ref3.children,
      className = _ref3.className,
      id = _ref3.id,
      _ref3$orientation = _ref3.orientation,
      orientation = _ref3$orientation === void 0 ? 'horizontal' : _ref3$orientation,
      style = _ref3.style,
      toolsProp = _ref3.tools,
      _ref3$getTools = _ref3.getTools,
      getTools = _ref3$getTools === void 0 ? function () {
    return toolsProp || React__default['default'].Children.toArray(children);
  } : _ref3$getTools,
      rootProps = _objectWithoutProperties(_ref3, ["children", "className", "id", "maxRows", "orientation", "style", "title", "tools", "stops", "getTools"]);

  var root = React.useRef(null);

  var _useOverflowObserver = useOverflowObserver(orientation, 'Toolbar'),
      _useOverflowObserver2 = _slicedToArray(_useOverflowObserver, 3),
      innerContainerRef = _useOverflowObserver2[0],
      overflowedItems = _useOverflowObserver2[1],
      collapsedItems = _useOverflowObserver2[2];

  var tools = getTools();
  return /*#__PURE__*/React__default['default'].createElement("div", _extends({}, rootProps, {
    id: id // breakPoints={stops}
    ,
    className: classnames__default['default']('Toolbar', "Toolbar-".concat(orientation), className),
    ref: root // onResize={setSize}
    ,
    style: style
  }), /*#__PURE__*/React__default['default'].createElement("div", {
    className: "Responsive-inner",
    ref: innerContainerRef
  }, renderTools$1(tools, collapsedItems), overflowedItems.length > 0 ? /*#__PURE__*/React__default['default'].createElement(ToolbarField, {
    "data-overflow-indicator": true,
    "data-pad-left": true,
    "data-priority": 1
  }, /*#__PURE__*/React__default['default'].createElement(OverflowMenu, {
    className: "Toolbar-overflowMenu",
    "data-pad-left": true,
    "data-priority": 1,
    "data-index": tools.length - 1,
    key: "overflow",
    source: overflowedItems
  })) : null));
};
 // registerComponent('Toolbar', Toolbar);

exports.AppHeader = AppHeader;
exports.Button = Button;
exports.ButtonBar = ButtonBar;
exports.ButtonVariantValues = ButtonVariantValues;
exports.Checkbox = Checkbox;
exports.CheckboxBase = CheckboxBase;
exports.CheckboxCheckedIcon = CheckboxCheckedIcon;
exports.CheckboxIcon = CheckboxIcon;
exports.CheckboxIndeterminateIcon = CheckboxIndeterminateIcon;
exports.ControlLabel = ControlLabel;
exports.DefaultButtonsOrderByVariant = DefaultButtonsOrderByVariant;
exports.DensityValues = DensityValues;
exports.Dialog = Dialog;
exports.DialogActions = DialogActions;
exports.DialogContent = DialogContent;
exports.DialogTitle = DialogTitle;
exports.Dropdown = Dropdown;
exports.DropdownButton = DropdownButton;
exports.Icon = Icon;
exports.IconClassNameConsumer = IconClassNameConsumer;
exports.IconClassNameContext = IconClassNameContext;
exports.IconClassNameProvider = IconClassNameProvider;
exports.Input = Input;
exports.List = List;
exports.ListBase = ListBase;
exports.ListStateContext = ListStateContext;
exports.Logo = Logo;
exports.MultiSelectDropdown = MultiSelectDropdown;
exports.OrderedButton = OrderedButton;
exports.Pill = Pill;
exports.Popper = Popper;
exports.Scrim = Scrim;
exports.ScrimContext = ScrimContext;
exports.Spinner = Spinner;
exports.Switch = Switch;
exports.Tab = Tab;
exports.Tabstrip = Tabstrip;
exports.ThemeConsumer = ThemeConsumer;
exports.ThemeContext = ThemeContext;
exports.ThemeProvider = ThemeProvider;
exports.TokenizedInput = TokenizedInput;
exports.TokenizedInputBase = TokenizedInputBase;
exports.Toolbar = Toolbar;
exports.ToolbarField = ToolbarField;
exports.Tooltip = Tooltip;
exports.TooltipContext = TooltipContext;
exports.Tooltray = Tooltray;
exports.breakpointRamp = breakpointRamp;
exports.getBreakPoints = getBreakPoints;
exports.getSvgSpinner = getSvgSpinner;
exports.installTheme = installTheme;
exports.itemToString = itemToString;
exports.useDensity = useDensity;
exports.useList = useList;
exports.usePopperPositioning = usePopperPositioning;
exports.useTheme = useTheme;
exports.useThemeProps = useThemeProps;
exports.useTokenizedInput = useTokenizedInput;
exports.useTypeSelect = useTypeSelect;
//# sourceMappingURL=uitk-toolkit.cjs.js.map
