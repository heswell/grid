export function useTokenizedInput(props: any): {
    inputRef: import("react").MutableRefObject<null>;
    state: {
        value: any;
        selectedItems: any;
        activeIndices: never[];
        highlightedIndex: undefined;
        expanded: any;
        focused: boolean;
    };
    helpers: {
        cancelBlur: () => void;
        setValue: any;
        setSelectedItems: any;
        setHighlightedIndex: import("react").Dispatch<import("react").SetStateAction<undefined>>;
        setFocused: (newState: any) => void;
        updateExpanded: (newExpanded: any) => void;
    };
    inputProps: any;
};
