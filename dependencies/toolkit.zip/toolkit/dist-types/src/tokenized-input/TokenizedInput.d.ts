export const TokenizedInput: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
export default TokenizedInput;
import React from "react";
