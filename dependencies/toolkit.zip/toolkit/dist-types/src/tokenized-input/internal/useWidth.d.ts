export function getWidth(node: any): any;
export function useWidth(density: any): (((newNode: any) => void) | null)[];
