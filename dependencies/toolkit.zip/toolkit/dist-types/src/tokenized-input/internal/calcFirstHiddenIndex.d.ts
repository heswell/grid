export function calcFirstHiddenIndex({ containerWidth, pillWidths }?: {
    containerWidth?: number | undefined;
    pillWidths?: any[] | undefined;
}): number | null;
