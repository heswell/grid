export function getCursorPosition(inputRef: any): any;
