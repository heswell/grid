export const InputPill: React.NamedExoticComponent<object>;
export default InputPill;
import React from "react";
