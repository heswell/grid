export function defaultItemToString(item: any): string;
