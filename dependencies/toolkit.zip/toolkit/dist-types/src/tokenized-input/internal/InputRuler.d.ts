/**
 * This hidden component is used to wrap a copy of an input value
 * so that we can use it to determine the input width dynamically
 */
export const InputRuler: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
export default InputRuler;
import React from "react";
