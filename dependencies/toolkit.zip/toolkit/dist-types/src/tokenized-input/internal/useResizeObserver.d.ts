export function useResizeObserver(onSizeChange: any): import("react").MutableRefObject<undefined>;
