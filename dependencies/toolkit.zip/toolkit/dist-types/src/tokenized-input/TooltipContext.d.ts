export default TooltipContext;
export function useTooltipContext(): {
    Tooltip: any;
    enterDelay: any;
    leaveDelay: any;
    placement: any;
};
declare const TooltipContext: import("react").Context<any>;
