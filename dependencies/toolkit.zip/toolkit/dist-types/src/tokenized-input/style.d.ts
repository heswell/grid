export function style(theme: any): {
    root: {
        display: string;
        justifyContent: string;
        minWidth: string;
        width: string;
        '&:hover:not($disabled)': {
            cursor: string;
        };
    };
    pillGroup: {
        display: string;
        flex: number;
        flexWrap: string;
        alignContent: string;
        boxSizing: string;
    };
    pillRoot: {
        '& > *': {
            minWidth: number;
        };
    };
    pillActive: {
        '&& $pillMuiRoot': any;
        '& $pillDeleteIcon': {
            color: any;
        };
        '& $pillDeleteButton': any;
    };
    pillLastVisible: {};
    pillMuiRoot: {};
    pillDeleteIcon: {};
    pillDeleteButton: {};
    inputField: {};
    inputRoot: {
        flexGrow: number;
        padding: number;
        minWidth: number;
        outline: string;
        '&, &$inputField': {
            width: string;
            height: string;
        };
        '&, && $input': {
            minHeight: number;
        };
    };
    inputMultiline: {};
    input: {};
    clearButton: {
        flex: string;
        alignSelf: string;
    };
    expandButton: {};
    expanded: {};
    hidden: {
        display: string;
    };
    focused: any;
    disabled: any;
    touchDensity: {
        '& $pillGroup': {
            minHeight: any;
            padding: any[][];
        };
        '& $pillRoot, $expandButton, && $input, && $inputField$inputMultiline $input': {
            margin: number[][];
            height: number;
        };
        '& $pillRoot': {
            marginRight: number;
        };
        '& $pillLastVisible': {
            marginRight: any;
        };
        '& $expandButton': {
            padding: any[][];
        };
        '&& $input, && $inputField$inputMultiline $input': {
            padding: number;
        };
        '&$expanded': {
            '&, & $pillGroup': {
                height: string;
            };
        };
    };
    lowDensity: {
        '& $pillGroup': {
            minHeight: any;
            padding: any[][];
        };
        '& $pillRoot, $expandButton, && $input, && $inputField$inputMultiline $input': {
            margin: number[][];
            height: number;
        };
        '& $pillRoot': {
            marginRight: number;
        };
        '& $pillLastVisible': {
            marginRight: any;
        };
        '& $expandButton': {
            padding: any[][];
        };
        '&& $input, && $inputField$inputMultiline $input': {
            padding: number;
        };
        '&$expanded': {
            '&, & $pillGroup': {
                height: string;
            };
        };
    };
    mediumDensity: {
        '& $pillGroup': {
            minHeight: any;
            padding: any[][];
        };
        '& $pillRoot, $expandButton, && $input, && $inputField$inputMultiline $input': {
            margin: number[][];
            height: number;
        };
        '& $pillRoot': {
            marginRight: number;
        };
        '& $pillLastVisible': {
            marginRight: any;
        };
        '& $expandButton': {
            padding: any[][];
        };
        '&& $input, && $inputField$inputMultiline $input': {
            padding: number;
        };
        '&$expanded': {
            '&, & $pillGroup': {
                height: string;
            };
        };
    };
    highDensity: {
        '& $pillGroup': {
            minHeight: any;
            padding: any[][];
        };
        '& $pillRoot, $expandButton, && $input, && $inputField$inputMultiline $input': {
            margin: number[][];
            height: number;
        };
        '& $pillRoot': {
            marginRight: number;
        };
        '& $pillLastVisible': {
            marginRight: any;
        };
        '& $expandButton': {
            padding: any[][];
        };
        '&& $input, && $inputField$inputMultiline $input': {
            padding: number;
        };
        '&$expanded': {
            '&, & $pillGroup': {
                height: string;
            };
        };
    };
};
