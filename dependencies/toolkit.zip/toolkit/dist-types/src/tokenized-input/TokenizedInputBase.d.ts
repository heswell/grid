export const TokenizedInputBase: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
export default TokenizedInputBase;
import React from "react";
