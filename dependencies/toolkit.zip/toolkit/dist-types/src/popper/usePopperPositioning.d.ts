export function usePopperPositioning(anchorEl: any, popperRef: any, isOpen: any): (string | undefined)[];
