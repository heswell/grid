export default Popper;
declare function Popper({ anchorEl, children, className, offsetY, open, placement, role, }: {
    anchorEl: any;
    children: any;
    className: any;
    offsetY?: number | undefined;
    open: any;
    placement?: string | undefined;
    role: any;
}): JSX.Element | null;
