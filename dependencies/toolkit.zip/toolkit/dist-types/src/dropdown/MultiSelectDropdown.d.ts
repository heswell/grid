export default MultiSelectDropdown;
/**
 * Renders a multi-select dropdown with selectable items
 */
declare const MultiSelectDropdown: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
import React from "react";
