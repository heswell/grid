export function useResizeObserver(opts?: {}): {
    ref: import("react").MutableRefObject<null>;
    callbackRef: (element: any) => void;
    width: undefined;
    height: undefined;
};
