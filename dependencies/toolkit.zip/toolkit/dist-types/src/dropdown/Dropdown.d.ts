export default Dropdown;
/**
 * Renders a basic dropdown with selectable item
 */
declare const Dropdown: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
import React from "react";
