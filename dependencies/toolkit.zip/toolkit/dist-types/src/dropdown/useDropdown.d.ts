export function useDropdown(props?: {}, isMultiSelect?: boolean): {
    rootProps: {
        "aria-expanded": undefined;
        "aria-haspopup": undefined;
        "aria-labelledby": undefined;
        "data-jpmui-test": string;
        disabled: any;
        density: any;
        id: any;
        isOpen: any;
        fullWidth: any;
        role: undefined;
        ref: import("react").MutableRefObject<null>;
    };
    buttonProps: any;
    listContext: {
        state: {
            id: any;
            focusVisible: boolean;
            selectedItem: any;
            highlightedIndex: any;
            isMultiSelect: boolean;
            isDisabled: any;
        };
        helpers: {
            setFocusVisible: import("react").Dispatch<import("react").SetStateAction<boolean>>;
            setSelectedItem: any;
            setHighlightedIndex: any;
            keyDownHandlers: {
                ArrowUp: (event: any) => void;
                ArrowDown: (event: any) => void;
                PageUp: (event: any) => void;
                PageDown: (event: any) => void;
                Home: (event: any) => void;
                End: (event: any) => void;
                Enter: (event: any) => void;
                " ": (event: any) => void;
                Tab: (event: any) => void;
            };
            isFocusVisible: (event: any) => any;
            onBlurVisible: () => void;
            handleSelect: (event: any, index: any, item: any) => void;
        };
    };
    listProps: {
        onMouseLeave?: (event: any) => void;
        role: string;
        source: any;
        displayedItemCount: any;
        getItemId: any;
        disabled: any;
        "aria-multiselectable": any;
        "aria-labelledby": any;
        id: any;
        borderless: any;
        density: any;
        disableFocus: boolean;
        onBlur: (event: any) => void;
        onClick: (event: any) => void;
        onFocus: (event: any) => void;
        onKeyDown: (event: any) => void;
        onMouseDown: (event: any) => void;
        getItemAtIndex: (index: any) => any;
        getItemIndex: (item: any) => any;
        itemCount: any;
    };
};
