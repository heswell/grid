export function orderedButtonStyle({ toolkit }: {
    toolkit: any;
}): {
    stacked: {};
    orderedButton: {
        '&:last-child': {
            marginRight: number;
        };
    };
    alignRight: {};
    alignLeft: {};
    highDensity: {
        '&$orderedButton': {
            margin: any;
            '&:last-child': {
                margin: number;
            };
            '&$alignLeft': {
                marginRight: string;
            };
            '&$alignRight': {
                marginLeft: string;
            };
            '&$stacked': {
                margin: any;
                '&:last-child': {
                    margin: number;
                };
            };
        };
    };
    mediumDensity: {
        '&$orderedButton': {
            margin: any;
            '&:last-child': {
                margin: number;
            };
            '&$alignLeft': {
                marginRight: string;
            };
            '&$alignRight': {
                marginLeft: string;
            };
            '&$stacked': {
                margin: any;
                '&:last-child': {
                    margin: number;
                };
            };
        };
    };
    lowDensity: {
        '&$orderedButton': {
            margin: any;
            '&:last-child': {
                margin: number;
            };
            '&$alignLeft': {
                marginRight: string;
            };
            '&$alignRight': {
                marginLeft: string;
            };
            '&$stacked': {
                margin: any;
                '&:last-child': {
                    margin: number;
                };
            };
        };
    };
    touchDensity: {
        '&$orderedButton': {
            margin: any;
            '&:last-child': {
                margin: number;
            };
            '&$alignLeft': {
                marginRight: string;
            };
            '&$alignRight': {
                marginLeft: string;
            };
            '&$stacked': {
                margin: any;
                '&:last-child': {
                    margin: number;
                };
            };
        };
    };
};
