export default OrderedButton;
declare const OrderedButton: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
import React from "react";
