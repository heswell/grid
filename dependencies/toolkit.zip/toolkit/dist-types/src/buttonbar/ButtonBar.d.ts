export namespace DefaultButtonsOrderByVariant {
    namespace cta {
        const order: number;
        const alignLeftOrder: number;
        const stackOrder: number;
    }
    namespace regular {
        const order_1: number;
        export { order_1 as order };
        const alignLeftOrder_1: number;
        export { alignLeftOrder_1 as alignLeftOrder };
        const stackOrder_1: number;
        export { stackOrder_1 as stackOrder };
    }
    namespace secondary {
        const order_2: number;
        export { order_2 as order };
        const alignLeftOrder_2: number;
        export { alignLeftOrder_2 as alignLeftOrder };
        const stackOrder_2: number;
        export { stackOrder_2 as stackOrder };
    }
}
export default ButtonBar;
declare const ButtonBar: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
import React from "react";
