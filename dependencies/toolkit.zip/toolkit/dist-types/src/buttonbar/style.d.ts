export function buttonBarStyle(): {
    root: {
        width: string;
        display: string;
        justifyContent: string;
        '&$stacked': {
            justifyContent: string;
            flexDirection: string;
        };
        '&$alignedLeft': {
            justifyContent: string;
        };
    };
    alignedLeft: {};
    autoAligning: {
        "@media all and (-ms-high-contrast: none), (-ms-high-contrast: active)": {
            justifyContent: string;
        };
    };
    stacked: {};
};
