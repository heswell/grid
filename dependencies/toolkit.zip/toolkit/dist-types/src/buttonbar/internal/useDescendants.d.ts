export default function useDescendants(): [never[], import("react").Dispatch<import("react").SetStateAction<never[]>>];
