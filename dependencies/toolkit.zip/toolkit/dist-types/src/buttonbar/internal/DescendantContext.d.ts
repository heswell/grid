export function DescendantProvider({ items, setItems, ...props }: {
    [x: string]: any;
    items: any;
    setItems: any;
}): JSX.Element;
export const DescendantContext: React.Context<any>;
import React from "react";
