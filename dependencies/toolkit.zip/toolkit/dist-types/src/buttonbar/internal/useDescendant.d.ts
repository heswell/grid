export default function useDescendant(descendant: any): number;
