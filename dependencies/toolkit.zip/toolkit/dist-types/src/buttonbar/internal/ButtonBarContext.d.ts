export default ButtonBarContext;
declare const ButtonBarContext: import("react").Context<any>;
