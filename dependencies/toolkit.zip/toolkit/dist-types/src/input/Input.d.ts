export default Input;
declare const Input: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
import React from "react";
