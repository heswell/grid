export default Spinner;
/**
 * Spinner component, provides an indeterminate loading indicator
 *
 * @example
 * <Spinner size="small | medium | large" />
 */
declare const Spinner: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
import React from "react";
