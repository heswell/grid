export default SpinnerMedium;
declare function SpinnerMedium(): JSX.Element;
