export function getSvgSpinner(size: any): () => JSX.Element;
