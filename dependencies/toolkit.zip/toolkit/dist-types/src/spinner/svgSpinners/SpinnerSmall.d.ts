export default SpinnerSmall;
declare function SpinnerSmall(): JSX.Element;
