export default SpinnerLarge;
declare function SpinnerLarge(): JSX.Element;
