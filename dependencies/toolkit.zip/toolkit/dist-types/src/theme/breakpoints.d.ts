export function breakpointRamp(breakpoints: any): any[][];
export function getBreakPoints(themeName: any): any;
