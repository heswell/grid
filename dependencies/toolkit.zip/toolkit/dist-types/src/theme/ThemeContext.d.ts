export function ThemeProvider({ children, density, theme: themeId, themeLoader, }: {
    children: any;
    density?: string | undefined;
    theme?: string | undefined;
    themeLoader?: any;
}): JSX.Element;
export function useDensity(density: any): any;
export const ThemeContext: React.Context<any>;
export const ThemeConsumer: React.Consumer<any>;
export function useTheme(): any;
export function useThemeProps(): {
    density: any;
    theme: any;
};
import React from "react";
