export declare const DensityValues: readonly ["high", "medium", "low", "touch"];
export declare type Density = typeof DensityValues[number];
