export function installTheme(themeId: any): void;
