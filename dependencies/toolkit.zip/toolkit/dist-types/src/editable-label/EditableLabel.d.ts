export default EditableLabel;
declare function EditableLabel({ className: classNameProp, density: densityProp, onEnterEditMode, onExitEditMode, value: valueProp, }: {
    className: any;
    density: any;
    onEnterEditMode: any;
    onExitEditMode: any;
    value: any;
}): JSX.Element;
