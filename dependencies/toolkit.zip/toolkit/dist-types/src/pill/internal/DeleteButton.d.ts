/// <reference types="react" />
import { ButtonProps } from '../../button';
export interface DeleteButtonProps extends ButtonProps {
    /**
     * Active state.
     */
    active?: boolean;
}
export declare const DeleteButton: (props: DeleteButtonProps) => JSX.Element;
export default DeleteButton;
