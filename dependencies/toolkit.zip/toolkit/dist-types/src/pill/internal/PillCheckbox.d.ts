/// <reference types="react" />
import './PillCheckbox.css';
export declare const PillCheckbox: (props: {
    checked?: boolean | undefined;
}) => JSX.Element;
export default PillCheckbox;
