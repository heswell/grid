import React, { HTMLAttributes, ReactElement } from 'react';
import './PillBase.css';
export interface PillBaseProps extends HTMLAttributes<HTMLDivElement> {
    /**
     * Clickable variation. Use 'onClick' for callback.
     */
    clickable?: boolean;
    /**
     * Shows delete icon. Use `onDelete` for callback.
     */
    deletable?: boolean;
    /**
     * Override the default delete icon element. Shown only if `deletable` is set.
     */
    deleteIcon?: React.ReactElement;
    /**
     * If `true`, the pill will be disabled.
     */
    disabled?: boolean;
    /**
     * Icon element.
     */
    icon?: string | ReactElement;
    /**
     * The content of the label.
     */
    label?: string;
    /**
     * Callback function fired when the delete icon is clicked. Used when `deletable` is true.
     */
    onDelete?: React.EventHandler<any>;
}
export declare const PillBase: React.ForwardRefExoticComponent<PillBaseProps & React.RefAttributes<HTMLDivElement>>;
export default PillBase;
