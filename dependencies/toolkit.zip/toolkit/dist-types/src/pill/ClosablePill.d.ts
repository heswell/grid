import React from 'react';
import { PillBaseProps } from './internal/PillBase';
export declare const ClosablePill: React.ForwardRefExoticComponent<PillBaseProps & React.RefAttributes<HTMLDivElement>>;
export default ClosablePill;
