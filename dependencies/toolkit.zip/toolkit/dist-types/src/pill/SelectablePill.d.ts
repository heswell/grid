import React, { ChangeEvent } from 'react';
import { PillBaseProps } from './internal/PillBase';
export interface SelectablePillProps extends Omit<PillBaseProps, 'onChange'> {
    /**
     * Determines whether pill is checked.
     */
    checked?: boolean;
    onChange?: (event: ChangeEvent, checked: boolean) => void;
}
declare const SelectablePill: React.ForwardRefExoticComponent<SelectablePillProps & React.RefAttributes<HTMLDivElement>>;
export default SelectablePill;
