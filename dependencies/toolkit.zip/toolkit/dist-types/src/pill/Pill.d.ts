import React, { ForwardedRef, HTMLAttributes, ReactElement } from 'react';
import { PillBaseProps } from './internal/PillBase';
import { SelectablePillProps } from './SelectablePill';
import './Pill.css';
export declare type PillVariant = 'basic' | 'closable' | 'selectable';
interface PillVariantProps<T extends PillVariant = 'basic'> {
    /**
     * Determines the variant of pill
     */
    variant?: T;
}
export declare type PillProps<T extends PillVariant = 'basic'> = T extends 'basic' | 'closable' ? PillBaseProps & PillVariantProps<T> : SelectablePillProps & PillVariantProps<T>;
export declare const Pill: <T extends PillVariant = "basic">(p: PillProps<T> & {
    ref?: ((instance: React.HTMLAttributes<HTMLDivElement> | null) => void) | React.MutableRefObject<React.HTMLAttributes<HTMLDivElement> | null> | null | undefined;
}) => React.ReactElement<PillProps<T>, string | ((props: any) => React.ReactElement<any, string | any | (new (props: any) => React.Component<any, any, any>)> | null) | (new (props: any) => React.Component<any, any, any>)>;
export default Pill;
