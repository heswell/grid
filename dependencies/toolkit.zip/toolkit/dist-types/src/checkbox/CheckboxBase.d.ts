export const CheckboxBase: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
export default CheckboxBase;
import React from "react";
