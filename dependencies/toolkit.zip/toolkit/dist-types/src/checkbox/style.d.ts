export function CheckboxBaseStyle({ toolkit: toolkitTheme }: {
    toolkit: any;
}): {
    root: {
        background: string;
        color: any;
        justifyContent: string;
        marginTop: number;
    };
    disabled: any;
    checked: {
        fill: any;
        "& $icon": {
            fill: any;
        };
    };
    indeterminate: {
        flexGrow: number;
        stroke: any;
    };
    checkedTick: {
        fill: any;
    };
    icon: {
        height: number;
        width: number;
        flexGrow: number;
        fill: string;
        stroke: any;
        overflow: string;
    };
    iconRoot: {
        alignSelf: string;
        width: string;
        background: string;
        minHeight: string;
        height: string;
        padding: number;
        "&:before": {
            content: string;
            width: string;
            height: string;
            display: string;
            position: string;
            top: number;
            left: number;
        };
        "&:hover": {
            background: string;
            color: any;
            "& $icon": {
                stroke: any;
            };
        };
        "&$checked": {
            strokeWidth: number;
            "&:hover": {
                background: string;
                "& $icon": {
                    stroke: any;
                };
            };
        };
        "&$disabled": {
            cursor: string;
            pointerEvents: string;
        };
    };
    focusVisible: {};
    highDensity: {
        "& $icon": {
            height: any;
            width: any;
        };
        "&$indeterminate": {
            "& $checked": {
                height: number;
                y: number;
            } | {
                height?: undefined;
                y?: undefined;
            };
        };
        "&$focusVisible": {
            "&:before": any;
        };
    };
    mediumDensity: {
        "& $icon": {
            height: any;
            width: any;
        };
        "&$indeterminate": {
            "& $checked": {
                height: number;
                y: number;
            } | {
                height?: undefined;
                y?: undefined;
            };
        };
        "&$focusVisible": {
            "&:before": any;
        };
    };
    lowDensity: {
        "& $icon": {
            height: any;
            width: any;
        };
        "&$indeterminate": {
            "& $checked": {
                height: number;
                y: number;
            } | {
                height?: undefined;
                y?: undefined;
            };
        };
        "&$focusVisible": {
            "&:before": any;
        };
    };
    touchDensity: {
        "& $icon": {
            height: any;
            width: any;
        };
        "&$indeterminate": {
            "& $checked": {
                height: number;
                y: number;
            } | {
                height?: undefined;
                y?: undefined;
            };
        };
        "&$focusVisible": {
            "&:before": any;
        };
    };
};
export const useCheckboxStyle: any;
export function CheckboxGroupStyle({ toolkit: toolkitTheme }: {
    toolkit: any;
}): {
    root: {
        background: string;
        color: any;
        justifyContent: string;
        marginTop: number;
    };
    horizontalRoot: {
        display: string;
    };
    formControlRoot: {
        width: string;
    };
    formGroupHorizontal: {
        display: string;
        flexDirection: string;
    };
    formGroupVertical: {
        flexDirection: string;
        lineHeight: number;
    };
    horizontal: {
        display: string;
    };
    vertical: {
        padding: number;
    };
    legend: {
        marginBottom: number;
        "&$horizontal": {
            display: string;
            float: string;
            marginLeft: number;
        };
    };
    formField: {};
    formFieldFilled: {};
    formFieldLabelLeft: {};
    highDensity: {
        "& $legend$horizontal, $legend$vertical": {
            transition: string;
            transform: string;
        };
        "& $horizontal": {
            marginRight: any;
        };
        "&$formField": {
            paddingLeft: any;
            marginTop: any;
            "&$formFieldLabelLeft": {
                marginTop: number;
                marginBottom: any;
            };
            "& $formGroupHorizontal": {
                marginTop: any;
            };
            "& $formGroupVertical:last-child": {
                marginBottom: number;
            };
        };
    };
    mediumDensity: {
        "& $legend$horizontal, $legend$vertical": {
            transition: string;
            transform: string;
        };
        "& $horizontal": {
            marginRight: any;
        };
        "&$formField": {
            paddingLeft: any;
            marginTop: any;
            "&$formFieldLabelLeft": {
                marginTop: number;
                marginBottom: any;
            };
            "& $formGroupHorizontal": {
                marginTop: any;
            };
            "& $formGroupVertical:last-child": {
                marginBottom: number;
            };
        };
    };
    lowDensity: {
        "& $legend$horizontal, $legend$vertical": {
            transition: string;
            transform: string;
        };
        "& $horizontal": {
            marginRight: any;
        };
        "&$formField": {
            paddingLeft: any;
            marginTop: any;
            "&$formFieldLabelLeft": {
                marginTop: number;
                marginBottom: any;
            };
            "& $formGroupHorizontal": {
                marginTop: any;
            };
            "& $formGroupVertical:last-child": {
                marginBottom: number;
            };
        };
    };
    touchDensity: {
        "& $legend$horizontal, $legend$vertical": {
            transition: string;
            transform: string;
        };
        "& $horizontal": {
            marginRight: any;
        };
        "&$formField": {
            paddingLeft: any;
            marginTop: any;
            "&$formFieldLabelLeft": {
                marginTop: number;
                marginBottom: any;
            };
            "& $formGroupHorizontal": {
                marginTop: any;
            };
            "& $formGroupVertical:last-child": {
                marginBottom: number;
            };
        };
    };
};
