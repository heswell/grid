export const Checkbox: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
export default Checkbox;
import React from "react";
