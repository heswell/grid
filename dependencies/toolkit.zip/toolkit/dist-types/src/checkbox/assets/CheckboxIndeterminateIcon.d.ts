export default CheckboxIndeterminateIcon;
declare function CheckboxIndeterminateIcon({ className }: {
    className: any;
}): JSX.Element;
