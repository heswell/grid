export default CheckboxCheckedIcon;
declare function CheckboxCheckedIcon({ className }: {
    className: any;
}): JSX.Element;
