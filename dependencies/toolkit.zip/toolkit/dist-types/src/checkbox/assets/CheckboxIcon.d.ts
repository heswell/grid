export default CheckboxIcon;
declare function CheckboxIcon({ className }: {
    className: any;
}): JSX.Element;
