export default Dialog;
/**
 * The Dialog is a window that contains text and interactive components.
 * By default, Dialog is non-modal, but supports modal behaviour as well.
 */
declare const Dialog: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
import React from "react";
