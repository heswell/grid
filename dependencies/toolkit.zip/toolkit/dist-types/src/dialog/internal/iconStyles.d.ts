export function iconStyles({ toolkit: toolkitTheme }: {
    toolkit: any;
}): {
    root: {
        marginRight: number;
    };
    warning: {
        color: any;
    };
    error: {
        color: any;
    };
    success: {
        color: any;
    };
    info: {
        color: any;
    };
};
