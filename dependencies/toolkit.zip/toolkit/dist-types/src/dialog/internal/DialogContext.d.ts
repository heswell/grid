declare var _default: import("react").Context<any>;
export default _default;
