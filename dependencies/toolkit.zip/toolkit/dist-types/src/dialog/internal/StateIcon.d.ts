export default StateIcon;
declare function StateIcon(props: any): JSX.Element;
declare namespace StateIcon {
    namespace propTypes {
        const className: PropTypes.Requireable<string>;
        const state: PropTypes.Validator<string>;
    }
}
import PropTypes from "prop-types";
