export default DialogContent;
declare const DialogContent: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
import React from "react";
