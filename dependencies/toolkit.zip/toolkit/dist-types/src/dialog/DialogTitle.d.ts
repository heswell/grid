export default DialogTitle;
declare const DialogTitle: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
import React from "react";
