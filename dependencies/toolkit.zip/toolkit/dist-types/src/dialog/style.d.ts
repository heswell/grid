export function style({ breakpoints, toolkit: toolkitTheme }: {
    breakpoints: any;
    toolkit: any;
}): {
    paper: any;
    paperScrollPaper: {
        maxWidth: number;
    };
    paperScrollBody: {
        maxWidth: number;
    };
    paperWidthXs: {
        maxWidth: number;
    };
    paperWidthSm: {
        maxWidth: any;
    };
    paperWidthMd: {
        maxWidth: any;
    };
    paperWidthLg: {
        maxWidth: any;
    };
    paperFullWidth: {};
    dialog: any;
    backdropRoot: {
        backgroundColor: string;
    };
    focusTrapRoot: {
        width: string;
        height: string;
        display: string;
        flexDirection: string;
    };
    infoShadow: any;
    warning: {
        borderColor: any;
    };
    error: {
        borderColor: any;
    };
    success: {
        borderColor: any;
    };
    info: {
        borderColor: any;
    };
    highDensity: {
        boxSizing: string;
        '& $paper': {
            margin: any;
        };
        '& $paperWidthXs': {
            '& $paperScrollBody': {
                [x: number]: {
                    margin: any;
                };
            };
        };
        '& $paperWidthSm': {
            '& $paperScrollBody': {
                [x: number]: {
                    margin: any;
                };
            };
        };
        '& $paperWidthMd': {
            '& $paperScrollBody': {
                [x: number]: {
                    margin: any;
                };
            };
        };
        '& $paperWidthLg': {
            '& $paperScrollBody': {
                [x: number]: {
                    margin: any;
                };
            };
        };
        '& $dialog': {
            padding: any;
        };
    };
    mediumDensity: {
        boxSizing: string;
        '& $paper': {
            margin: any;
        };
        '& $paperWidthXs': {
            '& $paperScrollBody': {
                [x: number]: {
                    margin: any;
                };
            };
        };
        '& $paperWidthSm': {
            '& $paperScrollBody': {
                [x: number]: {
                    margin: any;
                };
            };
        };
        '& $paperWidthMd': {
            '& $paperScrollBody': {
                [x: number]: {
                    margin: any;
                };
            };
        };
        '& $paperWidthLg': {
            '& $paperScrollBody': {
                [x: number]: {
                    margin: any;
                };
            };
        };
        '& $dialog': {
            padding: any;
        };
    };
    lowDensity: {
        boxSizing: string;
        '& $paper': {
            margin: any;
        };
        '& $paperWidthXs': {
            '& $paperScrollBody': {
                [x: number]: {
                    margin: any;
                };
            };
        };
        '& $paperWidthSm': {
            '& $paperScrollBody': {
                [x: number]: {
                    margin: any;
                };
            };
        };
        '& $paperWidthMd': {
            '& $paperScrollBody': {
                [x: number]: {
                    margin: any;
                };
            };
        };
        '& $paperWidthLg': {
            '& $paperScrollBody': {
                [x: number]: {
                    margin: any;
                };
            };
        };
        '& $dialog': {
            padding: any;
        };
    };
    touchDensity: {
        boxSizing: string;
        '& $paper': {
            margin: any;
        };
        '& $paperWidthXs': {
            '& $paperScrollBody': {
                [x: number]: {
                    margin: any;
                };
            };
        };
        '& $paperWidthSm': {
            '& $paperScrollBody': {
                [x: number]: {
                    margin: any;
                };
            };
        };
        '& $paperWidthMd': {
            '& $paperScrollBody': {
                [x: number]: {
                    margin: any;
                };
            };
        };
        '& $paperWidthLg': {
            '& $paperScrollBody': {
                [x: number]: {
                    margin: any;
                };
            };
        };
        '& $dialog': {
            padding: any;
        };
    };
};
export function titleStyles({ toolkit: toolkitTheme }: {
    toolkit: any;
}): {
    root: any;
    close: {};
    closeIcon: {};
    stateIcon: {
        lineHeight: string;
    };
    highDensity: {
        fontSize: any;
        '& > $close': {
            paddingTop: any;
            paddingBottom: any;
            top: number;
            right: number;
            position: string;
        };
    };
    mediumDensity: {
        fontSize: any;
        '& > $close': {
            paddingTop: any;
            paddingBottom: any;
            top: number;
            right: number;
            position: string;
        };
    };
    lowDensity: {
        fontSize: any;
        '& > $close': {
            paddingTop: any;
            paddingBottom: any;
            top: number;
            right: number;
            position: string;
        };
    };
    touchDensity: {
        fontSize: any;
        '& > $close': {
            paddingTop: any;
            paddingBottom: any;
            top: number;
            right: number;
            position: string;
        };
    };
};
export function actionStyles(): {
    root: {
        padding: number;
    };
};
export function contentStyles({ toolkit: toolkitTheme }: {
    toolkit: any;
}): {
    root: any;
    leftGutter: {
        paddingLeft: number;
    };
    highDensity: {
        fontSize: any;
        minHeight: any;
        paddingTop: any;
        paddingBottom: any;
    };
    mediumDensity: {
        fontSize: any;
        minHeight: any;
        paddingTop: any;
        paddingBottom: any;
    };
    lowDensity: {
        fontSize: any;
        minHeight: any;
        paddingTop: any;
        paddingBottom: any;
    };
    touchDensity: {
        fontSize: any;
        minHeight: any;
        paddingTop: any;
        paddingBottom: any;
    };
};
