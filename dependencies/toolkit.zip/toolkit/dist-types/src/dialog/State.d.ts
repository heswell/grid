export default State;
declare const State: Readonly<{
    ERROR: string;
    SUCCESS: string;
    WARNING: string;
    INFO: string;
}>;
