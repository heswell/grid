export default function useOverflowObserver(orientation?: string, label?: string): (import("react").MutableRefObject<null> | never[] | (() => void))[];
