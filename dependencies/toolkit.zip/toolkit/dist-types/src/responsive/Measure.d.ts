export function useMeasure(props: any): [{
    height: any;
    width: any;
}, React.Dispatch<React.SetStateAction<{
    height: any;
    width: any;
}>>];
export default Measure;
import React from "react";
declare function Measure({ height, width, onMeasure }: {
    height: any;
    width: any;
    onMeasure: any;
}): JSX.Element;
