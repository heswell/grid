export function getOverflowedItems(containerRef: any, height?: number): any[][];
export function findFirstOverflow(elements: any, height: any): number;
