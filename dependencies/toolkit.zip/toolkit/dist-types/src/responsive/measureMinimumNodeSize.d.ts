export default function measureMinimumNodeSize(node: any, dimension?: string): any;
