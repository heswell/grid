export default function useResizeObserver(ref: any, dimensions: any, onResize: any): void;
