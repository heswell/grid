export function isResponsiveAttribute(propName: any): any;
export function extractResponsiveProps(props: any): {}[];
