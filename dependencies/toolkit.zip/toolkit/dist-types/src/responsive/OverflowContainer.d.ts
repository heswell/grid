export default Toolbar;
declare function Toolbar({ children, className, density: densityProp, id, maxRows: _1, orientation, style, title, tools: toolsProp, stops, getTools, ...rootProps }: {
    [x: string]: any;
    children: any;
    className: any;
    density: any;
    id: any;
    maxRows: any;
    orientation?: string | undefined;
    style: any;
    title: any;
    tools: any;
    stops: any;
    getTools?: (() => any) | undefined;
}): JSX.Element;
