export default OverflowMenu;
declare const OverflowMenu: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
import React from "react";
