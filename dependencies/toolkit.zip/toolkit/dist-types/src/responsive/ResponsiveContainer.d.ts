export default ResponsiveContainer;
declare const ResponsiveContainer: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
import React from "react";
