export default function useBreakpoints({ breakPoints: breakPointsProp, smallerThan, onResize }: {
    breakPoints: any;
    smallerThan: any;
    onResize: any;
}, ref: any): string | boolean;
