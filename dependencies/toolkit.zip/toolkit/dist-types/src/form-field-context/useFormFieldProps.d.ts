export default useFormFieldProps;
declare function useFormFieldProps({ focusVisible }?: {
    focusVisible: any;
}): {};
