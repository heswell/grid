export default IconClassNameContext;
declare const IconClassNameContext: React.Context<string>;
export const IconClassNameConsumer: React.Consumer<string>;
export function IconClassNameProvider({ children, value: className }: {
    children: any;
    value: any;
}): JSX.Element;
export namespace IconClassNameProvider {
    namespace propTypes {
        const children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        const value: PropTypes.Requireable<string>;
    }
}
import React from "react";
import PropTypes from "prop-types";
