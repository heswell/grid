import React, { HTMLAttributes } from 'react';
import './Icon.css';
declare const ICON_SIZES: readonly ["small", "medium", "large"];
export declare type IconSize = typeof ICON_SIZES[number];
export interface IconProps extends HTMLAttributes<HTMLSpanElement> {
    /**
     * Used to include HAT (hidden accessible text)
     * Defaults to icon name if used without value
     * will be set to custom HAT text if passed a string
     */
    accessibleText?: boolean | string;
    /**
     * Prefix for icon classes
     */
    brand?: string;
    /**
     * Name of the icon.
     */
    name?: string;
    /**
     * Pass a custom svg
     */
    svg?: string;
    /**
     * Size of the icon, explicit size or small/medium/large
     */
    size?: IconSize | number;
}
export declare const Icon: React.ForwardRefExoticComponent<IconProps & React.RefAttributes<HTMLSpanElement>>;
export default Icon;
