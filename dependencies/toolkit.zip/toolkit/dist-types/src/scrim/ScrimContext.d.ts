export default ScrimContext;
declare const ScrimContext: import("react").Context<null>;
