export default Scrim;
declare const Scrim: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
import React from "react";
