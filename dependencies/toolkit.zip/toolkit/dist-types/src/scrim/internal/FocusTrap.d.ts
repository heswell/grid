export default FocusTrap;
declare function FocusTrap(props: any): JSX.Element;
declare namespace FocusTrap {
    namespace defaultProps {
        export { defaultSelector as tabEnabledSelectors };
    }
    namespace propTypes {
        const active: PropTypes.Requireable<boolean>;
        const children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        const className: PropTypes.Requireable<string>;
        const tabEnabledSelectors: PropTypes.Requireable<string>;
    }
}
declare const defaultSelector: "\n[tabindex=\"0\"], \na:not([tabindex=\"-1\"]), \narea:not([tabindex=\"-1\"]), \ndetails:not([tabindex=\"-1\"]), \niframe:not([tabindex=\"-1\"]), \nselect:not([tabindex=\"-1\"]), \ntextarea:not([tabindex=\"-1\"]), \nbutton:not([tabindex=\"-1\"]), \ninput:not([tabindex=\"-1\"])\n";
import PropTypes from "prop-types";
