import React, { HTMLAttributes, ReactNode } from 'react';
import { Density } from '../theme';
import './Tooltip.css';
export declare type Placement = 'right' | 'right-start' | 'right-end' | 'top' | 'top-start' | 'top-end' | 'left' | 'left-start' | 'left-end' | 'bottom' | 'bottom-start' | 'bottom-end';
export declare type TooltipState = 'error' | 'info' | 'success' | 'warning';
export declare type TooltipSize = 'small' | 'medium';
export interface TooltipRenderProp {
    Icon: any;
    getIconProps: any;
    getTitleProps: any;
}
interface MUITooltipProps {
    /**
     * Do not respond to focus events.
     */
    disableFocusListener?: boolean;
    /**
     * Do not respond to hover events.
     */
    disableHoverListener?: boolean;
    /**
     * Do not respond to long press touch events.
     */
    disableTouchListener?: boolean;
    /**
     * The number of milliseconds to wait before showing the tooltip.
     * This prop won't impact the enter touch delay (`enterTouchDelay`).
     */
    enterDelay?: number;
    /**
     * The number of milliseconds to wait before showing the tooltip when one was already recently opened.
     */
    enterNextDelay?: number;
    /**
     * The number of milliseconds a user must touch the element before showing the tooltip.
     */
    enterTouchDelay?: number;
    /**
     * This prop is used to help implement the accessibility logic.
     * If you don't provide this prop. It falls back to a randomly generated id.
     */
    id?: string;
    /**
     * Makes a tooltip interactive, i.e. will not close when the user
     * hovers over the tooltip before the `leaveDelay` is expired.
     */
    interactive?: boolean;
    /**
     * The number of milliseconds to wait before hiding the tooltip.
     * This prop won't impact the leave touch delay (`leaveTouchDelay`).
     */
    leaveDelay?: number;
    /**
     * The number of milliseconds after the user stops touching an element before hiding the tooltip.
     */
    leaveTouchDelay?: number;
    /**
     * Callback fired when the component requests to be closed.
     *
     * @param {object} event The event source of the callback.
     */
    onClose?: (event: React.ChangeEvent<{}>) => void;
    /**
     * Callback fired when the component requests to be open.
     *
     * @param {object} event The event source of the callback.
     */
    onOpen?: (event: React.ChangeEvent<{}>) => void;
    /**
     * If `true`, the tooltip is shown.
     */
    open?: boolean;
}
export interface TooltipProps extends MUITooltipProps, HTMLAttributes<HTMLDivElement> {
    /**
     * optional label used for accessible information when using a render prop instead of string title
     */
    accessibleText?: string;
    /**
     * Only single child element is supported.
     */
    children: JSX.Element;
    /**
     * The density of a component affects the style of the layout.
     * There are 4 sizes - high, medium, low, and touch. The badge
     * component only updates the size of the text being adorned,
     * not the badge text size itself.
     */
    density?: Density;
    /**
     * Removes the tooltip arrow.
     */
    hideArrow?: boolean;
    /**
     * Whether to hide a state icon within the tooltip
     */
    hideIcon?: boolean;
    /**
     * Tooltip placement ['right', 'right-start', 'right-end', 'top', 'top-start', 'top-end', 'left', 'left-start', 'left-end', 'bottom', 'bottom-start', 'bottom-end']
     */
    placement?: Placement;
    /**
     * A callback function to render the tooltip content
     * @param {function} getIcon getter for the icon based on the state
     * @param {function} getIconProps getter for the icon properties
     * @param {function} getTitleProps getter for the title properties
     */
    render?: (props: TooltipRenderProp) => ReactNode;
    /**
     * A string to determine the size of the tooltip
     */
    size?: TooltipSize;
    /**
     * A string to determine the current state of the tooltip
     */
    state?: TooltipState;
}
export declare const Tooltip: React.ForwardRefExoticComponent<TooltipProps & React.RefAttributes<HTMLDivElement>>;
export default Tooltip;
