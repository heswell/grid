export function getIconForState(state: any): ((props: any) => JSX.Element | null) | null;
export namespace State {
    const error: string;
    const success: string;
    const warning: string;
}
