export default ControlLabel;
declare function ControlLabel({ children, className, density: densityProp, label, labelPlacement, }: {
    children: any;
    className: any;
    density: any;
    label: any;
    labelPlacement?: string | undefined;
}): JSX.Element;
