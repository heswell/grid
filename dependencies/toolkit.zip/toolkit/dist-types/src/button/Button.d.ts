import React, { ButtonHTMLAttributes, ElementType } from 'react';
import './Button.css';
export declare const ButtonVariantValues: readonly ["regular", "secondary", "cta"];
export declare type ButtonVariant = typeof ButtonVariantValues[number];
export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
    /**
     * If `true`, the button will be disabled.
     */
    disabled?: boolean;
    /**
     * If `true`, the button will be focusable when disabled.
     */
    focusableWhenDisabled?: boolean;
    /**
     * The variant to use.
     */
    variant?: ButtonVariant;
    /**
     * HTML tag to use.
     */
    component?: ElementType;
}
export declare const Button: React.ForwardRefExoticComponent<ButtonProps & React.RefAttributes<HTMLButtonElement>>;
export default Button;
