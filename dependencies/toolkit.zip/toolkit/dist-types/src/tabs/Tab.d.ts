export default Tab;
declare const Tab: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
import React from "react";
