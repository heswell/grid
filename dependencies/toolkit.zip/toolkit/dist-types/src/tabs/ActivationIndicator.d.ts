export default ActivationIndicator;
declare function ActivationIndicator({ hideBackground, hideThumb, orientation, tabRef, }: {
    hideBackground?: boolean | undefined;
    hideThumb?: boolean | undefined;
    orientation?: string | undefined;
    tabRef: any;
}): JSX.Element;
