export default function useTabstrip({ children, defaultValue, keyBoardActivation, onChange, onDeleteTab, orientation, value: valueProp, }: {
    children: any;
    defaultValue: any;
    keyBoardActivation?: string | undefined;
    onChange: any;
    onDeleteTab: any;
    orientation: any;
    value: any;
}, ref: any): {
    activateTab: (e: any, tabIndex: any) => void;
    tabProps: {
        onClick: (e: any, tabIndex: any) => void;
        onDelete: (e: any, tabIndex: any) => void;
        onKeyDown: (e: any, tabIndex: any) => void;
        onKeyUp: (e: any, tabIndex: any) => void;
    };
    tabRefs: any[];
    value: any;
};
