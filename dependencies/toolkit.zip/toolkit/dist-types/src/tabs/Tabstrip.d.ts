export default Tabstrip;
declare function Tabstrip(props: any): JSX.Element;
declare namespace Tabstrip {
    const displayName: string;
}
