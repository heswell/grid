export default function useActivationIndicator(rootRef: any, tabRef: any, orientation: any): {
    left: number;
    width: any;
    top?: undefined;
    height?: undefined;
} | {
    top: number;
    height: any;
    left?: undefined;
    width?: undefined;
} | undefined;
