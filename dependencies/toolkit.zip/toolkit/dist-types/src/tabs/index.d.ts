export { default as Tabstrip } from "./Tabstrip";
export { default as Tab } from "./Tab";
