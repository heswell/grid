export default CheckedIcon;
declare function CheckedIcon({ className }: {
    className: any;
}): JSX.Element;
