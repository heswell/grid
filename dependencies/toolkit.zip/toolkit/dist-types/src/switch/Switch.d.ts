export const Switch: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
export default Switch;
import React from "react";
