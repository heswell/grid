export default AppHeader;
declare function AppHeader({ children, className, density: densityProp, id, style, }: {
    children: any;
    className: any;
    density: any;
    id: any;
    style: any;
}): JSX.Element;
