export function useListAutoSizer(props: any): (import("react").MutableRefObject<undefined> | {
    width: any;
    height: any;
})[];
