export function isPlainObject(obj: any): boolean;
export function calcPreferredListHeight(props?: {}): number | undefined;
