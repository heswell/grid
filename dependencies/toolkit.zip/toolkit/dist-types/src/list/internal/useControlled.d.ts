export function useControlled({ controlled, default: defaultProp, name, state }: {
    controlled: any;
    default: any;
    name: any;
    state?: string | undefined;
}): any[];
