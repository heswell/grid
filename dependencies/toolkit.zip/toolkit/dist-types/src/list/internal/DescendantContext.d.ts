export function DescendantProvider({ items, ...props }: {
    [x: string]: any;
    items: any;
}): JSX.Element;
export function useDescendant(descendant: any): number;
export default DescendantContext;
declare const DescendantContext: React.Context<any>;
import React from "react";
