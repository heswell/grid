export function calcPreferredListHeight(props?: {}): number | undefined;
