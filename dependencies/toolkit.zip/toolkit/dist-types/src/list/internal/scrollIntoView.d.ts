export function scrollIntoView(item: any, list: any): void;
