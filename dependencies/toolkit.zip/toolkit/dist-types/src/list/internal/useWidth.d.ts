export function useWidth(responsive: any): (import("react").MutableRefObject<undefined> | undefined)[];
