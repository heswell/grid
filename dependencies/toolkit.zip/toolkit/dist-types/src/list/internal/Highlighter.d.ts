export default Highlighter;
declare function Highlighter(props: any): JSX.Element;
