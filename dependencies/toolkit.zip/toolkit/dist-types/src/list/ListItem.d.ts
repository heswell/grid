export default ListItem;
declare function ListItem(props: any): JSX.Element;
declare namespace ListItem {
    namespace propTypes {
        const children: PropTypes.Requireable<PropTypes.ReactNodeLike>;
        const className: PropTypes.Requireable<string>;
        const classes: PropTypes.Requireable<{
            [x: string]: string | null | undefined;
        }>;
        const density: PropTypes.Requireable<string>;
        const disabled: PropTypes.Requireable<boolean>;
        const item: PropTypes.Requireable<any>;
        const itemToString: PropTypes.Requireable<(...args: any[]) => any>;
    }
}
import PropTypes from "prop-types";
