export default ListStateContext;
export function useListStateContext(): any;
declare const ListStateContext: import("react").Context<any>;
