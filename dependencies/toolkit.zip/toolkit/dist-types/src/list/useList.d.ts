export function useList(props?: {}): {
    focusableRef: ((refValue: any) => void) | null;
    state: {
        id: any;
        focusVisible: boolean;
        selectedItem: any;
        highlightedIndex: any;
        isMultiSelect: boolean;
        isDisabled: any;
    };
    helpers: {
        setFocusVisible: import("react").Dispatch<import("react").SetStateAction<boolean>>;
        setSelectedItem: any;
        setHighlightedIndex: any;
        keyDownHandlers: {
            ArrowUp: (event: any) => void;
            ArrowDown: (event: any) => void;
            PageUp: (event: any) => void;
            PageDown: (event: any) => void;
            Home: (event: any) => void;
            End: (event: any) => void;
            Enter: (event: any) => void;
            " ": (event: any) => void;
            Tab: (event: any) => void;
        };
        isFocusVisible: (event: any) => any;
        onBlurVisible: () => void;
        handleSelect: (event: any, index: any, item: any) => void;
    };
    listProps: {
        onFocus?: (event: any) => void;
        onBlur?: (event: any) => void;
        onKeyDown?: (event: any) => void;
        onMouseLeave?: (event: any) => void;
        role: string;
        "aria-activedescendant": any;
        id: any;
        source: any;
        itemCount: any;
        displayedItemCount: any;
        getItemAtIndex: (index: any) => any;
        getItemIndex: (item: any) => any;
        getItemId: any;
        disabled: any;
    };
};
