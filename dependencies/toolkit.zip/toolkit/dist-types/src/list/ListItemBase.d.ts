declare var _default: React.MemoExoticComponent<React.ForwardRefExoticComponent<React.RefAttributes<any>>>;
export default _default;
import React from "react";
