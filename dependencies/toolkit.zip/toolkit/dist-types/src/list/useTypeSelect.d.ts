export function useTypeSelect(options: any): {
    onKeyDownCapture: (event: any) => void;
};
