export default ListItemContext;
export function useListItemContext(): any;
declare const ListItemContext: import("react").Context<any>;
