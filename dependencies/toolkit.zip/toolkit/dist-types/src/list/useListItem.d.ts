export function useListItem(props?: {}): {
    item: any;
    itemToString: any;
    itemProps: any;
};
export function useVirtualizedListItem(props?: {}): {
    item: any;
    itemToString: any;
    itemProps: any;
};
