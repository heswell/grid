export function itemToString(item: any): string;
