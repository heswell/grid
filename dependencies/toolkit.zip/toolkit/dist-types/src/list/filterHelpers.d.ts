export function getDefaultFilterRegex(value: any): RegExp;
export function getDefaultFilter(inputValue?: string, getFilterRegex?: (value: any) => RegExp): (itemValue?: string) => boolean;
