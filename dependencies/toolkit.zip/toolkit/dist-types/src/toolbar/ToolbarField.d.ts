export default ToolbarField;
declare function ToolbarField({ children, ...props }: {
    [x: string]: any;
    children: any;
}): JSX.Element;
