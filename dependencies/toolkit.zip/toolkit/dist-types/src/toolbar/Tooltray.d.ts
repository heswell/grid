export default Tooltray;
declare function Tooltray({ align, children, className: classNameProp, collapse: collapseProp, collapsed: collapsedProp, "data-collapsible": collapse, "data-collapsed": collapsed, orientation, ...rest }: {
    [x: string]: any;
    align?: string | undefined;
    children: any;
    className: any;
    collapse: any;
    collapsed: any;
    "data-collapsible"?: any;
    "data-collapsed"?: any;
    orientation?: string | undefined;
}): JSX.Element;
