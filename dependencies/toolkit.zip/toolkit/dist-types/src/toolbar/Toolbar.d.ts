export default Toolbar;
declare function Toolbar({ children, className, id, maxRows: _1, orientation, style, title, tools: toolsProp, stops, getTools, ...rootProps }: {
    [x: string]: any;
    children: any;
    className: any;
    id: any;
    maxRows: any;
    orientation?: string | undefined;
    style: any;
    title: any;
    tools: any;
    stops: any;
    getTools?: (() => any) | undefined;
}): JSX.Element;
