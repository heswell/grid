export default ChaseLogo;
declare const ChaseLogo: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
import React from "react";
