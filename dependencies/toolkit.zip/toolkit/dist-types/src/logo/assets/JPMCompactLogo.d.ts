export default JPMCompactLogo;
declare const JPMCompactLogo: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
import React from "react";
