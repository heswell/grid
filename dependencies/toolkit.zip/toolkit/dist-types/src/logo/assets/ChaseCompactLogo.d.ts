export default ChaseCompactLogo;
declare const ChaseCompactLogo: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
import React from "react";
