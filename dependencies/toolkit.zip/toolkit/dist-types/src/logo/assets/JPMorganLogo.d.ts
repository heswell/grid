export default JPMorganLogo;
declare const JPMorganLogo: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
import React from "react";
