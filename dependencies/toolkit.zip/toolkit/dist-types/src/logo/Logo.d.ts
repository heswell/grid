export default Logo;
declare const Logo: React.ForwardRefExoticComponent<React.RefAttributes<any>>;
import React from "react";
