export function mergeStyles(s1: any, s2: any): any;
