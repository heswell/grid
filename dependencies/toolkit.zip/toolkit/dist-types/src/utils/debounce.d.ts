export default function debounce(func: any, wait?: number): {
    (...args: any[]): void;
    clear(): void;
};
