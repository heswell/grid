declare function _default(value: any): any;
export default _default;
