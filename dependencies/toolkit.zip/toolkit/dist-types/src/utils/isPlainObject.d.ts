export function isPlainObject(obj: any): boolean;
