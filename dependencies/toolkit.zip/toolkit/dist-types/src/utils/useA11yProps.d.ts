export default function useA11yProps(): {};
export const a11yContext: React.Context<{}>;
import React from "react";
