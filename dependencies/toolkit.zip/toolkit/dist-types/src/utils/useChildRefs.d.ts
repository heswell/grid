export default useChildRefs;
declare function useChildRefs(children: any): never[];
