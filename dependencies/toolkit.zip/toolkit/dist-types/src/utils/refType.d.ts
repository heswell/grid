export default refType;
declare const refType: PropTypes.Requireable<object>;
import PropTypes from "prop-types";
