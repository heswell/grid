export default function ownerDocument(node: any): any;
