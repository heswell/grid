export function teardown(doc: any): void;
export default function useIsFocusVisible(): {
    isFocusVisible: typeof isFocusVisible;
    onBlurVisible: typeof handleBlurVisible;
    ref: (instance: any) => void;
};
declare function isFocusVisible(event: any): any;
/**
 * Should be called if a blur event is fired on a focus-visible element
 */
declare function handleBlurVisible(): void;
export {};
