export default useLayoutEffectSkipFirst;
declare function useLayoutEffectSkipFirst(func: any, deps: any): void;
