export default function ownerWindow(node: any): any;
