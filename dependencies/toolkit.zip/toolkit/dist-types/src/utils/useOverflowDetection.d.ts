export default function useOverflowDetection(dependencies: any): (boolean | import("react").MutableRefObject<undefined>)[];
