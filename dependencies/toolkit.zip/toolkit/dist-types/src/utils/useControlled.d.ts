/**
 * Copied from MUI (v4.11.0) useControlled hook with one additional returned value
 * @see https://github.com/mui-org/material-ui/blob/master/packages/material-ui/src/utils/useControlled.js
 */
export default function useControlled({ controlled, default: defaultProp, name, state }: {
    controlled: any;
    default: any;
    name: any;
    state?: string | undefined;
}): any[];
