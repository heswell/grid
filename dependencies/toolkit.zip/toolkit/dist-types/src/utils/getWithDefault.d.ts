export default getWithDefault;
declare function getWithDefault(value: any, defaultValue: any): any;
